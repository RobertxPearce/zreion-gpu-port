module io_tools
  ! Intel
  use IFPORT
  use OMP_LIB


  ! HDF5
  use ISO_C_BINDING
  use HDF5


  ! Global
  use global


  ! Tools
  use fft_tools


  ! Default
  implicit none


contains


  subroutine write_dm
    ! Default
    implicit none


    ! Local variables
    integer(4)      :: un
    character(1000) :: fn


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Write dm
    un = 11
    fn = trim(dir_out)//'xv_dm.dat'
    write(*,*) 'Writing ',trim(fn)
    open(un,file=fn,form='binary')
    write(un) dm
    close(un)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called write dm'
    return
  end subroutine write_dm


!------------------------------------------------------------------------------!


  ! read_gaussian_random_field and write_gaussian_random_field now live in
  ! checkpoint_tools.f90. The old reader here took a raw Fortran binary holding
  ! delta1 *after* its forward FFT, which is why calc_delta_field used to skip
  ! the transform when read_grf was set. The replacement stores the real-space
  ! field in HDF5 instead, so the two directions are symmetric and the file is
  ! the same thing the GPU port loads.


!------------------------------------------------------------------------------!


  subroutine write_hdf5_header(file_id)
    ! Default
    implicit none


    ! Subroutine arguments
    integer(HID_T), intent(in) :: file_id


    ! Local variables
    integer(4)         :: error
    integer(4), target :: ng,is
    integer(HID_T)     :: header_id,dspace_id,dset_id
    integer(SIZE_T)    :: hint
    real(8)            :: tau
    type(C_PTR)        :: f_ptr
    integer(HSIZE_T), dimension(1) :: Ngrid,ddims


    ! Create header
    hint = 0
    call h5gcreate_f(file_id, "/header", header_id, error, size_hint=hint)

    ! Write header information
    Ngrid = (/ N_grid /)
    ddims = (/ 1 /)

    ! Grid size
    call h5screate_f(H5S_SCALAR_F, dspace_id, error)
    call h5dcreate_f(header_id, "N_grid", H5T_NATIVE_INTEGER, dspace_id, &
         dset_id, error)
    ng = N_grid
    f_ptr = c_loc(ng)
    call h5dwrite_f(dset_id, H5T_NATIVE_INTEGER, f_ptr, error)
    call h5dclose_f(dset_id, error)

    ! Box size
    call h5dcreate_f(header_id, "BoxSize", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, box, ddims, error)
    call h5dclose_f(dset_id, error)

    ! OmegaM
    call h5dcreate_f(header_id, "OmegaM", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, omegam, ddims, error)
    call h5dclose_f(dset_id, error)

    ! OmegaL
    call h5dcreate_f(header_id, "OmegaL", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, omegal, ddims, error)
    call h5dclose_f(dset_id, error)

    ! OmegaR
    call h5dcreate_f(header_id, "OmegaR", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, omegar, ddims, error)
    call h5dclose_f(dset_id, error)

    ! OmegaB
    call h5dcreate_f(header_id, "OmegaB", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, omegab, ddims, error)
    call h5dclose_f(dset_id, error)

    ! sigma8
    call h5dcreate_f(header_id, "sigma8", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, sigma8, ddims, error)
    call h5dclose_f(dset_id, error)

    ! hubble0
    call h5dcreate_f(header_id, "hubble0", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, hubble0, ddims, error)
    call h5dclose_f(dset_id, error)

    ! wde
    call h5dcreate_f(header_id, "wde", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, wde, ddims, error)
    call h5dclose_f(dset_id, error)

    ! YHe
    call h5dcreate_f(header_id, "YHe", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, YHe, ddims, error)
    call h5dclose_f(dset_id, error)

    ! nsinit
    call h5dcreate_f(header_id, "nsinit", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, nsinit, ddims, error)
    call h5dclose_f(dset_id, error)

    ! theta_max_ksz
    call h5dcreate_f(header_id, "theta_max_ksz", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, theta_max_ksz, ddims, error)
    call h5dclose_f(dset_id, error)

    ! Tcmb0
    call h5dcreate_f(header_id, "Tcmb0", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, Tcmb0, ddims, error)
    call h5dclose_f(dset_id, error)

    ! b0_zre
    call h5dcreate_f(header_id, "b0_zre", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, b0_zre, ddims, error)
    call h5dclose_f(dset_id, error)

    ! zmean_zre
    call h5dcreate_f(header_id, "zmean_zre", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, zmean_zre, ddims, error)
    call h5dclose_f(dset_id, error)

    ! alpha_zre
    call h5dcreate_f(header_id, "alpha_zre", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, alpha_zre, ddims, error)
    call h5dclose_f(dset_id, error)

    ! kb_zre
    call h5dcreate_f(header_id, "kb_zre", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, kb_zre, ddims, error)
    call h5dclose_f(dset_id, error)

    ! RNG seed. Four bytes that regenerate this run's initial conditions
    ! exactly; without it a product file cannot be traced back to a realization.
    call h5dcreate_f(header_id, "iseed", H5T_NATIVE_INTEGER, dspace_id, &
         dset_id, error)
    is = iseed_run
    f_ptr = c_loc(is)
    call h5dwrite_f(dset_id, H5T_NATIVE_INTEGER, f_ptr, error)
    call h5dclose_f(dset_id, error)

    ! Tau
    tau = tau_vals(2,1)  ! total tau
    call h5dcreate_f(header_id, "tau", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, tau, ddims, error)
    call h5dclose_f(dset_id, error)


    ! Close out
    call h5sclose_f(dspace_id, error)
    call h5gclose_f(header_id, error)

    return
  end subroutine write_hdf5_header


!------------------------------------------------------------------------------!


  subroutine write_fields
    ! Default
    implicit none


    ! Local variables
    character(1000)  :: fn,dir_sim,cmd
    integer(4)       :: error
    integer(HID_T)   :: file_id,dset_id
    integer(HID_T)   :: dspace_id,group_id
    integer(HSIZE_T) :: dims1(1),dims2(2),dims3(3)


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Initialize
    if (N_sims > 1) then
       if (isim < 10) then
          write(dir_sim,'(a,i1,a)') 'output_000',isim,'/'
       else if (isim < 100) then
          write(dir_sim,'(a,i2,a)') 'output_00' ,isim,'/'
       else if (isim < 1000) then
          write(dir_sim,'(a,i3,a)') 'output_0'  ,isim,'/'
       else
          write(dir_sim,'(a,i4,a)') 'output_'   ,isim,'/'
       endif
       dir_sim = trim(dir_out)//trim(dir_sim)
       cmd     = 'mkdir -p '//trim(dir_sim)
       error   = system(trim(cmd))
       fn      = trim(dir_sim)//fn_out
    else
       fn = trim(dir_out)//fn_out
    endif
    write(*,'(2a)') "Writing ",trim(fn)

    call h5open_f(error)
    call h5fcreate_f(trim(fn), H5F_ACC_TRUNC_F, file_id, error)

    ! Write header
    call write_hdf5_header(file_id)

    ! Create data group
    call h5gcreate_f(file_id, "/data", group_id, error)

    ! Write zvalues
    dims1 = (/ Nsightpix /)
    call h5screate_simple_f(1, dims1, dspace_id, error)
    call h5dcreate_f(group_id, "zvals", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, zvals, dims1, error)
    call h5dclose_f(dset_id, error)

    ! Write T0 values
    call h5dcreate_f(group_id, "t0vals", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, t0vals, dims1, error)
    call h5dclose_f(dset_id, error)
    call h5sclose_f(dspace_id, error)

    ! Write ionization history
    dims1 = (/ Nredshift /)
    call h5screate_simple_f(1, dims1, dspace_id, error)
    call h5dcreate_f(group_id, "zval_list", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, zval_list, dims1, error)
    call h5dclose_f(dset_id, error)

    call h5dcreate_f(group_id, "xval_list", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, xval_list, dims1, error)
    call h5dclose_f(dset_id, error)

    call h5dcreate_f(group_id, "xmval_list", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, xmval_list, dims1, error)
    call h5dclose_f(dset_id, error)
    call h5sclose_f(dspace_id, error)

    ! Write ksz field
    dims2 = (/ N_grid, N_grid /)
    call h5screate_simple_f(2, dims2, dspace_id, error)
    call h5dcreate_f(group_id, "ksz_map", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, ksz_map, dims2, error)
    call h5dclose_f(dset_id, error)

    ! Write t21 field
    call h5dcreate_f(group_id, "t21_map", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, t21_map, dims2, error)
    call h5dclose_f(dset_id, error)

    ! Write galaxy field
    call h5dcreate_f(group_id, "gal_map", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, gal_map, dims2, error)
    call h5dclose_f(dset_id, error)

    ! Write tau field
    call h5dcreate_f(group_id, "tau_map", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, tau_map, dims2, error)
    call h5dclose_f(dset_id, error)
    call h5sclose_f(dspace_id, error)

    if (save_t21_lightcone) then
       ! Write T21 lightcone
       dims3 = (/ N_grid, N_grid, Nsightpix /)
       call h5screate_simple_f(3, dims3, dspace_id, error)
       call h5dcreate_f(group_id, "t21_box", H5T_NATIVE_DOUBLE, dspace_id, &
            dset_id, error)
       call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, t21_box, dims3, error)
       call h5dclose_f(dset_id, error)
       call h5sclose_f(dspace_id, error)
    endif

    if (save_gal_lightcone) then
       ! Write galaxy lightcone
       dims3 = (/ N_grid, N_grid, Nsightpix /)
       call h5screate_simple_f(3, dims3, dspace_id, error)
       call h5dcreate_f(group_id, "gal_box", H5T_NATIVE_DOUBLE, dspace_id, &
            dset_id, error)
       call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, gal_box, dims3, error)
       call h5dclose_f(dset_id, error)
       call h5sclose_f(dspace_id, error)
    endif

    ! Close down
    call h5gclose_f(group_id, error)
    call h5fclose_f(file_id, error)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called write fields'
    return
  end subroutine write_fields


!------------------------------------------------------------------------------!


  subroutine read_fields
    ! Default
    implicit none


    ! Local variables
    character(1000)  :: fn,obj_name,dir_sim
    integer(4)       :: error
    integer(HID_T)   :: dset_id,file_id,attr_id
    integer(HSIZE_T) :: dims2(2)
    type(C_PTR)      :: f_ptr


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Prepare for reading
    if (N_sims > 1) then
       if (isim < 10) then
          write(dir_sim,'(a,i1,a)') 'output_000',isim,'/'
       else if (isim < 100) then
          write(dir_sim,'(a,i2,a)') 'output_00' ,isim,'/'
       else if (isim < 1000) then
          write(dir_sim,'(a,i3,a)') 'output_0'  ,isim,'/'
       else
          write(dir_sim,'(a,i4,a)') 'output_'   ,isim,'/'
       endif
       dir_sim = trim(dir_out)//trim(dir_sim)
       fn      = trim(dir_sim)//fn_out
    else
       fn = trim(dir_out)//fn_out
    endif
    write(*,*) "Reading ",trim(fn)
    call h5open_f(error)
    call h5fopen_f(fn, H5F_ACC_RDONLY_F, file_id, error)

    ! Read theta_max value
    if (read_all_fields) then
       write(obj_name,'(a)') "/header/theta_max_ksz"
       f_ptr = c_loc(theta_max_ksz)
       call h5dopen_f(file_id, obj_name, dset_id, error)
       call h5dread_f(dset_id, H5T_NATIVE_DOUBLE, f_ptr, error)
       call h5dclose_f(dset_id, error)
    else
       f_ptr = c_loc(theta_max_ksz)
       call h5aopen_by_name_f(file_id, "/Tau_map", "theta_max", attr_id, &
            error)
       call h5aread_f(attr_id, H5T_NATIVE_DOUBLE, f_ptr, error)
       call h5aclose_f(attr_id, error)
    endif

    ! Read maps in
    dims2 = (/ N_grid, N_grid /)
    if (read_all_fields) then
       call h5dopen_f(file_id, "/data/ksz_map", dset_id, error)
    else
       call h5dopen_f(file_id, "/Tau_map/Tau", dset_id, error)
    endif
    call h5dread_f(dset_id, H5T_NATIVE_DOUBLE, ksz_map, dims2, error)
    call h5dclose_f(dset_id, error)

    if (read_all_fields) then
       call h5dopen_f(file_id, "/data/gal_map", dset_id, error)
       call h5dread_f(dset_id, H5T_NATIVE_DOUBLE, gal_map, dims2, error)
       call h5dclose_f(dset_id, error)

       call h5dopen_f(file_id, "/data/t21_map", dset_id, error)
       call h5dread_f(dset_id, H5T_NATIVE_DOUBLE, t21_map, dims2, error)
       call h5dclose_f(dset_id, error)
    endif

    ! Close out
    call h5fclose_f(file_id, error)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called read fields'
    return
  end subroutine read_fields


!------------------------------------------------------------------------------!


  subroutine write_spectra
    ! Default
    implicit none


    ! Local variables
    character(1000) :: fn,dir_sim
    integer(4)      :: error
    integer(HID_T)  :: file_id,dset_id,data_id
    integer(HID_T)  :: memspace,dspace
    integer(HSIZE_T), dimension(2) :: mem_dims,offset,count,out_dims


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Prepare for writing
    if (N_sims > 1) then
       if (isim < 10) then
          write(dir_sim,'(a,i1,a)') 'output_000',isim,'/'
       else if (isim < 100) then
          write(dir_sim,'(a,i2,a)') 'output_00' ,isim,'/'
       else if (isim < 1000) then
          write(dir_sim,'(a,i3,a)') 'output_0'  ,isim,'/'
       else
          write(dir_sim,'(a,i4,a)') 'output_'   ,isim,'/'
       endif
       dir_sim = trim(dir_out)//trim(dir_sim)
       fn      = trim(dir_sim)//fn_cl
    else
       fn = trim(dir_out)//fn_cl
    endif
    write(*,'(2a)') "Writing ",trim(fn)

    call h5open_f(error)
    call h5fcreate_f(trim(fn), H5F_ACC_TRUNC_F, file_id, error)

    ! Write header
    call write_hdf5_header(file_id)

    ! Create data group
    call h5gcreate_f(file_id, "/data", data_id, error)

    ! Write cl spectra
    ! Only include well-samples modes
    mem_dims = (/ 3, N_grid /)
    offset   = (/ 0, 0 /)
    count    = (/ 3, N_grid/2 /)
    out_dims = (/ 3, N_grid/2 /)

    call h5screate_simple_f(2, mem_dims, memspace, error)
    call h5sselect_hyperslab_f(memspace, H5S_SELECT_SET_F, offset, count, error)
    call h5screate_simple_f(2, out_dims, dspace, error)

    call h5dcreate_f(data_id, "cl_ksz", H5T_NATIVE_DOUBLE, dspace, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, cl_ksz, mem_dims, error, &
         memspace, dspace)
    call h5dclose_f(dset_id, error)

    if (read_all_fields) then
       call h5dcreate_f(data_id, "cl_gal", H5T_NATIVE_DOUBLE, dspace, &
            dset_id, error)
       call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, cl_gal, mem_dims, error, &
            memspace, dspace)
       call h5dclose_f(dset_id, error)

       call h5dcreate_f(data_id, "cl_t21", H5T_NATIVE_DOUBLE, dspace, &
            dset_id, error)
       call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, cl_t21, mem_dims, error, &
            memspace, dspace)
       call h5dclose_f(dset_id, error)
    endif
    call h5sclose_f(dspace, error)
    call h5sclose_f(memspace, error)

    ! Close out
    call h5gclose_f(data_id, error)
    call h5fclose_f(file_id, error)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called write spectra'
    return
  end subroutine write_spectra


!------------------------------------------------------------------------------!


  subroutine write_pk
    ! Default
    implicit none


    ! Local variables
    character(1000)  :: fn,dir_sim
    integer(4)       :: error
    integer(HID_T)   :: file_id,dset_id
    integer(HID_T)   :: dspace_id,data_id
    integer(HSIZE_T) :: dims1(1),dims2(2),dims3(3)


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Prepare for writing
    if (N_sims > 1) then
       if (isim < 10) then
          write(dir_sim,'(a,i1,a)') 'output_000',isim,'/'
       else if (isim < 100) then
          write(dir_sim,'(a,i2,a)') 'output_00' ,isim,'/'
       else if (isim < 1000) then
          write(dir_sim,'(a,i3,a)') 'output_0'  ,isim,'/'
       else
          write(dir_sim,'(a,i4,a)') 'output_'   ,isim,'/'
       endif
       dir_sim = trim(dir_out)//trim(dir_sim)
       fn      = trim(dir_sim)//fn_pk
    else
       fn = trim(dir_out)//fn_pk
    endif
    write(*,'(2a)') "Writing ",trim(fn)

    call h5open_f(error)
    call h5fcreate_f(trim(fn), H5F_ACC_TRUNC_F, file_id, error)

    ! Write header
    call write_hdf5_header(file_id)

    ! Create data group
    call h5gcreate_f(file_id, "/data", data_id, error)

    ! Write zlist and xlist
    dims1 = (/ Nredshift /)
    call h5screate_simple_f(1, dims1, dspace_id, error)
    call h5dcreate_f(data_id, "zval_list", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, zval_list, dims1, error)
    call h5dclose_f(dset_id, error)

    call h5dcreate_f(data_id, "xval_list", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, xval_list, dims1, error)
    call h5dclose_f(dset_id, error)

    call h5dcreate_f(data_id, "xmval_list", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, xmval_list, dims1, error)
    call h5dclose_f(dset_id, error)
    call h5sclose_f(dspace_id, error)

    ! Write vrms
    dims2 = (/ 3, Nredshift /)
    call h5screate_simple_f(2, dims2, dspace_id, error)
    call h5dcreate_f(data_id, "vrms", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, vrms, dims2, error)
    call h5dclose_f(dset_id, error)
    call h5sclose_f(dspace_id, error)

    ! Write pk spectra
    dims3 = (/ 3, N_grid, Nredshift /)
    call h5screate_simple_f(3, dims3, dspace_id, error)
    call h5dcreate_f(data_id, "pk_dd", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, pk_dd, dims3, error)
    call h5dclose_f(dset_id, error)

    call h5dcreate_f(data_id, "pk_xx", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, pk_xx, dims3, error)
    call h5dclose_f(dset_id, error)

    call h5dcreate_f(data_id, "pk_dx", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, pk_dx, dims3, error)
    call h5dclose_f(dset_id, error)

    call h5dcreate_f(data_id, "pk_tt", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, pk_tt, dims3, error)
    call h5dclose_f(dset_id, error)

    ! Close out
    call h5sclose_f(dspace_id, error)
    call h5gclose_f(data_id, error)
    call h5fclose_f(file_id, error)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called write pk'
    return
  end subroutine write_pk


!------------------------------------------------------------------------------!


  subroutine get_box_size
    ! Default
    implicit none


    ! Local variables
    character(1000) :: fn,dir_sim
    integer(4)      :: error
    integer(HID_T)  :: dset_id,file_id,dspace_id
    integer(HSIZE_T) :: dims(3),maxdims(3)


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Prepare for reading
    if (N_sims > 1) then
       ! Grab just the first sim; assume they're all the same
       write(dir_sim,'(a)') 'output_0001/'
       dir_sim = trim(dir_out)//trim(dir_sim)
       fn      = trim(dir_sim)//fn_out
    else
       fn = trim(dir_out)//fn_out
    endif
    write(*,*) "Reading ",trim(fn)
    call h5open_f(error)
    call h5fopen_f(fn, H5F_ACC_RDONLY_F, file_id, error)

    ! Get the size of the t21_box dataset
    call h5dopen_f(file_id, "/data/t21_box", dset_id, error)
    call h5dget_space_f(dset_id, dspace_id, error)
    call h5sget_simple_extent_dims_f(dspace_id, dims, maxdims, error)
    Nsightpix = dims(3)
    call h5sclose_f(dspace_id, error)
    call h5dclose_f(dset_id, error)
    call h5fclose_f(file_id, error)

    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called get box size'
    return
  end subroutine get_box_size


!------------------------------------------------------------------------------!


  subRoutine read_ksz_zvals
    ! Default
    implicit none


    ! Local variables
    character(1000)  :: fn,dir_sim
    integer(4)       :: error
    integer(HID_T)   :: dset_id,file_id,dspace_id
    integer(HSIZE_T) :: dims1(1),maxdims1(1),dims2(2)
    type(C_PTR)      :: f_ptr


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Prepare for reading
    if (N_sims > 1) then
       if (isim < 10) then
          write(dir_sim,'(a,i1,a)') 'output_000',isim,'/'
       else if (isim < 100) then
          write(dir_sim,'(a,i2,a)') 'output_00' ,isim,'/'
       else if (isim < 1000) then
          write(dir_sim,'(a,i3,a)') 'output_0'  ,isim,'/'
       else
          write(dir_sim,'(a,i4,a)') 'output_'   ,isim,'/'
       endif
       dir_sim = trim(dir_out)//trim(dir_sim)
       fn      = trim(dir_sim)//fn_out
    else
       fn = trim(dir_out)//fn_out
    endif
    write(*,*) "Reading ",trim(fn)
    call h5open_f(error)
    call h5fopen_f(fn, H5F_ACC_RDONLY_F, file_id, error)

    ! Get theta_max value
    f_ptr = c_loc(theta_max_ksz)
    call h5dopen_f(file_id, "/header/theta_max_ksz", dset_id, error)
    call h5dread_f(dset_id, H5T_NATIVE_DOUBLE, f_ptr, error)
    call h5dclose_f(dset_id, error)

    ! Get the zvals dataset
    call h5dopen_f(file_id, "/data/zvals", dset_id, error)
    call h5dget_space_f(dset_id, dspace_id, error)
    call h5sget_simple_extent_dims_f(dspace_id, dims1, maxdims1, error)
    Nsightpix = dims1(1)
    if (allocated(zvals)) then
       deallocate(zvals)
    endif
    allocate(zvals(Nsightpix))
    zvals = 0
    call h5dread_f(dset_id, H5T_NATIVE_DOUBLE, zvals, dims1, error)
    call h5sclose_f(dspace_id, error)
    call h5dclose_f(dset_id, error)

    ! Now read in kSZ map
    dims2 = (/ N_grid, N_grid /)
    call h5dopen_f(file_id, "/data/ksz_map", dset_id, error)
    call h5dread_f(dset_id, H5T_NATIVE_DOUBLE, ksz_map, dims2, error)
    call h5dclose_f(dset_id, error)


    ! Close out
    call h5fclose_f(file_id, error)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called read ksz zvals'
    return
  end subroutine read_ksz_zvals


!------------------------------------------------------------------------------!


  subroutine read_obs_grids
    ! Default
    implicit none


    ! Local variables
    character(1000)  :: dir_sim,fn
    integer(4)       :: error
    integer(HID_T)   :: file_id,dset_id,memspace
    integer(HSIZE_T) :: dims(3),offset(3),count(3)


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Prepare for reading
        if (N_sims > 1) then
       if (isim < 10) then
          write(dir_sim,'(a,i1,a)') 'output_000',isim,'/'
       else if (isim < 100) then
          write(dir_sim,'(a,i2,a)') 'output_00' ,isim,'/'
       else if (isim < 1000) then
          write(dir_sim,'(a,i3,a)') 'output_0'  ,isim,'/'
       else
          write(dir_sim,'(a,i4,a)') 'output_'   ,isim,'/'
       endif
       dir_sim = trim(dir_out)//trim(dir_sim)
       fn      = trim(dir_sim)//fn_out
    else
       fn = trim(dir_out)//fn_out
    endif
    write(*,*) "Reading ",trim(fn)
    call h5open_f(error)
    call h5fopen_f(fn, H5F_ACC_RDONLY_F, file_id, error)

    ! Read in boxes
    dims = (/ N_grid, N_grid, Nsightpix /)
    call h5dopen_f(file_id, "/data/gal_box", dset_id, error)
    call h5dread_f(dset_id, H5T_NATIVE_DOUBLE, gal_box, dims, error)
    call h5dclose_f(dset_id, error)

    ! 21cm field is tricker b/c of FFT padding
    dims   = (/ N_grid+2, N_grid, Nsightpix /)
    offset = (/ 0, 0, 0 /)
    count  = (/ N_grid, N_grid, Nsightpix /)
    call h5screate_simple_f(3, dims, memspace, error)
    call h5sselect_hyperslab_f(memspace, H5S_SELECT_SET_F, offset, count, &
         error)
    call h5dopen_f(file_id, "/data/t21_box", dset_id, error)
    call h5dread_f(dset_id, H5T_NATIVE_DOUBLE, t21_box, dims, error, &
         memspace, H5S_ALL_F)
    call h5sclose_f(memspace, error)
    call h5dclose_f(dset_id, error)

    ! Close out
    call h5fclose_f(file_id, error)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called read obs grids'
    return
  end subroutine read_obs_grids


!------------------------------------------------------------------------------!


  subroutine read_field_chunks
    ! Default
    implicit none


    ! Local variables
    character(1000) :: dir_sim,fn
    integer(4)      :: error,i,j,k,Nwindow
    integer(HID_T)  :: file_id,dset_id,memspace,dataspace
    integer(HSIZE_T), dimension(3) :: offset_in,count_in   ! file handles
    integer(HSIZE_T), dimension(3) :: offset_out,count_out ! memory handles


    ! Local arrays
    real(8), dimension(N_grid,N_grid)      :: temp_map
    real(8), dimension(:,:,:), allocatable :: temp_array


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Prepare for reading
    if (N_sims > 1) then
       if (isim < 10) then
          write(dir_sim,'(a,i1,a)') 'output_000',isim,'/'
       else if (isim < 100) then
          write(dir_sim,'(a,i2,a)') 'output_00' ,isim,'/'
       else if (isim < 1000) then
          write(dir_sim,'(a,i3,a)') 'output_0'  ,isim,'/'
       else
          write(dir_sim,'(a,i4,a)') 'output_'   ,isim,'/'
       endif
       dir_sim = trim(dir_out)//trim(dir_sim)
       fn      = trim(dir_sim)//fn_out
    else
       fn = trim(dir_out)//fn_out
    endif
    write(*,*) "Reading ",trim(fn)
    call h5open_f(error)
    call h5fopen_f(fn, H5F_ACC_RDONLY_F, file_id, error)

    ! Allocate temporary array
    Nwindow = windx2 - windx1 + 1
    allocate(temp_array(N_grid, N_grid, Nwindow))

    ! Open the dataset and dataspace
    offset_in = (/ 0, 0, windx1 - 1 /)
    count_in = (/ N_grid, N_grid, Nwindow /)
    call h5dopen_f(file_id, "/data/t21_box", dset_id, error)
    call h5dget_space_f(dset_id, dataspace, error)
    call h5sselect_hyperslab_f(dataspace, H5S_SELECT_SET_F, offset_in, &
         count_in, error)

    ! Define the hyperslab in memory
    offset_out = (/ 0, 0, 0 /)
    count_out = (/ N_grid, N_grid, Nwindow /)
    call h5screate_simple_f(3, count_out, memspace, error)
    call h5sselect_hyperslab_f(memspace, H5S_SELECT_SET_F, offset_out, &
         count_out, error)

    ! Read in the data
    call h5dread_f(dset_id, H5T_NATIVE_DOUBLE, temp_array, count_out, error, &
         memspace, dataspace)
    call h5sclose_f(dataspace, error)
    call h5sclose_f(memspace, error)
    call h5dclose_f(dset_id, error)

    ! Move the data over to the target array
    temp_map = 0
    !$omp parallel do           &
    !$omp default(shared)       &
    !$omp private(i,j,k)        &
    !$omp reduction(+:temp_map)
    do k=1,Nwindow
       do j=1,N_grid
          do i=1,N_grid
             temp_map(i,j) = temp_map(i,j) + temp_array(i,j,k)/Nwindow
          enddo
       enddo
    enddo
    !$omp end parallel do

    !$omp parallel do     &
    !$omp default(shared) &
    !$omp private(i,j)
    do j=1,N_grid
       do i=1,N_grid
          t21_map(i,j) = temp_map(i,j)
       enddo
    enddo
    !$omp end parallel do

    ! Do the same for galaxy field
    call h5dopen_f(file_id, "/data/gal_box", dset_id, error)
    call h5dget_space_f(dset_id, dataspace, error)
    call h5sselect_hyperslab_f(dataspace, H5S_SELECT_SET_F, offset_in, &
         count_in, error)
    call h5screate_simple_f(3, count_out, memspace, error)
    call h5sselect_hyperslab_f(memspace, H5S_SELECT_SET_F, offset_out, &
         count_out, error)
    call h5dread_f(dset_id, H5T_NATIVE_DOUBLE, temp_array, count_out, error, &
         memspace, dataspace)
    call h5sclose_f(dataspace, error)
    call h5sclose_f(memspace, error)
    call h5dclose_f(dset_id, error)

    temp_map = 0
    !$omp parallel do           &
    !$omp default(shared)       &
    !$omp private(i,j,k)        &
    !$omp reduction(+:temp_map)
    do k=1,Nwindow
       do j=1,N_grid
          do i=1,N_grid
             temp_map(i,j) = temp_map(i,j) + temp_array(i,j,k)/Nwindow
          enddo
       enddo
    enddo
    !$omp end parallel do

    !$omp parallel do     &
    !$omp default(shared) &
    !$omp private(i,j)
    do j=1,N_grid
       do i=1,N_grid
          gal_map(i,j) = temp_map(i,j)
       enddo
    enddo
    !$omp end parallel do

    ! Close down
    deallocate(temp_array)
    call h5fclose_f(file_id, error)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called read field chunks'
    return
  end subroutine read_field_chunks


!------------------------------------------------------------------------------!


  subroutine write_window_spectra
    ! Default
    implicit none


    ! Local variables
    character(1000)  :: fn,dir_sim
    integer(4)       :: error
    integer(HID_T)   :: file_id,dset_id
    integer(HID_T)   :: dspace_id,data_id
    integer(HID_T)   :: memspace,dspace
    integer(HSIZE_T) :: dims1(1),dims3(3)
    integer(HSIZE_T), dimension(4) :: mem_dims,offset,count,out_dims


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Prepare for writing
    if (N_sims > 1) then
       if (isim < 10) then
          write(dir_sim,'(a,i1,a)') 'output_000',isim,'/'
       else if (isim < 100) then
          write(dir_sim,'(a,i2,a)') 'output_00' ,isim,'/'
       else if (isim < 1000) then
          write(dir_sim,'(a,i3,a)') 'output_0'  ,isim,'/'
       else
          write(dir_sim,'(a,i4,a)') 'output_'   ,isim,'/'
       endif
       dir_sim = trim(dir_out)//trim(dir_sim)
       fn      = trim(dir_sim)//fn_clw
    else
       fn = trim(dir_out)//fn_clw
    endif
    write(*,'(2a)') "Writing ",trim(fn)

    call h5open_f(error)
    call h5fcreate_f(trim(fn), H5F_ACC_TRUNC_F, file_id, error)

    ! Write header
    call write_hdf5_header(file_id)

    ! Create data group
    call h5gcreate_f(file_id, "/data", data_id, error)

    ! Write window values
    dims1 = (/ N_width /)
    call h5screate_simple_f(1, dims1, dspace_id, error)
    call h5dcreate_f(data_id, "delta_z", H5T_NATIVE_DOUBLE, dspace_id, dset_id, &
         error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, delta_z, dims1, error)
    call h5dclose_f(dset_id, error)
    call h5sclose_f(dspace_id, error)

    dims1 = (/ N_mid /)
    call h5screate_simple_f(1, dims1, dspace_id, error)
    call h5dcreate_f(data_id, "z_mid", H5T_NATIVE_DOUBLE, dspace_id, dset_id, &
         error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, z_mid, dims1, error)
    call h5dclose_f(dset_id, error)
    call h5sclose_f(dspace_id, error)

    ! Write redshift values
    dims3 = (/ 2, N_width, N_mid /)
    call h5screate_simple_f(3, dims3, dspace_id, error)
    call h5dcreate_f(data_id, "window_zvals", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, window_zvals, dims3, error)
    call h5dclose_f(dset_id, error)
    call h5sclose_f(dspace_id, error)

    ! Write cl spectra
    ! Only include well-sampled modes
    mem_dims = (/ 3, N_grid, N_width, N_mid /)
    offset   = (/ 0, 0, 0, 0 /)
    count    = (/ 3, N_grid/2, N_width, N_mid /)
    out_dims = (/ 3, N_grid/2, N_width, N_mid /)

    call h5screate_simple_f(4, mem_dims, memspace, error)
    call h5sselect_hyperslab_f(memspace, H5S_SELECT_SET_F, offset, count, error)
    call h5screate_simple_f(4, out_dims, dspace, error)

    call h5dcreate_f(data_id, "cl_ksz", H5T_NATIVE_DOUBLE, dspace, dset_id, &
         error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, cl_ksz_window, mem_dims, error,&
         memspace, dspace)
    call h5dclose_f(dset_id, error)

    call h5dcreate_f(data_id, "cl_gal", H5T_NATIVE_DOUBLE, dspace, dset_id, &
         error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, cl_gal_window, mem_dims, error,&
         memspace, dspace)
    call h5dclose_f(dset_id, error)

    call h5dcreate_f(data_id, "cl_t21", H5T_NATIVE_DOUBLE, dspace, dset_id, &
         error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, cl_t21_window, mem_dims, error,&
         memspace, dspace)
    call h5dclose_f(dset_id, error)

    call h5dcreate_f(data_id, "cl_ks2", H5T_NATIVE_DOUBLE, dspace, dset_id, &
         error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, cl_ks2_window, mem_dims, error,&
         memspace, dspace)
    call h5dclose_f(dset_id, error)

    call h5dcreate_f(data_id, "cl_kxg", H5T_NATIVE_DOUBLE, dspace, dset_id, &
         error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, cl_kxg_window, mem_dims, error,&
         memspace, dspace)
    call h5dclose_f(dset_id, error)

    call h5dcreate_f(data_id, "cl_kxt", H5T_NATIVE_DOUBLE, dspace, dset_id, &
         error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, cl_kxt_window, mem_dims, error,&
         memspace, dspace)
    call h5dclose_f(dset_id, error)

    ! Close out
    call h5sclose_f(memspace, error)
    call h5sclose_f(dspace, error)
    call h5gclose_f(data_id, error)
    call h5fclose_f(file_id, error)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called write window spectra'
    return
  end subroutine write_window_spectra


!------------------------------------------------------------------------------!


  subroutine read_f_ell
    ! Default
    implicit none


    ! Local variables
    character(1000)  :: fn
    integer(4)       :: error,nvals
    real(8)          :: fmax
    integer(HID_T)   :: dset_id,file_id,dspace_id
    integer(HSIZE_T) :: dims(2),maxdims(2)


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Prepare for reading
    fn = dir_filt//fn_filt
    write(*,*) "Reading ",trim(fn)
    call h5open_f(error)
    call h5fopen_f(fn, H5F_ACC_RDONLY_F, file_id, error)

    ! Get the size of the dataset
    call h5dopen_f(file_id, "/f_ell", dset_id, error)
    call h5dget_space_f(dset_id, dspace_id, error)
    call h5sget_simple_extent_dims_f(dspace_id, dims, maxdims, error)
    nvals = dims(2)
    allocate(f_ell(2,nvals))
    f_ell = 0
    call h5dread_f(dset_id, H5T_NATIVE_DOUBLE, f_ell, dims, error)
    call h5sclose_f(dspace_id, error)
    call h5dclose_f(dset_id, error)

    ! Close out
    call h5fclose_f(file_id, error)

    ! Renormalize array
    fmax  = maxval(f_ell(2,:))
    if (abs(fmax - 1) > 1e-3) then
       write(*,*) "Renormalizing f(ell) by: ",fmax
       f_ell(2,:) = f_ell(2,:)/fmax
    endif


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called read f ell'
    return
  end subroutine read_f_ell


!------------------------------------------------------------------------------!


  subroutine read_cmb_fields(fn,cmb_fields,Nfields)
    ! Default
    implicit none


    ! Subroutine arguments
    character(*) :: fn
    integer(4)   :: Nfields
    type(C_PTR)  :: f_ptr
    real(8), dimension(:,:,:), allocatable :: cmb_fields


    ! Local variables
    integer(4)       :: error,k
    integer(HID_T)   :: dset_id,file_id,dspace_id
    integer(HSIZE_T) :: dims(3),maxdims(3)


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Prepare for reading
    write(*,*) "Reading ",trim(fn)
    call h5open_f(error)
    call h5fopen_f(fn, H5F_ACC_RDONLY_F, file_id, error)

    ! Get theta_max value
    f_ptr = c_loc(theta_max_ksz)
    call h5dopen_f(file_id, "theta_max", dset_id, error)
    call h5dread_f(dset_id, H5T_NATIVE_DOUBLE, f_ptr, error)
    call h5dclose_f(dset_id, error)

    ! Get the size of the dataset
    call h5dopen_f(file_id, "cmb_maps", dset_id, error)
    call h5dget_space_f(dset_id, dspace_id, error)
    call h5sget_simple_extent_dims_f(dspace_id, dims, maxdims, error)
    Nfields = dims(3)

    ! Allocate and initialize
    allocate(cmb_fields(N_grid,N_grid,Nfields))
    !$omp parallel do     &
    !$omp default(shared) &
    !$omp private(k)
    do k=1,Nfields
       cmb_fields(:,:,k) = 0
    enddo
    !$omp end parallel do

    ! Read in file
    call h5dread_f(dset_id, H5T_NATIVE_DOUBLE, cmb_fields, dims, error)
    call h5sclose_f(dspace_id, error)
    call h5dclose_f(dset_id, error)

    ! Close out
    call h5fclose_f(file_id, error)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called read cmb fields'
    return
  end subroutine read_cmb_fields


!------------------------------------------------------------------------------!


  subroutine read_bt
    ! Default
    implicit none


    ! Local variables
    integer(4) :: un,i,nrows
    real(8)    :: z,bgal


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Scan file
    un = 11
    write(*,*) "Reading ",fn_bt
    open(un,file=fn_bt)
    nrows = 0
    do
       read(un,*,end=1) z,bgal
       nrows = nrows + 1
    enddo
1   continue

    ! allocate
    allocate(bt_bias(2,nrows))
    bt_bias = 0

    ! read in
    rewind(un)
    do i=1,nrows
       read(un,*) z,bgal
       bt_bias(1,i) = z
       bt_bias(2,i) = bgal
    enddo
    close(un)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called read bt'
    return
  end subroutine read_bt


!------------------------------------------------------------------------------!


  subroutine write_zreion(t0_vals)
    ! Default
    implicit none


    ! Subroutine arguments
    real(8), dimension(:,:) :: t0_vals


    ! Local variables
    character(1000)  :: fn
    integer(4)       :: error,n1,n2
    integer(HID_T)   :: file_id,dset_id,data_id
    integer(HID_T)   :: memspace,dspace
    integer(HSIZE_T) :: mem_dims(3),offset(3),count2(2),count3(3),out_dims(3)


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Prepare for writing
    fn = dir//'zreion.hdf5'

    write(*,*) "Writing ",trim(fn)

    call h5open_f(error)
    call h5fcreate_f(trim(fn), H5F_ACC_TRUNC_F, file_id, error)

    ! Write header
    call write_hdf5_header(file_id)


    ! Create data group
    call h5gcreate_f(file_id, "/data", data_id, error)


    ! Write T0 values
    n1 = size(t0_vals, dim=1)
    n2 = size(t0_vals, dim=2)

    count2 = (/ n1, n2  /)
    call h5screate_simple_f(2, count2, dspace, error)
    call h5dcreate_f(data_id, "t0_vals", H5T_NATIVE_DOUBLE, dspace, dset_id, &
         error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, t0_vals, count2, error)
    call h5dclose_f(dset_id, error)
    call h5sclose_f(dspace, error)


    ! Write fields using hyperslabs
    mem_dims = (/ Ndm+2, Ndm, Ndm /)
    offset   = (/ 0, 0, 0 /)
    count3   = (/ Ndm, Ndm, Ndm /)
    out_dims = (/ Ndm, Ndm, Ndm /)

    call h5screate_simple_f(3, mem_dims, memspace, error)
    call h5sselect_hyperslab_f(memspace, H5S_SELECT_SET_F, offset, count3, error)
    call h5screate_simple_f(3, out_dims, dspace, error)
    call h5dcreate_f(data_id, "zreion", H5T_NATIVE_DOUBLE, dspace, dset_id, &
         error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, zreion, mem_dims, error, &
         memspace, dspace)
    call h5dclose_f(dset_id, error)

    ! Close out
    call h5sclose_f(dspace, error)
    call h5sclose_f(memspace, error)
    call h5gclose_f(data_id, error)
    call h5fclose_f(file_id, error)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called write zreion'
    return
  end subroutine write_zreion


!------------------------------------------------------------------------------!


  subroutine write_coeval_density(zval)
    ! Default
    implicit none


    ! Subroutine arguments
    real(8), intent(in) :: zval


    ! Local variables
    character(1000) :: fn
    character(7)    :: ztag
    integer(4)      :: error
    integer(HID_T)  :: file_id,dset_id,data_id
    integer(HID_T)  :: memspace,dspace
    integer(HSIZE_T), dimension(3) :: mem_dims,offset,count,out_dims


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Prepare for writing
    if (zval >= 10) then
       write(ztag,'(f7.4)') zval
    else
       write(ztag,'(a,f6.4)') '0',zval
    endif
    fn = dir//'coeval_density_z'//ztag//'.hdf5'

    write(*,*) "Writing ",trim(fn)

    call h5open_f(error)
    call h5fcreate_f(trim(fn), H5F_ACC_TRUNC_F, file_id, error)

    ! Write header
    call write_hdf5_header(file_id)

    ! Create data group
    call h5gcreate_f(file_id, "/data", data_id, error)
    ! Write fields using hyperslabs
    mem_dims = (/ Ndm+2, Ndm, Ndm /)
    offset   = (/ 0, 0, 0 /)
    count    = (/ Ndm, Ndm, Ndm /)
    out_dims = (/ Ndm, Ndm, Ndm /)

    call h5screate_simple_f(3, mem_dims, memspace, error)
    call h5sselect_hyperslab_f(memspace, H5S_SELECT_SET_F, offset, count, error)
    call h5screate_simple_f(3, out_dims, dspace, error)
    call h5dcreate_f(data_id, "density", H5T_NATIVE_DOUBLE, dspace, dset_id, &
         error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, densityA, mem_dims, error, &
         memspace, dspace)
    call h5dclose_f(dset_id, error)

    ! Close out
    call h5sclose_f(dspace, error)
    call h5sclose_f(memspace, error)
    call h5gclose_f(data_id, error)
    call h5fclose_f(file_id, error)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called write coeval density'
    return
  end subroutine write_coeval_density


  subroutine close_h5
    ! Default
    implicit none


    ! Local variables
    integer(4) :: error
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Close HDF5 library
    call h5close_f(error)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called close h5'
    return
  end subroutine close_h5


end module io_tools
