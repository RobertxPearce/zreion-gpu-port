"""
Assuming orphics noise, filters are already computed
"""

import sys

FILTER = sys.argv[1]

assert FILTER in ["s4_ilc", "so_ilc", "hd_ilc"]


# STEP ONE: CHANGING GLOBAL.F90

fname_global = "global.f90"

EXPECTED_GLOBAL_CHANGES = 2
num_global_changes = 0

with open(fname_global) as f:
    new_lines = f.readlines()
    old_lines = list(new_lines)
    for lineno, line in enumerate(old_lines):
        if "parameter :: fn_filt" in line:
            new_lines[lineno] = line.split("fn_filt")[0] + "fn_filt = \'f_ell_" + FILTER + ".hdf5\'" + "\n"
            num_global_changes += 1
        if "parameter :: fn_clw" in line:
            new_lines[lineno] = line.split("fn_clw")[0] + "fn_clw = \'cl_arrays_window_" + FILTER + ".hdf5\'" + "\n"
            num_global_changes += 1

assert num_global_changes == EXPECTED_GLOBAL_CHANGES
with open(fname_global, "w") as f:
    f.writelines(new_lines)

#STEP TWO: CHANGING CONVOLUTION_INTEGRAL.F90

fname_conv = "convolution_integral.f90"

EXPECTED_CONV_CHANGES = 2
num_conv_changes = 0

with open(fname_conv) as f:
    new_lines = f.readlines()
    old_lines = list(new_lines)
    for lineno, line in enumerate(old_lines):
        if "parameter :: noise_fn" in line:
            new_lines[lineno] = line.split("noise_fn")[0] + "noise_fn = \'data/orphics_" + FILTER[:2] + "\'" + "\n"
            num_conv_changes += 1
        if "parameter :: read_noise" in line:
            new_lines[lineno] = line.split("read_noise")[0] + "read_noise = .true." + "\n"
            num_conv_changes += 1

assert num_conv_changes == EXPECTED_CONV_CHANGES
with open(fname_conv, "w") as f:
    f.writelines(new_lines)
