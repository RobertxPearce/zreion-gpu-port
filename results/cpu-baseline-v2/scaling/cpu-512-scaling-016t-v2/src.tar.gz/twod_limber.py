#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import numpy as np
import h5py
from astropy.cosmology import FlatLambdaCDM
from scipy.optimize import brentq
from scipy.integrate import quad

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# physical constants
c_cgs = 2.99792e10  # cm/s
mH_cgs = 1.67223e-24  # g
mHe_cgs = 4 * mH_cgs  # g
rhoc_cgs = 1.8789e-29  # h^2 g/cm^3
sT_cgs = 6.65246e-25  # cm^-2
Mpc2cm = 3.0856e24

# define where to look
root_dir = "/jet/home/plaplant/scratch_ml/ksz/output_0001"

# read in data files
fn = os.path.join(root_dir, "pk_arrays.hdf5")
with h5py.File(fn, "r") as h5f:
    zvals = h5f["data/zval_list"][()]
    xvals = h5f["data/xval_list"][()]
    vrms = h5f["data/vrms"][()]
    pk_dd = h5f["data/pk_dd"][()]
    pk_xx = h5f["data/pk_xx"][()]
    pk_dx = h5f["data/pk_dx"][()]

    # get cosmology values
    omegam = h5f["header/OmegaM"][()]
    omegal = h5f["header/OmegaL"][()]
    omegab = h5f["header/OmegaB"][()]
    try:
        tcmb = h5f["header/Tcmb0"][()]
    except KeyError:
        tcmb = 2.7255
    hubble0 = h5f["header/hubble0"][()]

# compute cosmological factors
cosmo = FlatLambdaCDM(hubble0 * 100, omegam, tcmb)
zstart = 6.0
zend = 15.0
chi0 = cosmo.comoving_distance(zstart).to("Mpc").value
chi1 = cosmo.comoving_distance(zend).to("Mpc").value

def z_of_chi(chi):
    def func(x):
        return (cosmo.comoving_distance(x).to("Mpc").value) - chi
    return brentq(func, 0, 5e4)

def ne_of_z(z):
    a = 1.0 / (1 + z)
    xval = np.interp(z, zvals, xvals)
    nH = omegab * rhoc_cgs * hubble0**2 / a**3 / mH_cgs
    nHe = omegab * rhoc_cgs * hubble0**2 / a**3 / mHe_cgs
    ne = (1 - xval) * (nH + nHe)
    return ne

# compute C_ell spectrum
print("computing C_l...")
ells = np.logspace(2.5, 4, num=100, dtype=np.float64)
cl = np.zeros_like(ells)
for i, ell in enumerate(ells):
    def integrand(chi):
        z = z_of_chi(chi)
        a = 1.0 / (1 + z)
        v = np.interp(z, zvals, vrms[:, 0]) * 1e5  # km/s -> cm/s
        ne = ne_of_z(z)  # cm^-3
        k = ell / chi / hubble0  # h/Mpc
        dz = z - zvals
        wherepos = np.where(dz > 0)
        iz1 = np.argmin(dz[wherepos])
        iz2 = iz1 + 1

        # interpolate in k first
        if True:
            pxx_z1 = np.interp(k, pk_xx[iz1, :, 0], pk_xx[iz1, :, 1])
            pxx_z2 = np.interp(k, pk_xx[iz2, :, 0], pk_xx[iz1, :, 1])
            pdx_z1 = np.interp(k, pk_dx[iz1, :, 0], pk_dx[iz1, :, 1])
            pdx_z2 = np.interp(k, pk_dx[iz2, :, 0], pk_dx[iz1, :, 1])
            pdd_z1 = np.interp(k, pk_dd[iz1, :, 0], pk_dd[iz1, :, 1])
            pdd_z2 = np.interp(k, pk_dd[iz2, :, 0], pk_dd[iz1, :, 1])
        else:
            pxx_z1 = np.exp(np.interp(k, np.log(pk_xx[iz1, :, 0]), np.log(pk_xx[iz1, :, 1])))
            pxx_z2 = np.exp(np.interp(k, np.log(pk_xx[iz2, :, 0]), np.log(pk_xx[iz1, :, 1])))
            pdx_z1 = np.exp(np.interp(k, np.log(pk_dx[iz1, :, 0]), np.log(pk_dx[iz1, :, 1])))
            pdx_z2 = np.exp(np.interp(k, np.log(pk_dx[iz2, :, 0]), np.log(pk_dx[iz1, :, 1])))
            pdd_z1 = np.exp(np.interp(k, np.log(pk_dd[iz1, :, 0]), np.log(pk_dd[iz1, :, 1])))
            pdd_z2 = np.exp(np.interp(k, np.log(pk_dd[iz2, :, 0]), np.log(pk_dd[iz1, :, 1])))

        # now interpolate in redshift
        # P(k) has units of (Mpc/h)**3; convert to Mpc**3
        pxx = np.interp(z, [zvals[iz1], zvals[iz2]], [pxx_z1, pxx_z2]) / hubble0**3
        pdx = np.interp(z, [zvals[iz1], zvals[iz2]], [pdx_z1, pdx_z2]) / hubble0**3
        pdd = np.interp(z, [zvals[iz1], zvals[iz2]], [pdd_z1, pdd_z2]) / hubble0**3

        # put it all together
        # we need to clean up a straggling (Mpc -> cm)^2 conversion factor
        return (
            a**2 * v**2 * sT_cgs**2 * ne**2 * (pxx + 2 * pdx + pdd)
            / (c_cgs * chi)**2 * Mpc2cm**2
        )

    # compute integral
    cl[i] = tcmb**2 / 3 * quad(integrand, chi0, chi1)[0] * 1e12  # units of uK^2

print("cl: ", cl)

# make a plot
dl = ells * (ells + 1) * cl / (2 * np.pi)

print("plotting...")
fig = plt.figure()
ax = plt.gca()
ax.loglog(ells, dl)
ax.set_xlabel(r"$\ell$")
ax.set_ylabel(r"$\ell(\ell+1)C_\ell/2\pi$ [$\mu$K$^2$]")
output = "ksz_limber.pdf"
print(f"saving {output}...")
fig.savefig(output, bbox_inches="tight")
plt.close(fig)

fig = plt.figure()
ax = plt.gca()
zx = np.linspace(6, 15, num=1000)
ne = ne_of_z(zx)
ax.plot(zx, ne)
ax.set_xlabel("$z$")
ax.set_ylabel(r"$n_e(z)$ [cm$^{-3}$]")
output = "ne.pdf"
print(f"saving {output}...")
fig.savefig(output, bbox_inches="tight")
plt.close(fig)

fig = plt.figure()
ax = plt.gca()
zx = np.linspace(6, 15, num=1000)
xx = np.interp(zx, zvals, xvals)
ax.plot(zx, 1 - xx)
ax.set_xlabel("$z$")
ax.set_ylabel(r"x(z)$")
output = "xvals.pdf"
print(f"saving {output}...")
fig.savefig(output, bbox_inches="tight")
plt.close(fig)
