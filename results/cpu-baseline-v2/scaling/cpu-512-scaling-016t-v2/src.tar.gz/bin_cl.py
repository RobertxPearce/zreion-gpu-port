# -*- coding: utf-8 -*-

import warnings
import numpy as np


def bin_cl(ell, cl, delta_ell=50, log_bins=False, log_width=0.1):
    """
    Re-bin l and Cl data given a particular bin width.

    This funciton does not assume that the l values are
    monotonic, just that the indices of ell and cl match.

    Parameters
    ----------
    ell : ndarray
        The l values of the angular power spectrum.
    cl : ndarray
        The corresponding Cl values for the power spectrum.
    delta_ell : int or float, optional
        The bin width of l-modes to use. Default is 50. This option is ignored
        when log_bins is True.
    log_bins : bool, optional
        When True, use constant logarithmic bins (i.e., dl/l is constant).
        Otherwise, use constant linear bins. Default is False.
    log_width : float, optional
        The relative spacing in log space (d ell / ell) to use for specifying
        bin width. This option is ignored when log_bins is False.

    Returns
    -------
    new_ell : ndarray
        The new l values of the angular power spectrum.
    new_cl : ndarray
        The new Cl values.

    Raises
    ------
    ValueError:
        This is raised if ell and cl are not 1d arrays, or if their
        shapes do not match.
    """
    if ell.shape != cl.shape:
        raise ValueError("ell and cl must have the same shape")
    if len(ell.shape) != 1:
        raise ValueError("ell and cl must be one-dimensional arrays")

    ell_min = np.amin(ell)
    ell_max = np.amax(ell)
    if log_bins:
        if np.isclose(ell_min, 0.0):
            # set a new ell_min that won't give us inifinity
            ell_min = 1.0
        lmin = np.log(ell_min)
        lmax = np.log(ell_max)
        n_bins = int((lmax - lmin) / log_width + 1)
        new_ell = np.asarray(
            [np.exp((i + 0.5) * log_width + lmin) for i in range(n_bins)]
        )
        bin_edges = np.asarray(
            [np.exp(i * log_width + lmin) for i in range(n_bins + 1)]
        )
    else:
        n_bins = int((ell_max - ell_min) / delta_ell + 1)
        new_ell = np.asarray([(i + 0.5) * delta_ell + ell_min for i in range(n_bins)])
        bin_edges = np.asarray([i * delta_ell + ell_min for i in range(n_bins + 1)])
    new_cl = np.zeros_like(new_ell)

    for i, el in enumerate(new_ell):
        lmin = bin_edges[i]
        lmax = bin_edges[i + 1]
        indices = np.logical_and(ell >= lmin, ell < lmax)
        arr = np.ma.masked_array(cl, mask=~indices)

        # We might take the average of a totally-masked bin, which leads to NaN,
        # which we clean up later. Ignore warnings for now
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            new_cl[i] = np.average(arr)

    new_cl = np.where(np.isnan(new_cl), 0.0, new_cl)
    return new_ell, new_cl
