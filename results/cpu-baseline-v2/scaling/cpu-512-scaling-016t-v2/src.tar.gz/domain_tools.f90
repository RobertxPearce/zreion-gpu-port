module domain_tools
  ! Intel
  use IFPORT
  use OMP_LIB


  ! Global
  use global


  ! Default
  implicit none
  public


contains


  subroutine init_domain
    ! Default
    implicit none


    ! Local variables
    integer(4) :: a,b,c
    integer(4) :: i,j,k
    integer(4) :: l,m,n
    integer(4) :: i1,j1,k1
    integer(4) :: n1,n2,n3,nx,ny,nz


    ! Timing variables
    real(8)      :: tr1,tr2
    character(8) :: ts1,ts2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Calculate domain subdivision. Seeded from N_dom_seed, not N_cpu, so the
    ! decomposition is the same at every thread count -- see global.f90.
    n = nint((N_dom_seed)**(1./3))

    ! Sentinel: the search below can find no divisor, which used to leave n1, nx
    ! and Ndomain undefined and allocate on garbage. Now selectable grid sizes
    ! make that reachable, so fail loudly instead.
    Ndomain = 0

    do i=n,N_grid
       if (mod(N_grid,2*i) == 0) then
          n1 = 2*i
          n2 = n1
          n3 = n1
          nx = N_grid/n1
          ny = nx
          nz = nx
          Ndomain = n1*n2*n3
          ! write(*,*) Ncpu,Ndomain,n1,nx,Ndm
          exit
       endif
    enddo

    if (Ndomain == 0) then
       write(*,*) "init_domain: no valid subdivision of N_grid = ",N_grid, &
            " for N_dom_seed = ",N_dom_seed
       write(*,*) "N_grid must be divisible by 2*i for some i >= nint(N_dom_seed**(1/3))"
       stop 1
    endif


    ! Allocate domain arrays
    allocate(domain(  27 ,Ndomain))
    allocate(indx_dom(2,3,Ndomain))


    ! Calculate domain information
    do n=1,Ndomain
       i = 1 + mod((n-1),n1)
       j = 1 + mod((n-1)/n1,n2)
       k = 1 +    ((n-1)/n1/n2)

       ! Calculate indices
       indx_dom(1,1,n) = 1 + (i-1)*nx
       indx_dom(2,1,n) = i*nx
       indx_dom(1,2,n) = 1 + (j-1)*ny
       indx_dom(2,2,n) = j*ny
       indx_dom(1,3,n) = 1 + (k-1)*nz
       indx_dom(2,3,n) = k*nz
       ! write(*,*) n,i,indx_dom(:,1,n)
       ! write(*,*) n,j,indx_dom(:,2,n)
       ! write(*,*) n,k,indx_dom(:,3,n)

       ! Init domain
       m           = 1
       domain(1,n) = 0

       ! Calculate neighbors
       do c=-1,1
          k1 = 1 + mod(k + c - 1 + n3,n3)
          do b=-1,1
             j1 = 1 + mod(j + b - 1 + n2,n2)
             do a=-1,1
                i1 = 1 + mod(i + a - 1 + n1,n1)
                l  = i1 + (j1-1)*n1 + (k1-1)*n1*n2
              
                if (l /= n) then
                   m           = m + 1
                   domain(m,n) = l
                endif
             enddo
          enddo
       enddo
    enddo


    call time(ts2)
    tr2 = omp_get_wtime()
    write(*,"(f8.2,2a10,a)") tr2-tr1,ts1,ts2,'  Called init domain'
    return
  end subroutine init_domain


  subroutine set_domain(i,Ndomain,domain)
    ! Default
    implicit none

    ! Subroutine arguments
    integer(4) :: i,Ndomain
    integer(4) :: domain(:,:)


    ! Local variables
    integer(4) :: l,m,n
    logical    :: loop,eval


    !$omp critical (access_domain)
    ! Repeat until eligible domain is found
    loop = .true.

    do while (loop)
       do n=1,Ndomain
          if (domain(1,n) == 0) then
             eval = .true.
             do m=2,27
                l = domain(m,n)
                if (domain(1,l) == 1) then
                   eval = .false.
                   exit
                endif
             enddo

             if (eval) then
                i           = n
                domain(1,i) = 1
                loop        = .false.
                exit
             endif
          endif
       enddo
    enddo
    !$omp end critical (access_domain)

    return
  end subroutine set_domain


  subroutine end_domain(i,Ndomain,domain)
    ! Default
    implicit none


    ! Subroutine arguments
    integer(4) :: i,Ndomain
    integer(4) :: domain(:,:)


    ! Domain evaluated
    domain(1,i) = 2

    ! Reset domains if all are evaluated
    if (sum(domain(1,:)) == 2*Ndomain) domain(1,:) = 0

    return
  end subroutine end_domain


end module domain_tools
