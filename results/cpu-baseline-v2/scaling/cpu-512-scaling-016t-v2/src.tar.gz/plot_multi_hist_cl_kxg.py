# -*- coding: utf-8 -*-

import os
import datetime
import h5py
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from bin_cl import bin_cl

dark_background = False
if dark_background:
    plt.style.use("dark_background")
    transparent = True
    ax_color = "w"
else:
    transparent = False
    ax_color = "k"

fontsize = 20
sm_fontsize = 14

# define where to find files
extended_dir = "/ocean/projects/ast180004p/jsipple/ksz/extended_output"
early_dir = "/ocean/projects/ast180004p/jsipple/ksz/early_output"
short_dir = "/jet/home/plaplant/scratch_ml/ksz/fiducial/bt_bias"

out_dir = "/ocean/projects/ast190007p/plaplant/ksz/plots"

# define parameters
experiment = "so_ilc"
cl_window_fn = f"cl_arrays_window_{experiment}.hdf5"
log_width = 0.2

# get representative window values
cl_fn = os.path.join(extended_dir, "output_0001", cl_window_fn)
with h5py.File(cl_fn, "r") as h5f:
    tcmb0 = h5f["header/Tcmb0"][()]
    window_zvals = h5f["data/window_zvals"][()]
tfac = tcmb0 * 1e6

# define function for reading in datasets
def read_all_data(root_dir):
    navg = 0
    output_dirs = sorted([d for d in os.listdir(root_dir) if "output_00" in d])
    for idir, dirname in enumerate(output_dirs):
        cl_fn = os.path.join(root_dir, dirname, cl_window_fn)
        print(f"reading {cl_fn}...")
        with h5py.File(cl_fn, "r") as h5f:
            cl_kxg = h5f["data/cl_kxg"][()]

        cl_kxg[:, :, :, 1:3] *= tfac**2

        ells = cl_kxg[:, :, 1:, 0]
        cl = cl_kxg[:, :, 1:, 1]
        cl2 = cl_kxg[:, :, 1:, 1]**2

        if idir == 0:
            # bin up spectra
            binned_ells, temp_cl = bin_cl(
                ells[0, 0, :], cl[0, 0, :], log_bins=True, log_width=log_width
            )
            binned_cl = np.zeros(
                (cl.shape[0], cl.shape[1], temp_cl.shape[0]), dtype=np.float64
            )
            binned_cl2 = np.zeros(
                (cl.shape[0], cl.shape[1], temp_cl.shape[0]), dtype=np.float64
            )
            for i in range(cl.shape[0]):
                for j in range(cl.shape[1]):
                    binned_cl[i, j, :] = bin_cl(
                        ells[i, j, :], cl[i, j, :], log_bins=True, log_width=log_width
                    )[1]
                    binned_cl2[i, j, :] = bin_cl(
                        ells[i, j, :], cl2[i, j, :], log_bins=True, log_width=log_width
                    )[1]
        else:
            for i in range(cl.shape[0]):
                for j in range(cl.shape[1]):
                    binned_cl[i, j, :] += bin_cl(
                        ells[i, j, :], cl[i, j, :], log_bins=True, log_width=log_width
                    )[1]
                    binned_cl2[i, j, :] += bin_cl(
                        ells[i, j, :], cl2[i, j, :], log_bins=True, log_width=log_width
                    )[1]

        navg += 1

    # finish computing statistics once we're done
    binned_cl /= navg
    binned_cl2 = np.sqrt(binned_cl2 / navg - binned_cl**2) / np.sqrt(navg)

    return binned_ells, binned_cl, binned_cl2

def write_data(filename, binned_ells, binned_cl, binned_cl2):
    with h5py.File(filename, "w") as h5f:
        dset = h5f.create_dataset("binned_ells", data=binned_ells)
        dset = h5f.create_dataset("binned_cl", data=binned_cl)
        dset = h5f.create_dataset("binned_cl2", data=binned_cl2)

    return

def read_binned_data(filename):
    with h5py.File(filename, "r") as h5f:
        binned_ells = h5f["binned_ells"][()]
        binned_cl = h5f["binned_cl"][()]
        binned_cl2 = h5f["binned_cl2"][()]

    return binned_ells, binned_cl, binned_cl2


# test to see if data has been pre-computed already
data_extended_fn = f"data/binned_cl_extended_{experiment}.hdf5"
data_early_fn = f"data/binned_cl_early_{experiment}.hdf5"
data_short_fn = f"data/binned_cl_short_{experiment}.hdf5"

try:
    ext_ell, ext_cl, ext_cl2 = read_binned_data(data_extended_fn)
    have_ext_data = True
except (IOError, OSError):
    have_ext_data = False

try:
    early_ell, early_cl, early_cl2 = read_binned_data(data_early_fn)
    have_early_data = True
except (IOError, OSError):
    have_early_data = False

try:
    short_ell, short_cl, short_cl2 = read_binned_data(data_short_fn)
    have_short_data = True
except (IOError, OSError):
    have_short_data = False

if not have_ext_data:
    ext_ell, ext_cl, ext_cl2 = read_all_data(extended_dir)
    write_data(data_extended_fn, ext_ell, ext_cl, ext_cl2)

if not have_early_data:
    early_ell, early_cl, early_cl2 = read_all_data(early_dir)
    write_data(data_early_fn, early_ell, early_cl, early_cl2)

if not have_short_data:
    short_ell, short_cl, short_cl2 = read_all_data(short_dir)
    write_data(data_short_fn, short_ell, short_cl, short_cl2)

# make plot
matplotlib.rc("text", usetex=True)
matplotlib.rc("font", family="serif")

fig = plt.figure()
ax = plt.gca()
ax.axhline(y=0.0, color=ax_color, linestyle="--")

linewidth = 1.5
alpha = 0.75

ells = [500, 1000, 3000]
dl_ext_list = []
dl_early_list = []
dl_short_list = []

lines = []
for iell, ell in enumerate(ells):
    zvals = np.zeros((window_zvals.shape[0],), dtype=np.float64)
    dl_vals_ext = np.zeros_like(zvals)
    dl_vals_early = np.zeros_like(zvals)
    dl_vals_short = np.zeros_like(zvals)

    for i in range(window_zvals.shape[0]):
        idx0 = i
        idx1 = 9  # Delta z = 1
        z1 = window_zvals[idx0, idx1, 0]
        z2 = window_zvals[idx0, idx1, 1]
        zvals[i] = (z1 + z2) / 2.0
        dl_ext = (
            ext_ell * (ext_ell + 1) * ext_cl[idx0, idx1, :]
            / (2 * np.pi)
        )
        dl_early = (
            early_ell * (early_ell + 1) * early_cl[idx0, idx1, :]
            / (2 * np.pi)
        )
        dl_short = (
            short_ell * (short_ell + 1) * short_cl[idx0, idx1, :]
            / (2 * np.pi)
        )
        dl_vals_ext[i] = np.interp(ell, ext_ell, dl_ext)
        dl_vals_early[i] = np.interp(ell, early_ell, dl_early)
        dl_vals_short[i] = np.interp(ell, short_ell, dl_short)

    # save to list for later use
    dl_ext_list.append(dl_vals_ext)
    dl_early_list.append(dl_vals_early)
    dl_short_list.append(dl_vals_short)

    # plot result
    line, = ax.plot(
        zvals,
        dl_vals_ext,
        linewidth=linewidth,
        alpha=alpha,
        color=f"C{iell}",
        linestyle="-",
    )
    lines.append(line)

    line, = ax.plot(
        zvals,
        dl_vals_early,
        linewidth=linewidth,
        alpha=alpha,
        color=f"C{iell}",
        linestyle="--",
    )
    lines.append(line)

    line, = ax.plot(
        zvals,
        dl_vals_short,
        linewidth=linewidth,
        alpha=alpha,
        color=f"C{iell}",
        linestyle=":",
    )
    lines.append(line)

# make plot pretty
ax.set_xlabel(r"$z_0$", fontsize=fontsize)
ax.set_ylabel(r"$\ell(\ell+1)C_\ell /2\pi$ [$\mu$K$^2$]", fontsize=fontsize)
lines = lines[::3] + lines[:3]
labels = [
    rf"$\ell={ells[0]}$",
    rf"$\ell={ells[1]}$",
    rf"$\ell={ells[2]}$",
    "Fiducial",
    "Early",
    "Short",
]
leg = ax.legend(lines, labels, loc=0, prop={"size": sm_fontsize}, ncol=2)
ax.tick_params(axis="both", labelsize=sm_fontsize)

plot_dir = datetime.date.today().strftime("%y%m%d")
plot_dir = os.path.join(out_dir, plot_dir)
if not os.path.isdir(plot_dir):
    os.makedirs(plot_dir)
output_fn = f"cl_kxg_of_z_multihist_{experiment}.pdf"
out_fn = os.path.join(plot_dir, output_fn)
print(f"saving {out_fn}...")
fig.savefig(out_fn, bbox_inches="tight", transparent=transparent)
plt.close(fig)


# do the same thing as a function of ionization fraction
xvals = np.linspace(0, 1, num=100)

# read in ionization histories for each type
pk_ext_fn = os.path.join(extended_dir, "output_0001", "pk_arrays.hdf5")
pk_early_fn = os.path.join(early_dir, "output_0001", "pk_arrays.hdf5")
pk_short_fn = os.path.join(short_dir, "output_0001", "pk_arrays.hdf5")

with h5py.File(pk_ext_fn, "r") as h5f:
    zvals_ext = h5f["data/zval_list"][()]
    xvals_ext = h5f["data/xval_list"][()]

with h5py.File(pk_early_fn, "r") as h5f:
    zvals_early = h5f["data/zval_list"][()]
    xvals_early = h5f["data/xval_list"][()]

with h5py.File(pk_short_fn, "r") as h5f:
    zvals_short = h5f["data/zval_list"][()]
    xvals_short = h5f["data/xval_list"][()]


# make a plot
fig = plt.figure()
ax = plt.gca()
ax.axhline(y=0.0, color=ax_color, linestyle="--")

lines = []

for iell, ell in enumerate(ells):
    dl_xvals_ext = np.zeros_like(xvals)
    dl_xvals_early = np.zeros_like(xvals)
    dl_xvals_short = np.zeros_like(xvals)

    for i, x in enumerate(xvals):
        # interpolate to get z value
        z_ext = np.interp(x, xvals_ext, zvals_ext)
        z_early = np.interp(x, xvals_early, zvals_early)
        z_short = np.interp(x, xvals_short, zvals_short)

        # now interpolate to get C_l
        dl_xvals_ext[i] = np.interp(z_ext, zvals, dl_ext_list[iell])
        dl_xvals_early[i] = np.interp(z_early, zvals, dl_early_list[iell])
        dl_xvals_short[i] = np.interp(z_short, zvals, dl_short_list[iell])

    # plot result
    # we actually plot the ionization fraction, rather than neutral fraction
    line, = ax.plot(
        1 - xvals,
        dl_xvals_ext,
        linewidth=linewidth,
        alpha=alpha,
        color=f"C{iell}",
        linestyle="-",
    )
    lines.append(line)

    line, = ax.plot(
        1 - xvals,
        dl_xvals_early,
        linewidth=linewidth,
        alpha=alpha,
        color=f"C{iell}",
        linestyle="--",
    )
    lines.append(line)

    line, = ax.plot(
        1 - xvals,
        dl_xvals_short,
        linewidth=linewidth,
        alpha=alpha,
        color=f"C{iell}",
        linestyle=":",
    )
    lines.append(line)

# make plot pretty
ax.set_xlim(ax.get_xlim()[::-1])
ax.set_xlabel(r"$x_\mathrm{HII}$", fontsize=fontsize)
ax.set_ylabel(r"$\ell(\ell+1)C_\ell/2\pi$ [$\mu$K$^2$]", fontsize=fontsize)
lines = lines[::3] + lines[:3]
labels = [
    rf"$\ell={ells[0]}$",
    rf"$\ell={ells[1]}$",
    rf"$\ell={ells[2]}$",
    "Fiducial",
    "Early",
    "Short",
]
leg = ax.legend(lines, labels, loc=0, prop={"size": sm_fontsize}, ncol=2)
ax.tick_params(axis="both", labelsize=sm_fontsize)

plot_dir = datetime.date.today().strftime("%y%m%d")
plot_dir = os.path.join(out_dir, plot_dir)
if not os.path.isdir(plot_dir):
    os.makedirs(plot_dir)
output_fn = f"cl_kxg_of_z_multihist_ion_{experiment}.pdf"
out_fn = os.path.join(plot_dir, output_fn)
print(f"saving {out_fn}...")
fig.savefig(out_fn, bbox_inches="tight", transparent=transparent)
plt.close(fig)
