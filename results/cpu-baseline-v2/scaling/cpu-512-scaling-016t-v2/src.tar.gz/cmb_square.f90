program main
  ! Intel
  use IFPORT
  use OMP_LIB

  ! Global
  use global

  ! Tools
  use io_tools
  use cosmo_tools
  use field_tools

  ! Default
  implicit none

  ! Parameters
  character(*), parameter :: fn_cmb_in  = &
       "/jet/home/plaplant/scratch_ml/ksz/cmb_maps/cmb_projection_v2.hdf5"
  character(*), parameter :: fn_cmb_out  = "cmb_estimate.txt"
  character(*), parameter :: fn_cmb2_out = "cmb_squared.txt"

  ! Variables
  integer(4) :: ifield,Nfields

  ! Arrays
  real(8), dimension(:,:,:), allocatable :: cmb_fields,cl_cmb,cl_cmb2

  ! Initialize
  call OMP_SET_NUM_THREADS(N_cpu)
  call init_small_fields

  ! Read in cmb spectra
  call read_cmb_fields(fn_cmb_in,cmb_fields,Nfields)

  ! Initialize
  allocate(cl_cmb( 3,N_grid,Nfields))
  allocate(cl_cmb2(3,N_grid,Nfields))
  cl_cmb  = 0
  cl_cmb2 = 0

  ! Do work
  do ifield=1,Nfields
     call calc_cl_spectrum(cmb_fields(:,:,ifield),cmb_fields(:,:,ifield),&
          cl_gal,.false.,.false.)
     cl_cmb(:,:,ifield) = cl_gal
     call calc_cl_spectrum(cmb_fields(:,:,ifield),cmb_fields(:,:,ifield),&
          cl_ksz,.true.,.true.)
     cl_cmb2(:,:,ifield) = cl_ksz
  enddo

  call average_spectrum
  call write_cmb_spectrum(fn_cmb_out,cl_gal)
  call write_cmb_spectrum(fn_cmb2_out,cl_ksz)


contains


  subroutine average_spectrum
    ! Default
    implicit none


    ! Local variables
    integer(4) :: i


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Average over spectra
    cl_ksz = 0
    do i=1,Nfields
       if (i==1) then
          cl_gal(1,:) = cl_cmb(1,:,1)
          cl_ksz(1,:) = cl_cmb2(1,:,1)
       endif
       cl_gal(2,:) = cl_gal(2,:) + cl_cmb(2,:,i)
       cl_gal(3,:) = cl_gal(3,:) + cl_cmb(2,:,i)**2

       cl_ksz(2,:) = cl_ksz(2,:) + cl_cmb2(2,:,i)
       cl_ksz(3,:) = cl_ksz(3,:) + cl_cmb2(2,:,i)**2
    enddo

    ! Compute average
    cl_gal(2,:) = cl_gal(2,:)/Nfields
    cl_gal(3,:) = sqrt(cl_gal(3,:)/(Nfields-1) - cl_gal(2,:)**2)

    cl_ksz(2,:) = cl_ksz(2,:)/Nfields
    cl_ksz(3,:) = sqrt(cl_ksz(3,:)/(Nfields-1) - cl_ksz(2,:)**2)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called average spectrum'
    return
  end subroutine average_spectrum


!------------------------------------------------------------------------------!


  subroutine write_cmb_spectrum(fn,cl)
    ! Default
    implicit none


    ! Subroutine arguments
    character(*) :: fn
    real(8), dimension(3,N_grid) :: cl


    ! Local variables
    integer(4) :: i


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Write out spectrum
    write(*,*) "Writing ",trim(fn)
    open(11,file=fn)
    do i=1,N_grid/2
       write(11,"(3es16.8)") cl(:,i)
    enddo
    close(11)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called write cmb spectrum'
    return
  end subroutine write_cmb_spectrum


end program main
