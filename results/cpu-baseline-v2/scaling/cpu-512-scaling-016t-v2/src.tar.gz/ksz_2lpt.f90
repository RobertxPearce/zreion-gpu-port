program main
  ! Intel
  use IFPORT
  use OMP_LIB


  ! Variables
  use global


  ! Tools
  use cosmo_tools
  use domain_tools
  use rng_tools
  use field_tools
  use io_tools
  use zreion_tools
  use checkpoint_tools


  ! Default
  implicit none


  ! Initialize
  write(*,*) "Num cpu avail: ",OMP_GET_NUM_PROCS()
  call OMP_SET_NUM_THREADS(N_cpu)
  call process_args
  call init_dm
  call init_domain
  call calc_cosmo_distance
  call calc_angular_distance
  if (use_bt) then
     call read_bt
  endif

  ! Need to initialize fields *after* we figure out how many pixels long the
  ! sightlines are
  call calc_Nsightpix
  call init_fields

  ! Do work
  call calc_linear_power_spectrum

  do isim=1,N_sims
     write(*,*)
     write(*,*)
     write(*,*) "Iteration ",isim," of ",N_sims

     call ckpt_open

     ! Generate initial conditions
     if (read_grf) then
        call read_gaussian_random_field
     else
        call make_gaussian_random_field
     endif
     ! The initial field lives in grf.hdf5, not in the checkpoint file -- it is
     ! the same array, and writing 8 GB of it twice at N=1024 helps nobody.
     call write_gaussian_random_field

     call calc_delta_field
     call ckpt_kspace('calc_delta_field','delta1_k',delta1,Ndm,Ndm,Ndm)

     ! Do rest of work
     call calc_zreion
     call calc_tau
     call calc_ksz_t21_fields
     call ckpt_map('calc_ksz_t21_fields','ksz_map',ksz_map,N_grid,N_grid)
     call ckpt_map('calc_ksz_t21_fields','tau_map',tau_map,N_grid,N_grid)
     call ckpt_map('calc_ksz_t21_fields','t21_map',t21_map,N_grid,N_grid)
     call ckpt_map('calc_ksz_t21_fields','gal_map',gal_map,N_grid,N_grid)

     ! Write out observables
     call write_fields
     if (calc_pk) then
        call write_pk
     endif

     call ckpt_close
  enddo

  call close_h5


contains


  subroutine process_args
    ! Default
    implicit none


    ! Local variables
    integer(4)      :: i,nargs,iflag
    character(1000) :: arg


    ! Set defaults
    dir_out   = dir_out0
    zmean_zre = zmean_zre0
    alpha_zre = alpha_zre0
    kb_zre    = kb_zre0
    b0_zre    = b0_zre0

    ! Iterate through arguments
    nargs = command_argument_count()
    if (nargs > 0) then
       do i=1,nargs
          call get_command_argument(i, arg)
          select case(i)
          case(1)
             dir_out = arg
          case(2)
             read(arg,*) zmean_zre
          case(3)
             read(arg,*) alpha_zre
          case(4)
             read(arg,*) kb_zre
          case(5)
             read(arg,*) b0_zre
          case(6)
             ! 0 draws a fresh seed from system entropy; anything else replays
             ! that realization exactly.
             read(arg,*) iseed_run
          case(7)
             read(arg,*) iflag
             save_grf = (iflag /= 0)
          case(8)
             read(arg,*) iflag
             read_grf = (iflag /= 0)
          case(9)
             read(arg,*) checkpoint_level
          end select
       enddo
    endif

    write(*,*) "dir_out:   ", trim(dir_out)
    write(*,*) "zmean_zre: ", zmean_zre
    write(*,*) "alpha_zre: ", alpha_zre
    write(*,*) "kb_zre:    ", kb_zre
    write(*,*) "b0_zre:    ", b0_zre
    write(*,*) "iseed:     ", iseed_run
    write(*,*) "save_grf:  ", save_grf
    write(*,*) "read_grf:  ", read_grf
    write(*,*) "ckpt_level:", checkpoint_level

    ! read_grf loads dir_out/grf.hdf5; save_grf would then overwrite the file it
    ! was just read from, which is at best pointless and at worst destructive.
    if (read_grf .and. save_grf) then
       write(*,*) "process_args: read_grf and save_grf are mutually exclusive"
       stop 1
    endif

    return
  end subroutine process_args


end program main
