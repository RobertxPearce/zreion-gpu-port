program main
  ! Intel
  use IFPORT
  use OMP_LIB


  ! HDF5
  use ISO_C_BINDING
  use HDF5


  ! Tools
  use general_tools, only: interpolate, bin_cl


  ! Default
  implicit none


  !! Parameters
  ! Computation and constants
  integer(4), parameter :: N_cpu = 4
  real(8),    parameter :: pi    = acos(-1D0)


  ! I/O
  integer(4),   parameter :: N_sims    = 30
  character(*), parameter :: dir_short = &
       "/jet/home/plaplant/scratch_ml/ksz/fiducial/bt_bias/"
  character(*), parameter :: dir_early = &
       "/ocean/projects/ast180004p/jsipple/ksz/early_output/"
  character(*), parameter :: dir_ext   = &
       ! "/ocean/projects/ast180004p/jsipple/ksz/extended_output/"
       "/jet/home/plaplant/scratch_ml/ksz/jackson_extended/"
  character(*), parameter :: dir_out_short = &
       "/jet/home/plaplant/scratch_ml/ksz/paul_short/"
  character(*), parameter :: dir_out_early = &
       "/jet/home/plaplant/scratch_ml/ksz/jackson_early/"
  character(*), parameter :: dir_out_ext   = &
       "/jet/home/plaplant/scratch_ml/ksz/jackson_extended/"

  character(*), parameter :: hist     = "ext"  ! "ext", "early", "short"
  character(*), parameter :: expt     = "so"   ! "so, "s4", "hd"
  character(*), parameter :: noise    = "" ! "_ilc", "" (naive noise)
  character(*), parameter :: fn_clw   = &
       "cl_arrays_window_"//expt//noise//".hdf5"
  character(*), parameter :: fn_conv  = &
       "data/cl_t2t2_"//hist//"_"//expt//noise//".txt"
  character(*), parameter :: fn_out   = &
       "snr_"//hist//"_"//expt//noise//"_wide_z_nosn.hdf5"
  character(*), parameter :: fn_hls   = "data/hls_gal.txt"
  character(*), parameter :: fn_btl   = "data/dndz_low.txt"
  character(*), parameter :: fn_bth   = "data/dndz_high.txt"
  logical,      parameter :: use_t2t2 = .true.
  logical,      parameter :: use_sn   = .false.
  logical,      parameter :: use_hls  = .false.


  ! Survery parameters
  real(8),    parameter :: area_dsq = 2200
  real(8),    parameter :: rad2deg  = 180d0/pi
  !real(8),    parameter :: f_sky    = 0.05  ! ~2063 deg^2
  real(8),    parameter :: f_sky    = area_dsq/(4*pi*rad2deg**2)
  integer(4), parameter :: ell_min  = 100
  integer(4), parameter :: ell_max  = 10000
  integer(4), parameter :: N_ell    = ell_max-ell_min
  logical,    parameter :: rebin_cl = .true.
  logical,    parameter :: fixed_N  = .false.


  !! Variables
  integer(4)      :: Nmid,Nwidth
  character(1000) :: dir,dir_out


  !! Arrays
  real(8), dimension(:,:),       allocatable :: cl_t2t2,snr,hls_gal,btl,bth
  real(8), dimension(:,:,:),     allocatable :: window_zvals
  real(8), dimension(:,:,:,:),   allocatable :: snr_by_ell
  real(8), dimension(:,:,:,:,:), allocatable :: cl_gal,cl_kxg,cl_ks2


  ! Initialize
  call OMP_SET_NUM_THREADS(N_cpu)
  select case(hist)
  case("ext")
     ! Extended = Fiducial
     dir     = dir_ext
     dir_out = dir_out_ext
  case("early")
     dir     = dir_early
     dir_out = dir_out_early
  case("short")
     dir     = dir_short
     dir_out = dir_out_short
  end select

  ! Read in spectra
  if (use_t2t2) then
     call read_cl_t2t2
  endif
  if (use_sn) then
     if (use_hls) then
        call read_hls_gal
     else
        call read_bt
     endif
  endif
  call read_cl_windows

  ! Do work
  call calc_snr


  ! Write out answer
  call write_snr


contains


  subroutine read_cl_t2t2
    ! Default
    implicit none


    ! Local variables
    integer(4) :: un,i,nrows
    real(8)    :: ell,cl


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Read in data
    un = 11
    write(*,*) "Reading ",trim(fn_conv)
    open(un,file=fn_conv)
    nrows = 0
    do
       read(un,*,end=1) ell,cl
       nrows = nrows + 1
    enddo
1   continue

    ! Allocate arrays
    allocate(cl_t2t2(2,nrows))
    cl_t2t2 = 0

    ! Read in data for real now
    rewind(un)
    do i=1,nrows
       read(un,*) ell,cl
       cl_t2t2(1,i) = ell
       cl_t2t2(2,i) = cl
    enddo
    close(un)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called read cl_t2t2'
    return
  end subroutine read_cl_t2t2


!------------------------------------------------------------------------------!


  subroutine read_hls_gal
    ! Default
    implicit none


    ! Local variables
    integer(4) :: un,i,nrows
    real(8)    :: z,ngal


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Read in data
    un = 11
    write(*,*) "Reading ",trim(fn_hls)
    open(un,file=fn_hls)
    nrows = 0
    do
       read(un,*,end=2) z,ngal
       nrows = nrows + 1
    enddo
2   continue

    ! Allocate arrays
    allocate(hls_gal(2,nrows))
    hls_gal = 0

    ! Read in data for real now
    rewind(un)
    do i=1,nrows
       read(un,*) z,ngal
       hls_gal(1,i) = z
       hls_gal(2,i) = ngal
    enddo
    close(un)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called read hls gal'
    return
  end subroutine read_hls_gal


!------------------------------------------------------------------------------!


  subroutine read_bt
    ! Default
    implicit none


    ! Local variables
    integer(4) :: un,i,nrows
    real(8)    :: z,dndz


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Read in data
    un = 12
    write(*,*) "Reading ",fn_btl
    open(un,file=fn_btl)
    nrows = 0
    do
       read(un,*,end=3) z,dndz
       nrows = nrows + 1
    enddo
3   continue
    allocate(btl(2,nrows))
    rewind(un)
    do i=1,nrows
       read(un,*) z,dndz
       btl(1,i) = z
       btl(2,i) = log(abs(dndz))  ! convert to positive dn/dz, take log
    enddo
    close(un)

    un = 13
    write(*,*) "Reading ",fn_bth
    open(un,file=fn_bth)
    nrows = 0
    do
       read(un,*,end=4) z,dndz
       nrows = nrows + 1
    enddo
4   continue
    allocate(bth(2,nrows))
    rewind(un)
    do i=1,nrows
       read(un,*) z,dndz
       bth(1,i) = z
       bth(2,i) = log(abs(dndz))
    enddo
    close(un)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called read bt'
    return
  end subroutine read_bt


!------------------------------------------------------------------------------!


  subroutine read_cl_windows
    ! Default
    implicit none


    ! Local variables
    character(1000)  :: dir_sim,fn
    integer(4)       :: error,isim
    real(8)          :: tcmb
    integer(HID_T)   :: file_id,dset_id,dspace_id,dset_id2
    integer(HSIZE_T) :: dims(4),maxdims(4),dims1(1),dims3(3)
    real(8), dimension(:,:,:,:), allocatable :: io_array


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Initialize
    call h5open_f(error)

    do isim=1,N_sims
       if (isim < 10) then
          write(dir_sim,"(a,i1,a)") "output_000",isim,"/"
       else if (isim < 100) then
          write(dir_sim,"(a,i2,a)") "output_00" ,isim,"/"
       else if (isim < 1000) then
          write(dir_sim,"(a,i3,a)") "output_0"  ,isim,"/"
       else
          write(dir_sim,"(a,i4,a)") "output_"   ,isim,"/"
       endif
       dir_sim = trim(dir)//trim(dir_sim)
       fn      = trim(dir_sim)//fn_clw

       write(*,*) "Reading ",trim(fn)

       call h5fopen_f(fn, H5F_ACC_RDONLY_F, file_id, error)

       call h5dopen_f(file_id, "data/cl_kxg", dset_id, error)
       if (isim == 1) then
          ! First time through, we need to get the size of things and allocate
          call h5dget_space_f(dset_id, dspace_id, error)
          call h5sget_simple_extent_dims_f(dspace_id, dims, maxdims, error)
          if (dims(1) /= 3) then
             write(*,*) "First dimension expected to be 3, got ",dims(1)
             stop
          endif
          if (dims(2) /= 512) then
             write(*,*) "Second dimension expected to be 512, got ",dims(2)
             stop
          endif
          Nwidth = dims(3)
          Nmid   = dims(4)
          allocate(cl_gal(3,512,Nwidth,Nmid,N_sims))
          allocate(cl_kxg(3,512,Nwidth,Nmid,N_sims))
          allocate(io_array(3,512,Nwidth,Nmid))
          allocate(snr(Nwidth,Nmid))
          allocate(snr_by_ell(2,N_ell,Nwidth,Nmid))
          if (.not. use_t2t2) then
             allocate(cl_ks2(3,512,Nwidth,Nmid,N_sims))
             cl_ks2 = 0
          endif
          cl_gal     = 0
          cl_kxg     = 0
          snr        = 0
          snr_by_ell = 0
          call h5sclose_f(dspace_id, error)

          ! Also need to get Tcmb0
          dims1 = (/ 1 /)
          call h5dopen_f(file_id, "header/Tcmb0", dset_id2, error)
          call h5dread_f(dset_id2, H5T_NATIVE_DOUBLE, tcmb, dims1, error)
          call h5dclose_f(dset_id2, error)

          ! Get window values for good measure
          allocate(window_zvals(2, Nwidth, Nmid))
          dims3 = (/ 2, Nwidth, Nmid /)
          call h5dopen_f(file_id, "data/window_zvals", dset_id2, error)
          call h5dread_f(dset_id2, H5T_NATIVE_DOUBLE, window_zvals, dims3, &
               error)
          call h5dclose_f(dset_id2, error)
       endif
       call h5dread_f(dset_id, H5T_NATIVE_DOUBLE, io_array, dims, error)
       call h5dclose_f(dset_id, error)

       ! Need to add temperature factors to put in uK^2
       cl_kxg(  1,:,:,:,isim) = io_array(  1,:,:,:)
       cl_kxg(2:3,:,:,:,isim) = io_array(2:3,:,:,:) * (1d6*tcmb)**2

       call h5dopen_f(file_id, "data/cl_gal", dset_id, error)
       call h5dread_f(dset_id, H5T_NATIVE_DOUBLE, io_array, dims, error)
       call h5dclose_f(dset_id, error)
       cl_gal(:,:,:,:,isim) = io_array

       if (.not. use_t2t2) then
          call h5dopen_f(file_id, "data/cl_ks2", dset_id, error)
          call h5dread_f(dset_id, H5T_NATIVE_DOUBLE, io_array, dims, error)
          call h5dclose_f(dset_id, error)
          cl_ks2(  1,:,:,:,isim) = io_array(  1,:,:,:)
          cl_ks2(2:3,:,:,:,isim) = io_array(2:3,:,:,:) * (1d6*tcmb)**4
       endif

       ! close file
       call h5fclose_f(file_id, error)
    enddo

    ! Close out
    call h5close_f(error)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called read cl windows'
    return
  end subroutine read_cl_windows


!------------------------------------------------------------------------------!


  pure function calc_ngal(z1,z2)
    ! Default
    implicit none


    ! Function parameters
    integer(4), parameter :: N_z = 10000


    ! Function arguments
    real(8), intent(in) :: z1,z2
    real(8)             :: calc_ngal


    ! Local variables
    integer(4) :: i
    real(8)    :: z,d1,d2,dm,ng,dz


    ! Integrate dn/dz between z1 and z2
    ! Use geometric mean of high and low bands
    ng = 0
    dz = (z2 - z1)/N_z
    do i=1,N_z
       z  = z1 + (i-0.5)*dz
       d1 = interpolate(z,btl,1,2,'lin')
       d2 = interpolate(z,bth,1,2,'lin')
       dm = exp((d1+d2)/2)  ! compute geometric mean, return to real space
       ng = ng + dm
    enddo
    calc_ngal = ng*dz

    return
  end function calc_ngal


!------------------------------------------------------------------------------!


  subroutine calc_snr
    ! Default
    implicit none


    ! Local variables
    integer(4) :: iell,isim,iwidth,imid,idx(2)
    real(8)    :: ell,cgg,ctt,ckg,s,tot,zval,ngal,sn,dz,z1,z2
    real(8), dimension(:,:), allocatable :: clg,clk,cl2
    real(8), dimension(:,:), allocatable :: clg_r,clk_r,cl2_r


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Loop over windows
    do imid=1,Nmid
       do iwidth=1,Nwidth
          ! Reinitialize
          if (allocated(clg)) then
             deallocate(clg)
             deallocate(clk)
             if (.not. use_t2t2) then
                deallocate(cl2)
             endif
          endif

          allocate(clg(2,512))
          allocate(clk(2,512))
          if (.not. use_t2t2) then
             allocate(cl2(2,512))
             cl2 = 0
          endif
          clg = 0
          clk = 0

          ! Average spectrum over independent realizations
          do isim=1,N_sims
             clg = clg + cl_gal(:2,:,iwidth,imid,isim)
             clk = clk + cl_kxg(:2,:,iwidth,imid,isim)
             if (.not. use_t2t2) then
                cl2 = cl2 + cl_ks2(:2,:,iwidth,imid,isim)
             endif
          enddo
          clg = clg / dble(N_sims)
          clk = clk / dble(N_sims)
          if (.not. use_t2t2) then
             cl2 = cl2 / dble(N_sims)
          endif

          if (rebin_cl) then
             if (allocated(clg_r)) then
                deallocate(clg_r)
                deallocate(clk_r)
                if (.not. use_t2t2) then
                   deallocate(cl2_r)
                endif
             endif

             call bin_cl(clg(1,:),clg(2,:),.true.,0.2D0,clg_r)
             deallocate(clg)
             allocate(clg(2,size(clg_r,dim=2)))
             clg = clg_r

             call bin_cl(clk(1,:),clk(2,:),.true.,0.2D0,clk_r)
             deallocate(clk)
             allocate(clk(2,size(clk_r,dim=2)))
             clk = clk_r

             if (.not. use_t2t2) then
                call bin_cl(cl2(1,:),cl2(2,:),.true.,0.2D0,cl2_r)
                deallocate(cl2)
                allocate(cl2(2,size(cl2_r,dim=2)))
                cl2 = cl2_r
             endif
          endif

          ! Add shot-noise for galaxies if desired
          if (use_sn) then
             z1 = window_zvals(1,iwidth,imid)
             z2 = window_zvals(2,iwidth,imid)
             if (use_hls) then
                zval = (z1+z2)/2d0
                dz   = z2 - z1
                ngal = max(interpolate(zval,hls_gal,1,2,'lin'),1D0) * (dz / 1d0)
             else
                ngal = max(calc_ngal(z1,z2),1D0)
             endif
             if (fixed_N) then
                ! Assume fixed number observed over larger area
                sn = 4*pi*f_sky/ngal
             else
                ! Assume we have same number density over larger area
                sn = 2200/rad2deg**2/ngal
             endif
             clg(2,:) = clg(2,:) + sn
          endif

          ! Compute the total signal to noise
          ! Do the sum in serial b/c we're writing out the answer ell-by-ell
          s = 0
          do iell=ell_min,ell_max
             ell = iell
             cgg = interpolate(ell,clg,1,2,'lin')
             if (use_t2t2) then
                ctt = interpolate(ell,cl_t2t2,1,2,'lin')
             else
                ctt = interpolate(ell,cl2,1,2,'lin')
             endif
             ckg = interpolate(ell,clk,1,2,'lin')
             tot = (2*ell + 1)*ckg**2 / (ctt*cgg + ckg**2)
             s   = s + f_sky*tot
             if (iell > ell_min) then
                snr_by_ell(1,iell-ell_min,iwidth,imid) = ell
                snr_by_ell(2,iell-ell_min,iwidth,imid) = 1D0/sqrt(s)
             endif
          enddo

          ! Save in main array
          snr(iwidth,imid) = 1D0/sqrt(s)

          ! Echo out for user
          if (.false.) then
             write(*,"(a,2f8.3)") "window extent: ",window_zvals(:,iwidth,imid)
             write(*,"(a,f8.3)") "snr: ",1D0/snr(iwidth,imid)
          endif
       enddo
    enddo

    write(*,*) "max snr: ",1D0/minval(snr)
    idx = minloc(snr)
    write(*,*) "window values: ",window_zvals(:,idx(1),idx(2))


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called calc_snr'
    return
  end subroutine calc_snr


!------------------------------------------------------------------------------!


  subroutine write_snr
    ! Default
    implicit none


    ! Local variables
    character(1000)  :: fn
    integer(4)       :: error
    integer(HID_T)   :: file_id,dset_id,dspace_id
    integer(HSIZE_T) :: dims2(2),dims4(4)


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Initialize
    fn = trim(dir_out)//fn_out
    write(*,*) "Writing ",trim(fn)
    call h5open_f(error)
    call h5fcreate_f(trim(fn), H5F_ACC_TRUNC_F, file_id, error)

    ! Create dataset
    dims2 = (/ Nwidth, Nmid /)
    call h5screate_simple_f(2, dims2, dspace_id, error)
    call h5dcreate_f(file_id, "snr", H5T_NATIVE_DOUBLE, dspace_id, dset_id, &
         error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, snr, dims2, error)
    call h5dclose_f(dset_id, error)
    call h5sclose_f(dspace_id, error)

    ! Write out ell-by-ell answer
    dims4 = (/ 2, N_ell, Nwidth, Nmid /)
    call h5screate_simple_f(4, dims4, dspace_id, error)
    call h5dcreate_f(file_id, "snr_by_ell", H5T_NATIVE_DOUBLE, dspace_id, &
         dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, snr_by_ell, dims4, error)
    call h5dclose_f(dset_id, error)
    call h5sclose_f(dspace_id, error)

    ! Close out
    call h5fclose_f(file_id, error)
    call h5close_f(error)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called write snr'
    return
  end subroutine write_snr


end program main
