# -*- coding: utf-8 -*-

import os
import datetime
import h5py
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

dark_background = False
if dark_background:
    plt.style.use("dark_background")
    transparent = True
    ax_color = "w"
else:
    transparent = False
    ax_color = "k"

fontsize = 20
sm_fontsize = 14

input_dir = "/jet/home/plaplant/scratch_ml/ksz/jackson_extended/"

filename_fixed_n = [
    "snr_ext_s4_ilc.hdf5",
    "snr_ext_s4_ilc_fsky_4400.hdf5",
    "snr_ext_s4_ilc_fsky_6600.hdf5",
    "snr_ext_s4_ilc_fsky_8800.hdf5",
    "snr_ext_s4_ilc_fsky_22000.hdf5",
    "snr_ext_s4_ilc_fsky_40000.hdf5",
]

filename_unfixed_n = [
    "snr_ext_s4_ilc_fsky_2200_unfixed.hdf5",
    "snr_ext_s4_ilc_fsky_4400_unfixed.hdf5",
    "snr_ext_s4_ilc_fsky_6600_unfixed.hdf5",
    "snr_ext_s4_ilc_fsky_8800_unfixed.hdf5",
    "snr_ext_s4_ilc_fsky_22000_unfixed.hdf5",
    "snr_ext_s4_ilc_fsky_40000_unfixed.hdf5",
]

degsq = np.array(
    [
        2200,
        4400,
        6600,
        8800,
        22000,
        40000,
    ],
    dtype=np.float64,
)

snr = np.zeros_like(degsq)
snr_unfixed = np.zeros_like(degsq)

for idx, fn in enumerate(filename_fixed_n):
    total_fn = os.path.join(input_dir, fn)
    with h5py.File(total_fn, "r") as h5f:
        snr[idx] = 1.0 / np.amin(h5f["snr"][()])

    # get unfixed results as well
    total_fn = os.path.join(input_dir, filename_unfixed_n[idx])
    with h5py.File(total_fn, "r") as h5f:
        snr_unfixed[idx] = 1.0 / np.amin(h5f["snr"][()])

# plot the result
matplotlib.rc("text", usetex=True)
matplotlib.rc("font", family="serif")

fig = plt.figure()
ax = plt.gca()

# convert from degsq -> f_sky
amin2deg = 180.0 / np.pi
fsky = degsq / (4 * np.pi * amin2deg**2)

# add guide line for HLS area
ax.axvline(x=fsky[0], color=ax_color, linestyle="--")
ax.text(
    fsky[0] + 0.01,
    7.5,
    "HLS Survey Area",
    rotation=90,
    color=ax_color,
    fontsize=sm_fontsize,
)

# plot values
ax.plot(fsky, snr, label="Fixed Number Count")

# plot other value
ax.plot(fsky, snr_unfixed, linestyle="--", label="Fixed Number Density")

ax.set_xlabel(r"$f_\mathrm{sky}$", fontsize=fontsize)
ax.set_ylabel(r"S/N", fontsize=fontsize)
ax.tick_params(axis="both", labelsize=sm_fontsize)
ax.legend(loc=0, prop={"size": sm_fontsize})

# save figure
date = datetime.date.today().strftime("%y%m%d")
plots_dir = os.path.join(input_dir, "plots", date)
if not os.path.isdir(plots_dir):
    os.makedirs(plots_dir)
output_fn = os.path.join(plots_dir, "snr_shotnoise.pdf")
print(f"saving {output_fn}...")
fig.savefig(output_fn, bbox_inches="tight", transparent=transparent)
plt.close(fig)
