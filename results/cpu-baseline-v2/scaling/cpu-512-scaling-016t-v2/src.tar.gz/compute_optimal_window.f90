program main
  ! Intel
  use IFPORT
  use OMP_LIB


  ! HDF5
  use ISO_C_BINDING
  use HDF5


  ! Tools
  use general_tools, only : interpolate


  ! Default
  implicit none


  ! Parameters
  real(8), parameter :: pi       = acos(-1D0)
  real(8), parameter :: Mpc2cm   = 3.08560D+24
  real(8), parameter :: H0_cgs   = 3.24086D-18
  real(8), parameter :: c_cgs    = 2.99792D+10
  real(8), parameter :: sT_cgs   = 6.65246D-25
  real(8), parameter :: rhoc_cgs = 1.87890D-29
  real(8), parameter :: mH_cgs   = 1.67223D-24
  real(8), parameter :: omegam   = 0.315823D0
  real(8), parameter :: omegal   = 1-omegam
  real(8), parameter :: omegab   = 0.049387D0
  real(8), parameter :: hubble0  = 0.673212D0
  real(8), parameter :: wde      = -1.0D0
  real(8), parameter :: Tcmb0    = 2.7255D0
  real(8), parameter :: omegar   = 4.48D-7*(1+0.69D0)*Tcmb0**4/hubble0**2
  real(8), parameter :: YHe      = 0.245401D0

  character(*), parameter :: dir_pk = &
       "/jet/home/plaplant/scratch/Nbody/L2000_NP2048_nbody_Planck2018/Pk/"
  character(*), parameter :: fn_pk  = "pk_lin.txt"
  character(*), parameter :: dir_xvals = &
       "/jet/home/plaplant/scratch_ml/ksz/fiducial/output_0001/"
  character(*), parameter :: fn_xvals  = "pk_arrays.hdf5"


  ! Variables
  real(8) :: pk_integral


  ! Arrays
  real(8), dimension(:,:), allocatable :: pk_lin,xvals


  ! Do work
  call read_pk_lin
  call read_xvals
  call calc_pk_integral
  call write_vrms
  call write_window


contains


  subroutine read_pk_lin
    ! Default
    implicit none


    !  Local variables
    character(1000) :: fn
    real(8)         :: vals(5)
    integer(4)      :: i,Nk,un


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Open file
    un = 11
    fn = dir_pk//fn_pk
    write(*,*) "Reading ",trim(fn)
    open(un,file=trim(fn))
    i = 0
    do
       ! Find number of records
       read(un,*,end=1) vals

       i = i + 1
    enddo
1   continue
    Nk = i

    ! Allocate array
    allocate(pk_lin(3,Nk))
    pk_lin = 0

    ! Read in values now
    rewind(un)
    do i=1,Nk
       read(un,*) vals
       pk_lin(1,i) = vals(1)
       pk_lin(2,i) = vals(2)
       pk_lin(3,i) = vals(5)
    enddo

    ! Close the file
    close(un)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called read pk lin'
    return
  end subroutine read_pk_lin


  subroutine read_xvals
    ! Default
    implicit none


    ! Local variables
    character(1000 ) :: fn
    integer(4)       :: error,Nvals
    integer(HID_T)   :: dset_id,file_id,dspace_id
    integer(HSIZE_T) :: dims(1),maxdims(1)
    real(8), dimension(:), allocatable :: io_array


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Read in file
    fn = dir_xvals//fn_xvals
    write(*,*) "Reading ",trim(fn)
    call h5open_f(error)
    call h5fopen_f(fn, H5F_ACC_RDONLY_F, file_id, error)

    ! Get the zvals dataset
    call h5dopen_f(file_id, "/data/zval_list", dset_id, error)
    call h5dget_space_f(dset_id, dspace_id, error)
    call h5sget_simple_extent_dims_f(dspace_id, dims, maxdims, error)
    Nvals = dims(1)
    allocate(io_array(Nvals))
    allocate(xvals(2,Nvals))
    io_array = 0
    xvals    = 0
    call h5dread_f(dset_id, H5T_NATIVE_DOUBLE, io_array, dims, error)
    xvals(1,:) = io_array
    call h5sclose_f(dspace_id, error)
    call h5dclose_f(dset_id, error)

    call h5dopen_f(file_id, "/data/xval_list", dset_id, error)
    call h5dread_f(dset_id, H5T_NATIVE_DOUBLE, io_array, dims, error)
    xvals(2,:) = io_array
    call h5dclose_f(dset_id, error)

    ! Close out
    call h5fclose_f(file_id, error)
    call h5close_f(error)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called read xvals'
    return
  end subroutine read_xvals


  subroutine calc_pk_integral
    ! Default
    implicit none


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Compute integral
    ! Convert from Delta^2(k) -> P(k)
    pk_lin(3,:) = pk_lin(3,:) * (2*pi**2) / pk_lin(1,:)**3

    ! Compute sum(dk * P(k))
    pk_integral = dot_product(pk_lin(2,:),pk_lin(3,:)) / (2*pi**2)

    ! Convert units to km/s
    pk_integral = sqrt(pk_integral) * Mpc2cm / hubble0 / 1e5


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called calc pk integral'
    return
  end subroutine calc_pk_integral


  pure function D_of_z(z)
    ! Default
    implicit none


    ! Local parameters
    real(8), parameter :: w   = wde
    real(8), parameter :: om  = omegam
    real(8), parameter :: ol  = omegal
    real(8), parameter :: or  = omegar
    real(8), parameter :: aeq = or/om


    ! Function arguments
    real(8), intent(in) :: z
    real(8)             :: D_of_z(2)


    ! Local variables
    real(8) :: a,ah,aw,af,H,q,c0,c1
    real(8) :: da,D,Dh,dDda,dDdah


    af   = 1/(1+z)
    a    = max(aeq,1D-6)
    D    = a + 2./3*aeq
    dDda = 1
    do while (a < af)
       da    = min(max(af-a,1D-8),1D-6)

       aw    = a**(3*(1+w))
       H     = sqrt(om/a**3+or/a**4+ol/aw)
       q     = (om/a**3+2*or/a**4-2*ol/aw)/H**2/2
       c0    = -1.5*om/H**2/a**5
       c1    = (2-q)/a
       Dh    = D + dDda*da/2
       dDdah = dDda - (c1*dDda+c0*D)*da/2
       ah    = a + da/2

       aw    = ah**(3*(1+w))
       H     = sqrt(om/ah**3+or/ah**4+ol/aw)
       q     = (om/ah**3+2*or/ah**4-2*ol/aw)/H**2/2
       c0    = -1.5*om/H**2/ah**5
       c0    = -1.5*om/H**2/ah**5
       c1    = (2-q)/ah
       D     = D + dDdah*da
       dDda  = dDda - (c1*dDdah+c0*Dh)*da
       a     = a + da
    enddo

    D_of_z(1) = D
    D_of_z(2) = dDda*a/D

    do while (a < 1)
       da    = min(max(1-a,1D-8),1D-6)

       aw    = a**(3*(1+w))
       H     = sqrt(om/a**3+or/a**4+ol/aw)
       q     = (om/a**3+2*or/a**4-2*ol/aw)/H**2/2
       c0    = -1.5*om/H**2/a**5
       c1    = (2-q)/a
       Dh    = D + dDda*da/2
       dDdah = dDda - (c1*dDda+c0*D)*da/2
       ah    = a + da/2

       aw    = ah**(3*(1+w))
       H     = sqrt(om/ah**3+or/ah**4+ol/aw)
       q     = (om/ah**3+2*or/ah**4-2*ol/aw)/H**2/2
       c0    = -1.5*om/H**2/ah**5
       c1    = (2-q)/ah
       D     = D + dDdah*da
       dDda  = dDda - (c1*dDdah+c0*Dh)*da
       a     = a + da
    enddo

    D_of_z(1) = D_of_z(1)/D

    return
  end function D_of_z


  pure function H_of_z(z)
    ! Default
    implicit none


    ! Function parameters
    real(8), intent(in) :: z
    real(8)             :: H_of_z


    ! Local variables
    real(8) :: a,E_of_z


    ! Convert to a
    a = 1D0/(1 + z)

    ! Compute E(z)
    E_of_z = sqrt(omegam/a**3 + omegar/a**4 + omegal/a**(3*(1+wde)))

    ! Compute H(z)
    H_of_z = H0_cgs*hubble0*E_of_z

    return
  end function H_of_z


  subroutine write_vrms
    ! Default
    implicit none


    ! Local variables
    integer(4) :: i,Nz
    real(8)    :: z_min,z_max,d_z,z
    real(8)    :: Hz,Dz(2),vrms


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Compute vrms(z) for different redshifts
    z_min = 6
    z_max = 20
    d_z   = 0.1D0
    Nz    = (z_max-z_min)/d_z

    open(11,file="vrms.txt")
    write(11,'(a,a6,a16)') "#","z","v_RMS [km/s]"
    do i=1,Nz
       z    = (i-0.5)*d_z + z_min
       Hz   = H_of_z(z)
       Dz   = D_of_z(z)
       vrms = Hz*Dz(1)*pk_integral/sqrt(3D0)/(1+z)
       write(11,'(f7.2,es16.8)') z,vrms
    enddo

    close(11)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called write vrms'
    return
  end subroutine write_vrms


  subroutine write_window
    ! Default
    implicit none


    ! Local variables
    integer(4) :: i,Nz
    real(8)    :: z_min,z_max,d_z,z,x,g
    real(8)    :: Hz,Dz(2),vrms,ne,ne0


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Initialize
    z_min = 6
    z_max = 20
    d_z   = 0.1D0
    Nz    = 1 + int((z_max-z_min)/d_z)
    ne0   = omegab*rhoc_cgs*hubble0**2/mH_cgs*(1-(4-1)*YHe/4)

    open(11,file="window.txt")
    write(11,"(a,a6,a16)") "#","z","W(z) [h/Mpc]"
    do i=1,Nz
       z   = (i-1)*d_z + z_min
       Hz  = H_of_z(z)
       Dz  = D_of_z(z)
       vrms = Hz*Dz(1)*pk_integral/sqrt(3D0)/(1+z) * 1d5  ! km/s -> cm/s

       x  = interpolate(z,xvals,1,2,'lin')
       ne = ne0*(1-x)*(1+z)**2

       g = (ne*sT_cgs*vrms/c_cgs/(1+z)/hubble0*Mpc2cm)**2
       write(11,'(f7.2,es16.8)') z,g
    enddo

    close(11)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called write window'
    return
  end subroutine write_window


end program main
