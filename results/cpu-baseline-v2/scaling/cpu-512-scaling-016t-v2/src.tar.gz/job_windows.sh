#!/bin/bash
#SBATCH -J search_windows
#SBATCH -p RM-shared
#SBATCH -t 8:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node 8
#SBATCH -o std.log
#SBATCH -A ast180004p
#SBATCH --mail-type ALL
#SBATCH --mail-user plaplant@berkeley.edu

# Intel
module unload intel
module load intel/20.4
which ifort

# set environment variables
export KMP_LIBRARY=turnaround
export KMP_SCHEDULE=static,balanced
export KMP_STACKSIZE=256m

# Go to the job scratch directory
cd $SLURM_SUBMIT_DIR

# Compile and run the job
make clean
make search_windows.x
./search_windows.x > windows_s4_ilc_log
