# -*- coding: utf-8 -*-

import os
import datetime
import h5py
import numpy as np
from scipy.integrate import quad
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from bin_cl import bin_cl

# define files
root_dir = "/jet/home/plaplant/scratch_ml/ksz/fiducial/bt_bias"
window_fn_so = "cl_arrays_window_so_ilc.hdf5"
window_fn_s4 = "cl_arrays_window_s4_ilc.hdf5"
window_fn_hd = "cl_arrays_window_hd_ilc.hdf5"
cl_t2t2_fn_so = "data/cl_t2t2_so_ilc.txt"
cl_t2t2_fn_s4 = "data/cl_t2t2_s4_ilc.txt"
cl_t2t2_fn_hd = "data/cl_t2t2_hd_ilc.txt"
use_hls = False

# define indices
imid = 13
iwidth = -1

# define experiment parameters
# f_sky = 0.05
f_sky = 2200 / (4 * np.pi * (180.0 / np.pi)**2)
if use_hls:
    hls_counts = np.genfromtxt("data/hls_gal.txt")
else:
    roman_dndz = np.genfromtxt("data/dndz.txt")
    def integrand(z):
        return np.interp(z, roman_dndz[:, 0], roman_dndz[:, 3])

output_dirs = sorted([d for d in os.listdir(root_dir) if "output_" in d])
n_dirs = len(output_dirs)
for i, odir in enumerate(output_dirs):
    full_path_so = os.path.join(root_dir, odir, window_fn_so)
    print(f"reading {full_path_so}...")
    with h5py.File(full_path_so, "r") as h5f:
        if i == 0:
            tcmb0 = h5f["header/Tcmb0"][()]
            tfac = 1e6 * tcmb0
            cl_gal_so = h5f["data/cl_gal"][imid, iwidth, :, :]
            cl_kxg_so = h5f["data/cl_kxg"][imid, iwidth, :, :]
            cl_ks2_so = h5f["data/cl_ks2"][imid, iwidth, :, :]

        else:
            cl_gal_so += h5f["data/cl_gal"][imid, iwidth, :, :]
            cl_kxg_so += h5f["data/cl_kxg"][imid, iwidth, :, :]
            cl_ks2_so += h5f["data/cl_ks2"][imid, iwidth, :, :]

    full_path_s4 = os.path.join(root_dir, odir, window_fn_s4)
    print(f"reading {full_path_s4}...")
    with h5py.File(full_path_s4, "r") as h5f:
        if i == 0:
            tcmb0 = h5f["header/Tcmb0"][()]
            tfac = 1e6 * tcmb0
            cl_gal_s4 = h5f["data/cl_gal"][imid, iwidth, :, :]
            cl_kxg_s4 = h5f["data/cl_kxg"][imid, iwidth, :, :]
            cl_ks2_s4 = h5f["data/cl_ks2"][imid, iwidth, :, :]

            z1 = h5f["data/window_zvals"][imid, iwidth, 0]
            z2 = h5f["data/window_zvals"][imid, iwidth, 1]
        else:
            cl_gal_s4 += h5f["data/cl_gal"][imid, iwidth, :, :]
            cl_kxg_s4 += h5f["data/cl_kxg"][imid, iwidth, :, :]
            cl_ks2_s4 += h5f["data/cl_ks2"][imid, iwidth, :, :]

    full_path_hd = os.path.join(root_dir, odir, window_fn_hd)
    print(f"reading {full_path_hd}...")
    with h5py.File(full_path_hd, "r") as h5f:
        if i == 0:
            tcmb0 = h5f["header/Tcmb0"][()]
            tfac = 1e6 * tcmb0
            cl_gal_hd = h5f["data/cl_gal"][imid, iwidth, :, :]
            cl_kxg_hd = h5f["data/cl_kxg"][imid, iwidth, :, :]
            cl_ks2_hd = h5f["data/cl_ks2"][imid, iwidth, :, :]

            z1 = h5f["data/window_zvals"][imid, iwidth, 0]
            z2 = h5f["data/window_zvals"][imid, iwidth, 1]
        else:
            cl_gal_hd += h5f["data/cl_gal"][imid, iwidth, :, :]
            cl_kxg_hd += h5f["data/cl_kxg"][imid, iwidth, :, :]
            cl_ks2_hd += h5f["data/cl_ks2"][imid, iwidth, :, :]

# finish computing spectra
cl_gal_so /= n_dirs
cl_kxg_so /= n_dirs
cl_ks2_so /= n_dirs
cl_kxg_so[:, 1:] *= tfac**2
cl_ks2_so[:, 1:] *= tfac**4

cl_gal_s4 /= n_dirs
cl_kxg_s4 /= n_dirs
cl_ks2_s4 /= n_dirs
cl_kxg_s4[:, 1:] *= tfac**2
cl_ks2_s4[:, 1:] *= tfac**4

cl_gal_hd /= n_dirs
cl_kxg_hd /= n_dirs
cl_ks2_hd /= n_dirs
cl_kxg_hd[:, 1:] *= tfac**2
cl_ks2_hd[:, 1:] *= tfac**4

zavg = (z1 + z2) / 2.0
print("zvalue: ", zavg)
print("Delta z: ", z2 - z1)
if use_hls:
    ngal = np.interp(zavg, hls_counts[:, 0], hls_counts[:, 1])
else:
    ngal = quad(integrand, z1, z2)[0]
sn = 4 * np.pi * f_sky / ngal

# read in C_\ell^{T^2,T^2}
cl_t2t2_so = np.genfromtxt(cl_t2t2_fn_so)
cl_t2t2_s4 = np.genfromtxt(cl_t2t2_fn_s4)
cl_t2t2_hd = np.genfromtxt(cl_t2t2_fn_hd)

# plot a comparison of all spectra
matplotlib.rc("text", usetex=True)
matplotlib.rc("font", family="serif")
matplotlib.rc("lines", linewidth=2)

# fig = plt.figure()
# ax = plt.gca()

# ells = cl_gal_so[:, 0]
# clgg_so = cl_gal_so[:, 1]
# clt2t2_so = np.interp(ells, cl_t2t2_so[:, 0], cl_t2t2_so[:, 1])
# cl_prod_so = clgg_so * clt2t2_so
# l1, = ax.loglog(ells, cl_prod_so, color="C0", linestyle="--")

# idx_min = 8
# ells = cl_kxg_so[:, 0]
# cl_signal_so = cl_kxg_so[:, 1]**2
# ell_so, signal_so = bin_cl(ells, cl_signal_so, log_bins=True, log_width=0.2)
# l2, = ax.loglog(ell_so[idx_min:], signal_so[idx_min:], color="C0", linestyle="-")

# ells = cl_gal_s4[:, 0]
# clgg_s4 = cl_gal_s4[:, 1]
# clt2t2_s4 = np.interp(ells, cl_t2t2_s4[:, 0], cl_t2t2_s4[:, 1])
# cl_prod_s4 = clgg_s4 * clt2t2_s4
# l3, = ax.loglog(ells, cl_prod_s4, linestyle="--", color="C1")

# ells = cl_kxg_s4[:, 0]
# cl_signal_s4 = cl_kxg_s4[:, 1]**2
# ell_s4, signal_s4 = bin_cl(ells, cl_signal_s4, log_bins=True, log_width=0.2)
# l4, = ax.loglog(ell_s4[idx_min:], signal_s4[idx_min:], linestyle="-", color="C1")

# cl_prod_so_sn = (clgg_so + sn) * clt2t2_so
# l5, = ax.loglog(ells, cl_prod_so_sn, color="C0", linestyle=":")

# cl_prod_s4_sn = (clgg_s4 + sn) * clt2t2_s4
# l6, = ax.loglog(ells, cl_prod_s4_sn, color="C1", linestyle=":")

# ax.set_xlabel(r"$\ell$")
# ax.set_ylabel(r"$C_\ell^2$ [rad$^2$ $\mu$K$^4$]")

# label1 = r"$C_\ell^{\bar{T}^2\bar{T}^2,f} C_\ell^{\delta_g \delta_g}$"
# label2 = r"$\left(C_\ell^{\mathrm{kSZ}^2 \times \delta_g}\right)^2$"
# label3 = "SO"
# label4 = "S4"
# label5 = r"$C_\ell^{\bar{T}^2\bar{T}^2,f} C_\ell^{\delta_g \delta_g}$ (shot noise)"
# ax.legend(
#     [l2, l1, l5, l2, l4],
#     [label2, label1, label5, label3, label4],
#     loc=0,
#     ncol=2,
# )

date = datetime.date.today().strftime("%y%m%d")
plot_dir = os.path.join(root_dir, "plots", date)
if not os.path.isdir(plot_dir):
    os.makedirs(plot_dir)
# output = os.path.join(plot_dir, "snr_components_v2.pdf")
# print(f"saving {output}...")
# fig.savefig(output, bbox_inches="tight")
# plt.close(fig)

# also plot "integrand"
idx_min = 8

ells = cl_kxg_so[:, 0]
cl_signal_so = cl_kxg_so[:, 1]**2

ells = cl_gal_so[:, 0]
clgg_so = cl_gal_so[:, 1]
clt2t2_so = np.interp(ells, cl_t2t2_so[:, 0], cl_t2t2_so[:, 1])
cl_prod_so = (clgg_so + sn) * clt2t2_so

ells = cl_kxg_s4[:, 0]
cl_signal_s4 = cl_kxg_s4[:, 1]**2

ells = cl_gal_s4[:, 0]
clgg_s4 = cl_gal_s4[:, 1]
clt2t2_s4 = np.interp(ells, cl_t2t2_s4[:, 0], cl_t2t2_s4[:, 1])
cl_prod_s4 = (clgg_s4 + sn) * clt2t2_s4

ells = cl_kxg_hd[:, 0]
cl_signal_hd = cl_kxg_hd[:, 1]**2

ells = cl_gal_hd[:, 0]
clgg_hd = cl_gal_hd[:, 1]
clt2t2_hd = np.interp(ells, cl_t2t2_hd[:, 0], cl_t2t2_hd[:, 1])
cl_prod_hd = (clgg_hd + sn) * clt2t2_hd

integrand_so_sn = ells * (2 * ells + 1) * f_sky * cl_signal_so / (cl_prod_so + cl_signal_so)
integrand_s4_sn = ells * (2 * ells + 1) * f_sky * cl_signal_s4 / (cl_prod_s4 + cl_signal_s4)
integrand_hd_sn = ells * (2 * ells + 1) * f_sky * cl_signal_hd / (cl_prod_hd + cl_signal_hd)
fig = plt.figure()
ax = plt.gca()

ell1, int1 = bin_cl(ells, integrand_so_sn, log_bins=True, log_width=0.2)
ell2, int2 = bin_cl(ells, integrand_s4_sn, log_bins=True, log_width=0.2)
ell3, int3 = bin_cl(ells, integrand_hd_sn, log_bins=True, log_width=0.2)

l1, = ax.loglog(ell1, int1, color="C0", linestyle="-", label="SO ILC")
l2, = ax.loglog(ell2, int2, color="C1", linestyle="-", label="S4 ILC")
l3, = ax.loglog(ell3, int3, color="C2", linestyle="-", label="CMB-HD ILC")

ax.set_xlabel(r"$\ell$")
ax.set_ylabel(r"$\frac{\mathrm{d}\,\mathrm{SNR}^2}{\mathrm{d}\,\ln\ell}$")
ax.set_xlim((2e2, 1.3e4))

# labels = ["SO", "S4", "With Shot Noise", "Neglecting Shot Noise"]
# ax.legend(
#     [l3, l4, l3, l1],
#     labels,
#     loc=0,
#     ncol=2,
# )
ax.legend(loc=0)

output = os.path.join(plot_dir, "snr_integrand.pdf")
print(f"saving {output}...")
fig.savefig(output, bbox_inches="tight")
plt.close(fig)
