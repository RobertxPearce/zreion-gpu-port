# -*- coding: utf-8 -*-

import os
import datetime
import h5py
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

add_watermark = False

dark_background = False
if dark_background:
    plt.style.use("dark_background")
    transparent = True
else:
    transparent = False

experiments = ["so", "s4", "hd"]
noise_models = ["ilc"]

linestyles = ["--", "-", ":"]
colors = ["C0", "C1"]

#root_dir = "/jet/home/plaplant/scratch_ml/ksz/fiducial/bt_bias/"
root_dir = "/ocean/projects/ast180004p/jsipple/ksz/extended_output/"
save_dir = "/jet/home/plaplant/scratch_ml/ksz/jackson_extended/"
window_fn = os.path.join(root_dir, "output_0001", f"cl_arrays_window_s4_ilc.hdf5")
output_fn = f"snr_of_z.pdf"
compute_zvals = False

fontsize = 20
sm_fontsize = 14

# set up plotting
matplotlib.rc("text", usetex=True)
matplotlib.rc("font", family="serif")
matplotlib.rc("lines", linewidth=1)

fig = plt.figure()
ax = plt.gca()
ax.axhline(y=3.0, color="k", linestyle="--")

# only need to do redshift window calculations once
with h5py.File(window_fn, "r") as h5f:
    if compute_zvals:
        window_zvals = h5f["data/window_zvals"][()]
    else:
        mid_vals = h5f["data/z_mid"][()]
        width_vals = h5f["data/delta_z"][()]

if compute_zvals:
    # compute the window midpoints and widths
    zvals_width = window_zvals[-1, :, :]
    width_vals = zvals_width[:, 1] - zvals_width[:, 0]

    zvals_mid = window_zvals[:, -1, :]
    mid_vals = np.average(zvals_mid, axis=1)

# loop over experiments and noise models
lines = []
for ie, exp in enumerate(experiments):
    for im, nm in enumerate(noise_models):
        snr_fn = os.path.join(save_dir, f"snr_ext_{exp}_{nm}.hdf5")

        with h5py.File(snr_fn, "r") as h5f:
            snr = h5f["snr"][()]

        # compute the cumulative S/N for different choices of redshift width
        snr = 1.0 / snr.T

        cum_snr = np.zeros_like(width_vals, dtype=np.float64)
        for i, width in enumerate(width_vals):
            cs = 0.0
            zstart = mid_vals[0] + width / 2
            zstop = mid_vals[-1]
            nz = max(1, int((zstop - zstart) / width))
            if nz == 1:
                cum_snr[i] = np.amax(snr[i, :])
            else:
                for iz in range(nz):
                    z0 = zstart + (iz * width / 2)
                    zidx = np.argmin(np.abs(mid_vals - z0))
                    cs += snr[i, zidx]**2
                cum_snr[i] = np.sqrt(cs)

        li, = ax.plot(width_vals, cum_snr, linestyle=linestyles[ie], color=colors[im])
        lines.append(li)

ax.set_xlabel(r"$\Delta z$", fontsize=fontsize)
ax.set_ylabel(r"$s_\mathrm{cum}$", fontsize=fontsize)
#ax.set_ylim((0, 50))
ax.tick_params(axis="both", labelsize=sm_fontsize)

labels = ["SO", "S4", "HD", r"Na{\"\i}ve", "ILC"]
lns = lines[::2] + lines[2:4]
ax.legend(lns, labels, loc=0, ncol=2, prop={"size": sm_fontsize})

date = datetime.date.today().strftime("%y%m%d")
plots_dir = os.path.join(save_dir, "plots", date)
if not os.path.isdir(plots_dir):
    os.makedirs(plots_dir)
output = os.path.join(plots_dir, output_fn)
print(f"saving {output}...")
fig.savefig(output, bbox_inches="tight", transparent=transparent)
plt.close(fig)
