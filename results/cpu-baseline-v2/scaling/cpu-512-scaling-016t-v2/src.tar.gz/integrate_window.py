# -*- coding: utf-8 -*-

import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq
from astropy.cosmology import FlatLambdaCDM

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# cosmology
hubble0 = 0.673212
omegam = 0.315823
tcmb0 = 2.7255

gvals = np.genfromtxt("window.txt")

cosmo = FlatLambdaCDM(100 * hubble0, omegam, tcmb0)

chi_min = cosmo.comoving_distance(6).to("Mpc").value * hubble0
chi_max = cosmo.comoving_distance(20).to("Mpc").value * hubble0

def z_of_chi(chi):
    def func(z):
        return cosmo.comoving_distance(z).to("Mpc").value * hubble0 - chi
    return brentq(func, 6, 20)

def integrand(chi):
    z = z_of_chi(chi)
    return np.interp(z, gvals[:, 0], gvals[:, 1])

result = quad(integrand, chi_min, chi_max)[0]
print("result: ", result)
print("normalization: ", 1 / result)
gvals[:, 1] /= result

# plot resulting window
matplotlib.rc("text", usetex=True)
matplotlib.rc("font", family="serif")
matplotlib.rc("lines", linewidth=3)

fig = plt.figure()
ax = plt.gca()
ax.plot(gvals[:, 0], gvals[:, 1])
ax.set_xlim((6, 10))
ax.set_xlabel(r"$z$")
ax.set_ylabel(r"$W_g(z)$ [$h$ Mpc$^{-1}$]")

output = "wg.pdf"
print(f"saving {output}...")
fig.savefig(output, bbox_inches="tight")
plt.close(fig)
