# -*- coding: utf-8 -*-

import os
import datetime
import h5py
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

dark_background = False
if dark_background:
    plt.style.use("dark_background")
    transparent = True
    ax_color = "w"
else:
    transparent = False
    ax_color = "k"

fontsize = 20
sm_fontsize = 14

short_dir = "/jet/home/plaplant/scratch_ml/ksz/paul_short/"
ext_dir = "/jet/home/plaplant/scratch_ml/ksz/jackson_extended/"
early_dir = "/jet/home/plaplant/scratch_ml/ksz/jackson_early/"

noise = "_ilc"  # "_ilc" or ""

plot_max = True
narrow_z = False

# read in the S/N files
short_so_fn = os.path.join(short_dir, f"snr_short_so{noise}.hdf5")
short_s4_fn = os.path.join(short_dir, f"snr_short_s4{noise}.hdf5")
short_hd_fn = os.path.join(short_dir, f"snr_short_hd{noise}.hdf5")

if narrow_z:
    ext_so_fn = os.path.join(ext_dir, f"snr_ext_so{noise}.hdf5")
    ext_s4_fn = os.path.join(ext_dir, f"snr_ext_s4{noise}.hdf5")
    ext_hd_fn = os.path.join(ext_dir, f"snr_ext_hd{noise}.hdf5")
else:
    ext_so_fn = os.path.join(ext_dir, f"snr_ext_so{noise}_wide_z.hdf5")
    ext_s4_fn = os.path.join(ext_dir, f"snr_ext_s4{noise}_wide_z.hdf5")
    ext_hd_fn = os.path.join(ext_dir, f"snr_ext_hd{noise}_wide_z.hdf5")

early_so_fn = os.path.join(early_dir, f"snr_early_so{noise}.hdf5")
early_s4_fn = os.path.join(early_dir, f"snr_early_s4{noise}.hdf5")
early_hd_fn = os.path.join(early_dir, f"snr_early_hd{noise}.hdf5")

def compute_cum_snr(snr_total_arr):
    nz = 5  # number of z_0 values that "fit" into dz = 1
    for iz in range(nz):
        snr_arr = snr_total_arr[iz::nz, :, :]
        for zidx in range(snr_arr.shape[0]):
            if zidx == 0:
                snr = snr_arr[zidx, :, :]
                snr[:, 1] = 1.0 / snr[:, 1]**2
            else:
                snr[:, 1] += 1.0 / snr_arr[zidx, :, 1]**2

        snr[:, 1] = 1.0 / np.sqrt(snr[:, 1])
        if iz == 0:
            snr_final = snr
        else:
            if snr[-1, 1] > snr_final[-1, 1]:
                snr_final = snr

    return snr_final

with h5py.File(short_so_fn, "r") as h5f:
    if plot_max:
        maxloc = np.unravel_index(np.argmin(h5f["snr"][()]), h5f["snr"].shape)  # values are 1/(S/N)
        snr_short_so = h5f["snr_by_ell"][maxloc[0], maxloc[1], :, :]
    else:
        # get all curves with Delta z = 1
        snr_dz1 = h5f["snr_by_ell"][:, 9, :, :]
        snr_short_so = compute_cum_snr(snr_dz1)

with h5py.File(short_s4_fn, "r") as h5f:
    if plot_max:
        maxloc = np.unravel_index(np.argmin(h5f["snr"][()]), h5f["snr"].shape)
        snr_short_s4 = h5f["snr_by_ell"][maxloc[0], maxloc[1], :, :]
    else:
        snr_dz1 = h5f["snr_by_ell"][:, 9, :, :]
        snr_short_s4 = compute_cum_snr(snr_dz1)

with h5py.File(short_hd_fn, "r") as h5f:
    if plot_max:
        maxloc = np.unravel_index(np.argmin(h5f["snr"][()]), h5f["snr"].shape)
        snr_short_hd = h5f["snr_by_ell"][maxloc[0], maxloc[1], :, :]
    else:
        snr_dz1 = h5f["snr_by_ell"][:, 9, :, :]
        snr_short_hd = compute_cum_snr(snr_dz1)

with h5py.File(ext_so_fn, "r") as h5f:
    if plot_max:
        maxloc = np.unravel_index(np.argmin(h5f["snr"][()]), h5f["snr"].shape)
        snr_ext_so = h5f["snr_by_ell"][maxloc[0], maxloc[1], :, :]
    else:
        snr_dz1 = h5f["snr_by_ell"][:, 9, :, :]
        snr_ext_so = compute_cum_snr(snr_dz1)

with h5py.File(ext_s4_fn, "r") as h5f:
    if plot_max:
        maxloc = np.unravel_index(np.argmin(h5f["snr"][()]), h5f["snr"].shape)
        snr_ext_s4 = h5f["snr_by_ell"][maxloc[0], maxloc[1], :, :]
    else:
        snr_dz1 = h5f["snr_by_ell"][:, 9, :, :]
        snr_ext_s4 = compute_cum_snr(snr_dz1)

with h5py.File(ext_hd_fn, "r") as h5f:
    if plot_max:
        maxloc = np.unravel_index(np.argmin(h5f["snr"][()]), h5f["snr"].shape)
        snr_ext_hd = h5f["snr_by_ell"][maxloc[0], maxloc[1], :, :]
    else:
        snr_dz1 = h5f["snr_by_ell"][:, 9, :, :]
        snr_ext_hd = compute_cum_snr(snr_dz1)

with h5py.File(early_so_fn, "r") as h5f:
    if plot_max:
        maxloc = np.unravel_index(np.argmin(h5f["snr"][()]), h5f["snr"].shape)
        snr_early_so = h5f["snr_by_ell"][maxloc[0], maxloc[1], :, :]
    else:
        snr_dz1 = h5f["snr_by_ell"][:, 9, :, :]
        snr_early_so = compute_cum_snr(snr_dz1)

with h5py.File(early_s4_fn, "r") as h5f:
    if plot_max:
        maxloc = np.unravel_index(np.argmin(h5f["snr"][()]), h5f["snr"].shape)
        snr_early_s4 = h5f["snr_by_ell"][maxloc[0], maxloc[1], :, :]
    else:
        snr_dz1 = h5f["snr_by_ell"][:, 9, :, :]
        snr_early_s4 = compute_cum_snr(snr_dz1)

with h5py.File(early_hd_fn, "r") as h5f:
    if plot_max:
        maxloc = np.unravel_index(np.argmin(h5f["snr"][()]), h5f["snr"].shape)
        snr_early_hd = h5f["snr_by_ell"][maxloc[0], maxloc[1], :, :]
    else:
        snr_dz1 = h5f["snr_by_ell"][:, 9, :, :]
        snr_early_hd = compute_cum_snr(snr_dz1)

# initialize plot
matplotlib.rc("text", usetex=True)
matplotlib.rc("font", family="serif")

fig = plt.figure()
ax = plt.gca()
ax.axhline(y=1.0, color=ax_color, linestyle=":")
ax.axhline(y=3.0, color=ax_color, linestyle="--")

# plot different combos
l0, = ax.plot(snr_short_so[:, 0], 1.0 / snr_short_so[:, 1], color="C0", linestyle="-")
l1, = ax.plot(snr_short_s4[:, 0], 1.0 / snr_short_s4[:, 1], color="C0", linestyle="--")
l2, = ax.plot(snr_short_hd[:, 0], 1.0 / snr_short_hd[:, 1], color="C0", linestyle=":")
l3, = ax.plot(snr_ext_so[:, 0], 1.0 / snr_ext_so[:, 1], color="C1", linestyle="-")
l4, = ax.plot(snr_ext_s4[:, 0], 1.0 / snr_ext_s4[:, 1], color="C1", linestyle="--")
l5, = ax.plot(snr_ext_hd[:, 0], 1.0 / snr_ext_hd[:, 1], color="C1", linestyle=":")
l6, = ax.plot(snr_early_so[:, 0], 1.0 / snr_early_so[:, 1], color="C2", linestyle="-")
l7, = ax.plot(snr_early_s4[:, 0], 1.0 / snr_early_s4[:, 1], color="C2", linestyle="--")
l8, = ax.plot(snr_early_hd[:, 0], 1.0 / snr_early_hd[:, 1], color="C2", linestyle=":")

# make plot pretty
ax.set_xlim((100, 3000))
ax.set_xlabel(r"$\ell_{\mathrm{max}}$", fontsize=fontsize)
ax.set_ylabel("cumulative S/N", fontsize=fontsize)
lines = [l3, l4, l5, l3, l0, l6]
labels = ["SO", "CMB-S4", "CMB-HD", "Fiducial", "Short", "Early"]
ax.legend(lines, labels, loc=0, ncol=2, prop={"size": sm_fontsize})
ax.tick_params(axis="both", labelsize=sm_fontsize)
ax.set_ylim((0, 14))

# save figure
date = datetime.date.today().strftime("%y%m%d")
plot_dir = os.path.join(short_dir, "plots", date)
if not os.path.isdir(plot_dir):
    os.makedirs(plot_dir)
output_fn = os.path.join(plot_dir, f"snr_by_ell{noise}.pdf")
print(f"saving {output_fn}...")
fig.savefig(output_fn, bbox_inches="tight", transparent=transparent)
plt.close(fig)
