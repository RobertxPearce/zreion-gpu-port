#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import datetime
import h5py
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# constants
tfac = 2.7255e6  # convert from Delta T/T_cmb -> uK

# read in Cl spectrum
root_dir = "/jet/home/plaplant/scratch_ml/ksz/output_0001"
#root_dir = "/jet/home/plaplant/scratch/Nbody/L2000_NP2048_nbody_Planck2018/Grid/output"
cl_fn = os.path.join(root_dir, "cl_arrays.hdf5")
with h5py.File(cl_fn, "r") as h5f:
    cl_ksz = h5f["data/cl_ksz"][()]

ngrid = cl_ksz.shape[0]
hgrid = ngrid // 2
ell = cl_ksz[:hgrid, 0]
cl = cl_ksz[:hgrid, 1] * tfac**2
dl = ell * (ell + 1) * cl / (2 * np.pi)

# matplotlib options
# matplotlib.rc("text", usetex=True)
matplotlib.rc("font", family="serif")
matplotlib.rc("lines", linewidth=3)

# make a plot
fig = plt.figure()
ax = plt.gca()
ax.loglog(ell, dl, alpha=0.5)
ax.set_xlabel(r"$\ell$")
ax.set_ylabel(r"$\ell(\ell+1)C_\ell /2\pi$ [$\mu$K$^2$]")
out_fn = os.path.join(root_dir, "cl_ksz.png")
print(f"saving {out_fn}...")
fig.savefig(out_fn, bbox_inches="tight")
plt.close(fig)
