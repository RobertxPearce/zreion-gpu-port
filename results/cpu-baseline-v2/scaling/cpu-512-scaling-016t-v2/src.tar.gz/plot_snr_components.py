# -*- coding: utf-8 -*-

import os
import datetime
import h5py
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# define files
root_dir = "/jet/home/plaplant/scratch_ml/ksz/fiducial"
snr_fn = os.path.join(root_dir, "snr_s4.hdf5")
window_fn = "cl_arrays_window_s4.hdf5"
cl_t2t2_fn = "cl_t2t2_s4.txt"

# define indices
imid = 15
iwidth = -1

output_dirs = sorted([d for d in os.listdir(root_dir) if "output_" in d])
n_dirs = len(output_dirs)
for i, odir in enumerate(output_dirs):
    full_path = os.path.join(root_dir, odir, window_fn)
    print(f"reading {full_path}...")
    with h5py.File(full_path, "r") as h5f:
        if i == 0:
            tcmb0 = h5f["header/Tcmb0"][()]
            tfac = 1e6 * tcmb0
            cl_gal = h5f["data/cl_gal"][imid, iwidth, :, :]
            cl_kxg = h5f["data/cl_kxg"][imid, iwidth, :, :]
            cl_ks2 = h5f["data/cl_ks2"][imid, iwidth, :, :]
        else:
            cl_gal += h5f["data/cl_gal"][imid, iwidth, :, :]
            cl_kxg += h5f["data/cl_kxg"][imid, iwidth, :, :]
            cl_ks2 += h5f["data/cl_ks2"][imid, iwidth, :, :]

# finish computing spectra
cl_gal /= n_dirs
cl_kxg /= n_dirs
cl_ks2 /= n_dirs
cl_kxg[:, 1:] *= tfac**2
cl_ks2[:, 1:] *= tfac**4

# read in C_\ell^{T^2,T^2}
cl_t2t2 = np.genfromtxt(cl_t2t2_fn)

# plot a comparison of all spectra
matplotlib.rc("text", usetex=True)
matplotlib.rc("font", family="serif")
matplotlib.rc("lines", linewidth=2)

fig = plt.figure()
ax = plt.gca()

ells = cl_gal[:, 0]
dl = ells * (ells + 1) * cl_gal[:, 1] / (2 * np.pi)
ax.loglog(ells, dl, label=r"$C_\ell^{\delta_g \delta_g}$")

ells = cl_kxg[:, 0]
dl = ells * (ells + 1) * cl_kxg[:, 1] / (2 * np.pi)
ax.loglog(ells, dl, label=r"$C_\ell^{\mathrm{kSZ}^2 \times \delta_g}$ [$\mu$K$^2$]")

ells = cl_t2t2[:, 0]
dl = ells * (ells + 1) * cl_t2t2[:, 1] / (2 * np.pi)
ax.loglog(ells, dl, label=r"$C_\ell^{\bar{T}^2\bar{T}^2,f}$ [$\mu$K$^4$]")

ells = cl_ks2[:, 0]
dl = ells * (ells + 1) * cl_ks2[:, 1] / (2 * np.pi)
ax.loglog(ells, dl, label=r"$C_\ell^{\mathrm{kSZ}^2\mathrm{kSZ}^2,f}$ [$\mu$K$^4$]")

ax.set_xlabel(r"$\ell$")
ax.set_ylabel(r"$\ell(\ell+1)C_\ell/2\pi$")
ax.legend(loc=0)

date = datetime.date.today().strftime("%y%m%d")
plot_dir = os.path.join(root_dir, "plots", date)
if not os.path.isdir(plot_dir):
    os.makedirs(plot_dir)
output = os.path.join(plot_dir, "snr_components_s4.pdf")
print(f"saving {output}...")
fig.savefig(output, bbox_inches="tight")
plt.close(fig)
