program main
  ! Intel
  use IFPORT
  use OMP_LIB


  ! Global
  use global


  ! Tools
  use io_tools
  use cosmo_tools
  use field_tools


  ! Default
  implicit none


  ! Read all boxes?
  logical, parameter :: read_full_boxes = .true.

  ! Apply 21cm wedge filter?
  ! Note: only applies if read_full_boxes is .true.
  logical, parameter :: wedge_filter = .false.


  ! Initialize
  write(*,*) "Ncpu available: ",OMP_GET_NUM_PROCS()
  call OMP_SET_NUM_THREADS(N_cpu)
  call init_small_fields
  if (read_full_boxes) then
     call get_box_size
  endif
  call init_window_fields
  call read_f_ell
  if (wedge_filter) then
     call calc_cosmo_distance
  endif


  ! Do work
  do isim=1,N_sims
     write(*,*)
     write(*,*)
     write(*,'(a,i4,a,i4)') "Analyzing simulation ",isim," of ",N_sims
     ! Do preliminary reading
     call read_ksz_zvals
     if (read_full_boxes) then
        call read_obs_grids
        if (wedge_filter) then
           call apply_wedge_filter
        endif
     endif


     ! Do work
     call compute_window_spectra

     ! Write out
     call write_window_spectra
  enddo


contains


  subroutine init_window_fields
    ! Default
    implicit none


    ! Local variables
    integer(4) :: k


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Initialize arrays
    allocate(cl_ksz_window(3,N_grid,N_width,N_mid))
    allocate(cl_t21_window(3,N_grid,N_width,N_mid))
    allocate(cl_gal_window(3,N_grid,N_width,N_mid))
    allocate(cl_ks2_window(3,N_grid,N_width,N_mid))
    allocate(cl_kxt_window(3,N_grid,N_width,N_mid))
    allocate(cl_kxg_window(3,N_grid,N_width,N_mid))

    cl_ksz_window = 0
    cl_t21_window = 0
    cl_gal_window = 0
    cl_ks2_window = 0
    cl_kxt_window = 0
    cl_kxg_window = 0

    if (read_full_boxes) then
       allocate(t21_box(N_grid+2,N_grid,Nsightpix))
       allocate(gal_box(N_grid  ,N_grid,Nsightpix))

       !$omp parallel        &
       !$omp default(shared) &
       !$omp private(k)
       !$omp do
       do k=1,Nsightpix
          t21_box(:,:,k) = 0
       enddo
       !$omp end do
       !$omp do
       do k=1,Nsightpix
          gal_box(:,:,k) = 0
       enddo
       !$omp end do
       !$omp end parallel
    endif


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called init window fields'
    return
  end subroutine init_window_fields


!------------------------------------------------------------------------------!


  subroutine compute_window_indices(imid,iwidth)
    ! Default
    implicit none


    ! Subroutine arguments
    integer(4) :: imid,iwidth


    ! Local variables
    integer(4) :: i
    real(8)    :: z1,z2,zmean,dz
    logical    :: increasing


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Check that zvals are monotonic
    if (zvals(2) > zvals(1)) then
       increasing = .true.
    else
       increasing = .false.
    endif

    do i=2,Nsightpix
       if (increasing) then
          if (zvals(i) < zvals(i-1)) then
             write(*,*) "zvals are not monotonic, stopping..."
             stop
          endif
       else
          if (zvals(i) > zvals(i-1)) then
             write(*,*) "zvals are not monotonic, stopping..."
             stop
          endif
       endif
    enddo

    ! Compute the indices that bracket the window in redshift space
    zmean = z_mid(imid)
    dz    = delta_z(iwidth)
    z1    = zmean - dz/2
    z2    = zmean + dz/2

    if (increasing) then
       if (z1 <= zvals(1)) then
          windx1 = 1
       else
          ! Find best starting point
          do i=2,Nsightpix
             if (zvals(i) > z1) then
                windx1 = i - 1
                exit
             endif
             windx1 = i
          enddo
       endif

       if (z2 >= zvals(Nsightpix)) then
          windx2 = Nsightpix
       else
          ! Find best ending point
          do i=1,Nsightpix
             if (zvals(i) > z2) then
                windx2 = i
                exit
             endif
             windx2 = i
          enddo
       endif
    else
       if (z1 >= zvals(Nsightpix)) then
          windx2 = Nsightpix
       else
          ! Find best ending point
          do i=Nsightpix-1,1,-1
             if (zvals(i) > z1) then
                windx2 = i + 1
                exit
             endif
             windx2 = i
          enddo
       endif

       if (z2 < zvals(1)) then
          windx1 = 1
       else
          do i=Nsightpix,1,-1
             if (zvals(i) > z2) then
                windx1 = i
                exit
             endif
             windx1 = i
          enddo
       endif
    endif

    if (windx1 > windx2) then
       write(*,*) "Nonsensical indices, stopping..."
       stop
    endif

    ! Re-assign based on the "actual" window indices
    z1 = zvals(windx1)
    z2 = zvals(windx2)
    ! write(*,'(a,2i5)')   "windx1, windx2: ",windx1,windx2
    ! write(*,'(a,2f6.2)') "z1, z2:         ",z1,z2
    window_zvals(1,iwidth,imid) = z1
    window_zvals(2,iwidth,imid) = z2


    tr2 = omp_get_wtime()
    call time(ts2)
    ! write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called compute window indices'
    return
  end subroutine compute_window_indices


!------------------------------------------------------------------------------!


  subroutine compute_window_spectra
    ! Default
    implicit none


    ! Local variables
    integer(4) :: imid,iwidth


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Loop over midpoints and widths, computing resulting spectra
    do imid=1,N_mid
       do iwidth=1,N_width
          ! Determine extent in redshift space
          call compute_window_indices(imid,iwidth)
          if (read_full_boxes) then
             call extract_field_chunks
          else
             call read_field_chunks
          endif
          call calc_cl_spectrum(ksz_map,ksz_map,cl_ksz,.false.,.false.)
          call calc_cl_spectrum(t21_map,t21_map,cl_t21,.false.,.false.)
          call calc_cl_spectrum(gal_map,gal_map,cl_gal,.false.,.false.)
          call calc_cl_spectrum(ksz_map,ksz_map,cl_ks2,.true. ,.true. )
          call calc_cl_spectrum(ksz_map,t21_map,cl_kxt,.true. ,.false.)
          call calc_cl_spectrum(ksz_map,gal_map,cl_kxg,.true. ,.false.)

          cl_ksz_window(:,:,iwidth,imid) = cl_ksz
          cl_t21_window(:,:,iwidth,imid) = cl_t21
          cl_gal_window(:,:,iwidth,imid) = cl_gal
          cl_ks2_window(:,:,iwidth,imid) = cl_ks2
          cl_kxt_window(:,:,iwidth,imid) = cl_kxt
          cl_kxg_window(:,:,iwidth,imid) = cl_kxg
       enddo
    enddo


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called compute window spectra'
    return
  end subroutine compute_window_spectra


!------------------------------------------------------------------------------!


  subroutine extract_field_chunks
    ! Default
    implicit none


    ! Local variables
    integer(4) :: i,j,k,idx,Nwindow
    real(8), dimension(N_grid,N_grid) :: temp_map


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Extract regions of the boxes
    Nwindow  = windx2 - windx1 + 1
    temp_map = 0
    !$omp parallel do           &
    !$omp default(shared)       &
    !$omp private(i,j,k,idx)    &
    !$omp reduction(+:temp_map)
    do k=1,Nwindow
       idx = k + windx1 - 1
       do j=1,N_grid
          do i=1,N_grid
             temp_map(i,j) = temp_map(i,j) + t21_box(i,j,idx)/Nwindow
          enddo
       enddo
    enddo
    !$omp end parallel do

    ! Move over to map array
    !$omp parallel do     &
    !$omp default(shared) &
    !$omp private(i,j)
    do j=1,N_grid
       do i=1,N_grid
          t21_map(i,j) = temp_map(i,j)
       enddo
    enddo
    !$omp end parallel do

    ! Same thing for galaxy field
    temp_map = 0
    !$omp parallel do           &
    !$omp default(shared)       &
    !$omp private(i,j,k,idx)    &
    !$omp reduction(+:temp_map)
    do k=1,Nwindow
       idx = k + windx1 - 1
       do j=1,N_grid
          do i=1,N_grid
             temp_map(i,j) = temp_map(i,j) + gal_box(i,j,idx)/Nwindow
          enddo
       enddo
    enddo
    !$omp end parallel do

    ! Move over to map array
    !$omp parallel do     &
    !$omp default(shared) &
    !$omp private(i,j)
    do j=1,N_grid
       do i=1,N_grid
          gal_map(i,j) = temp_map(i,j)
       enddo
    enddo
    !$omp end parallel do


    tr2 = omp_get_wtime()
    call time(ts2)
    ! write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called extract field chunks'
    return
  end subroutine extract_field_chunks


end program main
