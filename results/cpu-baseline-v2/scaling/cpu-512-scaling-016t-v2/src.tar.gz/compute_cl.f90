program main
  ! Intel
  use IFPORT
  use OMP_LIB


  ! Global
  use global


  ! Tools
  use io_tools
  use cosmo_tools
  use field_tools


  ! Default
  implicit none


  ! Initialize
  write(*,*) "Ncpu available: ",OMP_GET_NUM_PROCS()
  call OMP_SET_NUM_THREADS(N_cpu)
  call init_small_fields


  ! Do work
  do isim=1,N_sims
     call read_fields
     call calc_cl_spectrum(ksz_map,ksz_map,cl_ksz,.false.,.false.)
     call calc_cl_spectrum(t21_map,t21_map,cl_t21,.false.,.false.)
     call calc_cl_spectrum(gal_map,gal_map,cl_gal,.false.,.false.)
     !call calc_cl_spectrum(ksz_map,t21_map,cl_kxt,.true.,.false.)
     call write_spectra
  enddo


end program main
