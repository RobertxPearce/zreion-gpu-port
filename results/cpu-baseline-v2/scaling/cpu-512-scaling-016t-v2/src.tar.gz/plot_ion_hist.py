# -*- coding: utf-8 -*-

import os
import datetime
import h5py
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

dark_background = True
if dark_background:
    plt.style.use("dark_background")
    transparent = True
else:
    transparent = False

fontsize = 20
sm_fontsize = 14

# define places to find ionization history
extended_dir = "/ocean/projects/ast180004p/jsipple/ksz/extended_output"
early_dir = "/ocean/projects/ast180004p/jsipple/ksz/early_output"
short_dir = "/jet/home/plaplant/scratch_ml/ksz/fiducial/bt_bias"

out_dir = "/ocean/projects/ast190007p/plaplant/ksz/plots"

# read in ionization histories
extended_fn = os.path.join(extended_dir, "output_0001", "pk_arrays.hdf5")
with h5py.File(extended_fn, "r") as h5f:
    zvals_extended = h5f["data/zval_list"][()]
    xvals_extended = h5f["data/xval_list"][()]

early_fn = os.path.join(early_dir, "output_0001", "pk_arrays.hdf5")
with h5py.File(early_fn, "r") as h5f:
    zvals_early = h5f["data/zval_list"][()]
    xvals_early = h5f["data/xval_list"][()]

short_fn = os.path.join(short_dir, "output_0001", "pk_arrays.hdf5")
with h5py.File(short_fn, "r") as h5f:
    zvals_short = h5f["data/zval_list"][()]
    xvals_short = h5f["data/xval_list"][()]

# make a plot
matplotlib.rc("text", usetex=True)
matplotlib.rc("font", family="serif")

linewidth = 1.5
alpha = 1.0

fig = plt.figure()
ax = plt.gca()

ax.plot(
    zvals_extended,
    1 - xvals_extended,
    label="Fiducial",
    linestyle="-",
    linewidth=linewidth,
    alpha=alpha,
)
ax.plot(
    zvals_early,
    1 - xvals_early,
    label="Early",
    linestyle="--",
    linewidth=linewidth,
    alpha=alpha,
)
ax.plot(
    zvals_short,
    1 - xvals_short,
    label="Short",
    linestyle=":",
    linewidth=linewidth,
    alpha=alpha,
)

ax.set_xlim((5, 12))
ax.set_xlabel("$z$", fontsize=fontsize)
ax.set_ylabel("$x_{\mathrm{HII}}$", fontsize=fontsize)
ax.legend(loc=0, prop={"size": sm_fontsize})
ax.tick_params(axis="both", labelsize=sm_fontsize)

date = datetime.date.today().strftime("%y%m%d")
plot_dir = os.path.join(out_dir, date)
if not os.path.isdir(plot_dir):
    os.makedirs(plot_dir)
output_fn = os.path.join(plot_dir, "x_HII.pdf")
print(f"saving {output_fn}...")
fig.savefig(output_fn, bbox_inches="tight", transparent=transparent)
plt.close(fig)
