# -*- coding: utf-8 -*-

import os
import datetime
import h5py
import numba
from numba import jit
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

dark_background = True
if dark_background:
    plt.style.use("dark_background")
    transparent = True
else:
    transparent = False

root_dir = "/jet/home/plaplant/scratch_ml/ksz/long/jordan_bias/"
data_fn = os.path.join(root_dir, "output_0001", "obs_grids.hdf5")
save_dir = "/jet/home/plaplant/scratch_ml/ksz"
filter_dir = "/ocean/projects/ast180004p/jsipple/ksz/extended_output"
f_ell_fn = os.path.join(filter_dir, "f_ell_so_ilc.hdf5")
processed_data_fn = "data/plot_fields_data.hdf5"
plot_wedge = False
use_titles = True
ell_max = 1000.0

# set label sizes
fontsize = 20
sm_fontsize = 14

# define numba function for applying Wiener filter
@jit(nopython=True)
def apply_wiener_filter(fft_array, f_ell, theta):
    nx, ny = fft_array.shape
    for i in range(nx):
        if i < (nx // 2) + 1:
            lx = 2 * np.pi / theta * i
        else:
            lx = 2 * np.pi / theta * (i - nx)

        for j in range(ny):
            ly = 2 * np.pi / theta * j

            ell = np.sqrt(lx**2 + ly**2)
            f = np.interp(ell, f_ell[:, 0], f_ell[:, 1])

            fft_array[i, j] *= f

    return

# define function for low-pass filter
@jit(nopython=True)
def apply_lowpass_filter(fft_array, ell_max, theta):
    nx, ny = fft_array.shape
    for i in range(nx):
        if i < (nx // 2) + 1:
            lx = 2 * np.pi / theta * i
        else:
            lx = 2 * np.pi / theta * (i - nx)

        for j in range(ny):
            ly = 2 * np.pi / theta * j

            ell = np.sqrt(lx**2 + ly**2)
            if ell > ell_max:
                fft_array[i, j] = 0.0

    return

# define function for applying wedge filter
@jit(nopython=True)
def apply_wedge_filter(fft_array, slp):
    nx, ny, nz = fft_array.shape
    for i in range(nx):
        if i < (nx // 2) + 1:
            kx = 2 * np.pi / nx * i
        else:
            kx = 2 * np.pi / nx * (i - nx)

        kpara = np.abs(kx)

        for j in range(ny):
            if j < (ny // 2) + 1:
                ky = 2 * np.pi / ny * j
            else:
                ky = 2 * np.pi / ny * (j - ny)

            for k in range(nz):
                kz = 2 * np.pi / nz * k

                kperp = np.sqrt(ky**2 + kz**2)

                if kpara <= slp * kperp:
                    fft_array[i, j, k] = 0.0

    return


# try to read in already-processed data
have_data = False
if not plot_wedge:
    try:
        print(f"reading {processed_data_fn}...")
        with h5py.File(processed_data_fn, "r") as h5f:
            theta_max = h5f["theta_max_ksz"][()]
            tcmb = h5f["Tcmb0"][()]
            ksz_map = h5f["ksz_map"][()]
            zvals = h5f["zvals"][()]
            z1 = h5f["z1"][()]
            z2 = h5f["z2"][()]
            t21_map = h5f["t21_map"][()]
            gal_map = h5f["gal_map"][()]
            ion_map = h5f["ion_map"][()]

        have_data = True
    except (KeyError, IOError, OSError):
        have_data = False

if not have_data:
    # define bracketing redshfits
    z1 = 7.5
    z2 = 8.5

    print(f"reading {data_fn}...")
    with h5py.File(data_fn, "r") as h5f:
        theta_max = h5f["header/theta_max_ksz"][()]
        tcmb = h5f["header/Tcmb0"][()]
        ksz_map = h5f["data/ksz_map"][()]
        zvals = h5f["data/zvals"][()]
        iz1 = np.argmin(np.abs(zvals - z1))
        iz2 = np.argmin(np.abs(zvals - z2))
        t21_map = np.average(h5f["data/t21_box"][iz1:iz2, :, :], axis=0)
        gal_box = h5f["data/gal_box"][iz1:iz2, :, :]
        gal_avg = np.average(gal_box)
        gal_box -= gal_avg
        gal_map = np.average(gal_box, axis=0)
        ion_box = np.where(np.isclose(h5f["data/t21_box"][iz1:iz2, :, :], 0.0), 1.0, 0.0)
        ion_map = np.average(ion_box, axis=0)
        if plot_wedge:
            t21_box = h5f["data/t21_box"][iz1 // 2 : iz2 * 2, :, :]

    # save for later
    with h5py.File(processed_data_fn, "w") as h5f:
        h5f.create_dataset("theta_max_ksz", data=theta_max)
        h5f.create_dataset("Tcmb0", data=tcmb)
        h5f.create_dataset("ksz_map", data=ksz_map)
        h5f.create_dataset("zvals", data=zvals)
        h5f.create_dataset("z1", data=z1)
        h5f.create_dataset("z2", data=z2)
        h5f.create_dataset("t21_map", data=t21_map)
        h5f.create_dataset("gal_map", data=gal_map)
        h5f.create_dataset("ion_map", data=ion_map)

# rescale
tfac = 1e6 * tcmb
ksz_map *= tfac

print(f"reading {f_ell_fn}...")
with h5py.File(f_ell_fn, "r") as h5f:
    f_ell_array = h5f["f_ell"][()]

# make plots
print("plotting...")

matplotlib.rc("text", usetex=True)
matplotlib.rc("font", family="serif")

# 21cm
fig = plt.figure()
ax = plt.gca()

theta_deg = theta_max * 180.0 / np.pi
extent = [-theta_deg / 2, theta_deg / 2, -theta_deg / 2, theta_deg / 2]
im = ax.imshow(t21_map, extent=extent, cmap="plasma", vmin=0.0, vmax=20.0)
cb = plt.colorbar(im)

ax.set_xlabel(r"$\Theta$ [deg]", fontsize=fontsize)
ax.set_ylabel(r"$\Theta$ [deg]", fontsize=fontsize)
cb.set_label(r"$\delta T_b$ [mK]", fontsize=fontsize)
ax.tick_params(axis="both", labelsize=sm_fontsize)
cb.ax.tick_params(labelsize=sm_fontsize)
if use_titles:
    ax.set_title(rf"21\,cm, ${z1} \leq z \leq {z2}$")

date = datetime.date.today().strftime("%y%m%d")
plots_dir = os.path.join(save_dir, "plots", date)
if not os.path.isdir(plots_dir):
    os.makedirs(plots_dir)
output = os.path.join(plots_dir, "t21.pdf")
print(f"saving {output}...")
fig.savefig(output, bbox_inches="tight", transparent=transparent)
plt.close(fig)


# kSZ
fig = plt.figure()
ax = plt.gca()

theta_deg = theta_max * 180.0 / np.pi
extent = [-theta_deg / 2, theta_deg / 2, -theta_deg / 2, theta_deg / 2]
tmax = np.amax(np.abs(ksz_map))
im = ax.imshow(ksz_map, extent=extent, cmap="RdBu", vmin=-tmax, vmax=tmax)
cb = plt.colorbar(im)

ax.set_xlabel(r"$\Theta$ [deg]", fontsize=fontsize)
ax.set_ylabel(r"$\Theta$ [deg]", fontsize=fontsize)
cb.set_label(r"$\Delta T$ [$\mu$K]", fontsize=fontsize)
ax.tick_params(axis="both", labelsize=sm_fontsize)
cb.ax.tick_params(labelsize=sm_fontsize)
if use_titles:
    ax.set_title("kSZ")

date = datetime.date.today().strftime("%y%m%d")
plots_dir = os.path.join(save_dir, "plots", date)
if not os.path.isdir(plots_dir):
    os.makedirs(plots_dir)
output = os.path.join(plots_dir, "ksz.pdf")
print(f"saving {output}...")
fig.savefig(output, bbox_inches="tight", transparent=transparent)
plt.close(fig)


# galaxies
fig = plt.figure()
ax = plt.gca()

theta_deg = theta_max * 180.0 / np.pi
extent = [-theta_deg / 2, theta_deg / 2, -theta_deg / 2, theta_deg / 2]
im = ax.imshow(gal_map, extent=extent, cmap="viridis")
cb = plt.colorbar(im)

ax.set_xlabel(r"$\Theta$ [deg]", fontsize=fontsize)
ax.set_ylabel(r"$\Theta$ [deg]", fontsize=fontsize)
cb.set_label(r"$\delta_g$", fontsize=fontsize)
ax.tick_params(axis="both", labelsize=sm_fontsize)
cb.ax.tick_params(labelsize=sm_fontsize)
if use_titles:
    ax.set_title(rf"Galaxies, ${z1} \leq z \leq {z2}$")

date = datetime.date.today().strftime("%y%m%d")
plots_dir = os.path.join(save_dir, "plots", date)
if not os.path.isdir(plots_dir):
    os.makedirs(plots_dir)
output = os.path.join(plots_dir, "gal.pdf")
print(f"saving {output}...")
fig.savefig(output, bbox_inches="tight", transparent=transparent)
plt.close(fig)


# low-pass galaxies
gal_ft = np.fft.rfft2(gal_map)
apply_lowpass_filter(gal_ft, ell_max, theta_max)
gal_ift = np.fft.irfft2(gal_ft)

# compute RMS
gal_rms = np.sqrt(np.average(gal_ift**2))
print("filtered delta_g RMS: ",gal_rms)

fig = plt.figure()
ax = plt.gca()

theta_deg = theta_max * 180.0 / np.pi
extent = [-theta_deg / 2, theta_deg / 2, -theta_deg / 2, theta_deg / 2]
im = ax.imshow(gal_ift, extent=extent, cmap="viridis")
cb = plt.colorbar(im)

ax.set_xlabel(r"$\Theta$ [deg]", fontsize=fontsize)
ax.set_ylabel(r"$\Theta$ [deg]", fontsize=fontsize)
cb.set_label(r"$\delta_g$", fontsize=fontsize)
ax.tick_params(axis="both", labelsize=sm_fontsize)
cb.ax.tick_params(labelsize=sm_fontsize)

date = datetime.date.today().strftime("%y%m%d")
plots_dir = os.path.join(save_dir, "plots", date)
if not os.path.isdir(plots_dir):
    os.makedirs(plots_dir)
output = os.path.join(plots_dir, "gal_filt.pdf")
print(f"saving {output}...")
fig.savefig(output, bbox_inches="tight", transparent=transparent)
plt.close(fig)


# ksz^2
ksz_ft = np.fft.rfft2(ksz_map)
apply_wiener_filter(ksz_ft, f_ell_array, theta_max)
ksz_ift = np.fft.irfft2(ksz_ft)
ksz_ift *= ksz_ift

# print max
print("max value: ", np.amax(ksz_ift))

# compute RMS
ksz2_rms = np.sqrt(np.average(ksz_ift**2))
print("ksz^2 RMS [uK^2]: ", ksz2_rms)

fig = plt.figure()
ax = plt.gca()

theta_deg = theta_max * 180.0 / np.pi
extent = [-theta_deg / 2, theta_deg / 2, -theta_deg / 2, theta_deg / 2]
im = ax.imshow(ksz_ift, extent=extent, cmap="inferno", vmax=5)
cb = plt.colorbar(im)

ax.set_xlabel(r"$\Theta$ [deg]", fontsize=fontsize)
ax.set_ylabel(r"$\Theta$ [deg]", fontsize=fontsize)
cb.set_label(r"kSZ$^2$ [$\mu$K$^2$]", fontsize=fontsize)
ax.tick_params(axis="both", labelsize=sm_fontsize)
cb.ax.tick_params(labelsize=sm_fontsize)
if use_titles:
    ax.set_title("kSZ$^2$")

date = datetime.date.today().strftime("%y%m%d")
plots_dir = os.path.join(save_dir, "plots", date)
if not os.path.isdir(plots_dir):
    os.makedirs(plots_dir)
output = os.path.join(plots_dir, "ksz2.pdf")
print(f"saving {output}...")
fig.savefig(output, bbox_inches="tight", transparent=transparent)
plt.close(fig)


# ionization field
fig = plt.figure()
ax = plt.gca()

theta_deg = theta_max * 180.0 / np.pi
extent = [-theta_deg / 2, theta_deg / 2, -theta_deg / 2, theta_deg / 2]
im = ax.imshow(ion_map, extent=extent, cmap="magma")
cb = plt.colorbar(im)

ax.set_xlabel(r"$\Theta$ [deg]", fontsize=fontsize)
ax.set_ylabel(r"$\Theta$ [deg]", fontsize=fontsize)
cb.set_label(r"$x_\mathrm{HII}$", fontsize=fontsize)
ax.tick_params(axis="both", labelsize=sm_fontsize)
cb.ax.tick_params(labelsize=sm_fontsize)

date = datetime.date.today().strftime("%y%m%d")
plots_dir = os.path.join(save_dir, "plots", date)
if not os.path.isdir(plots_dir):
    os.makedirs(plots_dir)
output = os.path.join(plots_dir, "ion.pdf")
print(f"saving {output}...")
fig.savefig(output, bbox_inches="tight", transparent=transparent)
plt.close(fig)


# low-pass ionization field
ion_ft = np.fft.rfft2(ion_map)
apply_lowpass_filter(ion_ft, ell_max, theta_max)
ion_ift = np.fft.irfft2(ion_ft)

fig = plt.figure()
ax = plt.gca()

theta_deg = theta_max * 180.0 / np.pi
extent = [-theta_deg / 2, theta_deg / 2, -theta_deg / 2, theta_deg / 2]
im = ax.imshow(ion_ift, extent=extent, cmap="magma")
cb = plt.colorbar(im)

ax.set_xlabel(r"$\Theta$ [deg]", fontsize=fontsize)
ax.set_ylabel(r"$\Theta$ [deg]", fontsize=fontsize)
cb.set_label(r"$x_\mathrm{HII}$", fontsize=fontsize)
ax.tick_params(axis="both", labelsize=sm_fontsize)
cb.ax.tick_params(labelsize=sm_fontsize)

date = datetime.date.today().strftime("%y%m%d")
plots_dir = os.path.join(save_dir, "plots", date)
if not os.path.isdir(plots_dir):
    os.makedirs(plots_dir)
output = os.path.join(plots_dir, "ion_filt.pdf")
print(f"saving {output}...")
fig.savefig(output, bbox_inches="tight", transparent=transparent)
plt.close(fig)


if plot_wedge:
    # T21 wedge filtered
    t21_ft = np.fft.rfftn(t21_box)
    apply_wedge_filter(t21_ft, 3.0)
    t21_ift = np.fft.irfftn(t21_ft)
    lx = t21_ift.shape[0]
    t21_wedge_map = np.average(t21_ift[lx // 4 : 3 * lx // 4, :, :], axis=0)

    fig = plt.figure()
    ax = plt.gca()

    theta_deg = theta_max * 180.0 / np.pi
    extent = [-theta_deg / 2, theta_deg / 2, -theta_deg / 2, theta_deg / 2]
    im = ax.imshow(t21_wedge_map, extent=extent, cmap="plasma")
    cb = plt.colorbar(im)

    ax.set_xlabel(r"$\Theta$ [deg]", fontsize=fontsize)
    ax.set_ylabel(r"$\Theta$ [deg]", fontsize=fontsize)
    cb.set_label(r"$\delta T_b$ [mK]", fontsize=fontsize)
    ax.tick_params(axis="both", labelsize=sm_fontsize)
    cb.ax.tick_params(labelsize=sm_fontsize)
    if use_titles:
        ax.set_title("21\,cm -- wedge filtered")

    date = datetime.date.today().strftime("%y%m%d")
    plots_dir = os.path.join(save_dir, "plots", date)
    if not os.path.isdir(plots_dir):
        os.makedirs(plots_dir)
    output = os.path.join(plots_dir, "t21_wedge.pdf")
    print(f"saving {output}...")
    fig.savefig(output, bbox_inches="tight", transparent=transparent)
    plt.close(fig)
