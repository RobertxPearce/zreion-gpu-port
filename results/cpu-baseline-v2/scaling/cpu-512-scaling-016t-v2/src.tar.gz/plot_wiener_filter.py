# -*- coding: utf-8 -*-

import os
import datetime
import h5py
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

dark_background = False

if dark_background:
    plt.style.use("dark_background")
    transparent = True
else:
    transparent = False

fontsize = 20
sm_fontsize = 14

# define data input location
data_dir = "/ocean/projects/ast180004p/jsipple/ksz/extended_output"

# define data output location
out_dir = "/ocean/projects/ast190007p/plaplant/ksz/plots"

# read in data to plot
f_ell_so_fn = os.path.join(data_dir, "f_ell_so_ilc.hdf5")
f_ell_s4_fn = os.path.join(data_dir, "f_ell_s4_ilc.hdf5")
f_ell_hd_fn = os.path.join(data_dir, "f_ell_hd_ilc.hdf5")

with h5py.File(f_ell_so_fn, "r") as h5f:
    f_ell_so = h5f["f_ell"][()]

with h5py.File(f_ell_s4_fn, "r") as h5f:
    f_ell_s4 = h5f["f_ell"][()]

with h5py.File(f_ell_hd_fn, "r") as h5f:
    f_ell_hd = h5f["f_ell"][()]

# plot data
matplotlib.rc("text", usetex=True)
matplotlib.rc("font", family="serif")

linewidth = 1.5
alpha = 1.0

fig = plt.figure()
ax = plt.gca()

ax.plot(
    f_ell_so[:, 0],
    f_ell_so[:, 1],
    label="SO",
    linestyle="-",
    linewidth=linewidth,
    alpha=alpha,
)
ax.plot(
    f_ell_s4[:, 0],
    f_ell_s4[:, 1],
    label="CMB-S4",
    linestyle="--",
    linewidth=linewidth,
    alpha=alpha,
)
ax.plot(
    f_ell_hd[:, 0],
    f_ell_hd[:, 1],
    label="CMB-HD",
    linestyle=":",
    linewidth=linewidth,
    alpha=alpha,
)

ax.set_xlabel(r"$\ell$", fontsize=fontsize)
ax.set_ylabel(r"$f(\ell)$ [arbitrary normalization]", fontsize=fontsize)
ax.legend(loc=0, prop={"size": sm_fontsize})
ax.tick_params(axis="both", labelsize=sm_fontsize)

date = datetime.date.today().strftime("%y%m%d")
plots_dir = os.path.join(out_dir, date)
if not os.path.isdir(plots_dir):
    os.makedirs(plots_dir)
fn_out = os.path.join(plots_dir, "f_ell.pdf")
print(f"saving {fn_out}...")
fig.savefig(fn_out, bbox_inches="tight", transparent=transparent)
plt.close(fig)
