# -*- coding: utf-8 -*-

import os
import datetime
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


cl_t2t2_so = np.genfromtxt("data/cl_t2t2.txt")
cl_t2t2_s4 = np.genfromtxt("data/cl_t2t2_s4.txt")
cl_t2t2_so_ilc = np.genfromtxt("data/cl_t2t2_so_ilc.txt")
cl_t2t2_s4_ilc = np.genfromtxt("data/cl_t2t2_s4_ilc.txt")
cl_t2t2_hd_ilc = np.genfromtxt("data/cl_t2t2_hd_ilc.txt")

matplotlib.rc("text", usetex=True)
matplotlib.rc("font", family="serif")

fig = plt.figure()
ax = plt.gca()

ells = cl_t2t2_so[:, 0]
dl_t2t2_so = ells * (ells + 1) * cl_t2t2_so[:, 1] / (2 * np.pi)
# l1, = ax.loglog(ells, dl_t2t2_so, color="C0", linestyle="-")

ells = cl_t2t2_s4[:, 0]
dl_t2t2_s4 = ells * (ells + 1) * cl_t2t2_s4[:, 1] / (2 * np.pi)
# l2, = ax.loglog(ells, dl_t2t2_s4, color="C1", linestyle="-")

ells = cl_t2t2_so_ilc[:, 0]
dl_t2t2_so_ilc = ells * (ells + 1) * cl_t2t2_so_ilc[:, 1] / (2 * np.pi)
l3, = ax.loglog(ells, dl_t2t2_so_ilc, color="C0", linestyle="-", label="SO")

ells = cl_t2t2_s4_ilc[:, 0]
dl_t2t2_s4_ilc = ells * (ells + 1) * cl_t2t2_s4_ilc[:, 1] / (2 * np.pi)
l4, = ax.loglog(ells, dl_t2t2_s4_ilc, color="C1", linestyle="--", label="S4")

ells = cl_t2t2_hd_ilc[:, 0]
dl_t2t2_hd_ilc = ells * (ells + 1) * cl_t2t2_hd_ilc[:, 1] / (2 * np.pi)
l5, = ax.loglog(ells, dl_t2t2_hd_ilc, color="C2", linestyle=":", label="HD")

ax.set_xlabel(r"$\ell$")
ax.set_ylabel(r"$\ell(\ell+1)C_\ell^{\bar{T}^2\bar{T}^2,f}/2\pi$")
# lines = [l1, l2, l1, l3]
# labels = ["SO", "S4", r'Na\"\i ve', "ILC"]
# ax.legend(lines, labels, loc=0, ncol=2)
ax.legend(loc=0)

date = datetime.date.today().strftime("%y%m%d")
plots_dir = os.path.join("/jet/home/plaplant/scratch_ml/ksz/fiducial/bt_bias/plots", date)
if not os.path.isdir(plots_dir):
    os.makedirs(plots_dir)
output = os.path.join(plots_dir, "ct2t2_comp.pdf")
print(f"saving {output}...")
fig.savefig(output, bbox_inches="tight")
plt.close(fig)
