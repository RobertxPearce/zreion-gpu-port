#!/bin/bash
#SBATCH -J ksz_2lpt
#SBATCH -p RM
#SBATCH -t 8:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node 128
#SBATCH -o std.log
#SBATCH -A ast180004p
#SBATCH --mail-type ALL
#SBATCH --mail-user robertbdpearce@gmail.com

# Intel
module unload intel
module load intel-icc
module load intel-mkl
which ifort

# set environment variables
export KMP_LIBRARY=turnaround
export KMP_SCHEDULE=static,balanced
export KMP_STACKSIZE=256m

# Go to the job scratch directory
cd $SLURM_SUBMIT_DIR

# Compile and run the job
make clean
make ksz_2lpt.x

# Run just the simulation
./ksz_2lpt.x > log
