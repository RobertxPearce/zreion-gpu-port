module checkpoint_tools
  ! Intel
  use IFPORT
  use OMP_LIB


  ! HDF5
  use ISO_C_BINDING
  use HDF5


  ! Global
  use global


  ! Default
  implicit none


  ! Routine-boundary checkpoints for validating the GPU port.
  !
  ! One file per run, <dir_out>/checkpoints.hdf5, holding the full input and
  ! output arrays of the expensive routines so each one can be replayed and
  ! diffed in isolation. Written only when checkpoint_level >= 1.
  !
  ! Deliberately no statistics here. min/max/mean/std/L2/NaN counts are computed
  ! in scripts/validation/metrics.py from the saved arrays, so the CPU and the
  ! GPU are never compared through two separate definitions of "the mean".
  !
  ! Real-space arrays are written without their FFT padding: the first dimension
  ! of the working arrays is Ndm+2 or N_grid+2, of which only the first
  ! Ndm/N_grid columns are physical. Fourier-space arrays (the *_k datasets) are
  ! the exception and are written at full width -- see ckpt_kspace. Everything
  ! is real(8), C-contiguous on disk, and indexed [k,j,i] from Python.
  !
  ! The repeated routines are checkpointed on their first call only. That call
  ! is calc_zreion's, at z = zmean_zre, which is both the first and the
  ! scientifically central one; the remaining 21 calls differ only in redshift.


  ! File handle. Negative means "not open".
  integer(HID_T) :: ckpt_file_id = -1

  ! Calls to calc_density_velocity_fields so far, for first-call guards.
  integer(4) :: ckpt_ndvf = 0


contains


  logical function ckpt_on()
    ! Default
    implicit none

    ckpt_on = (checkpoint_level >= 1 .and. ckpt_file_id >= 0)
    return
  end function ckpt_on


!------------------------------------------------------------------------------!


  subroutine ckpt_open
    ! Default
    implicit none


    ! Local variables
    integer(4)      :: error
    character(1000) :: fn


    if (checkpoint_level < 1) return

    fn = trim(dir_out)//fn_ckpt
    write(*,*) "Writing ",trim(fn)

    call h5open_f(error)
    call h5fcreate_f(trim(fn), H5F_ACC_TRUNC_F, ckpt_file_id, error)

    ! Fresh file, fresh first-call guards -- N_sims > 1 reuses this program.
    ckpt_ndvf = 0

    return
  end subroutine ckpt_open


!------------------------------------------------------------------------------!


  subroutine ckpt_close
    ! Default
    implicit none


    ! Local variables
    integer(4)     :: error
    integer(HID_T) :: group_id


    if (ckpt_file_id < 0) return

    ! Header is written last because iseed_run -- the one field here that cannot
    ! be recovered from anywhere else -- is not known until the GRF is drawn.
    ! The full cosmology header is in obs_grids.hdf5; this is just enough to say
    ! which run the file belongs to and how to regenerate its initial field.
    call h5gcreate_f(ckpt_file_id, "/header", group_id, error)
    call ckpt_attr_int(group_id, "Ndm",              Ndm)
    call ckpt_attr_int(group_id, "N_grid",           N_grid)
    call ckpt_attr_int(group_id, "N_cpu",            N_cpu)
    call ckpt_attr_int(group_id, "Ndomain",          Ndomain)
    call ckpt_attr_int(group_id, "checkpoint_level", checkpoint_level)
    call ckpt_attr_int(group_id, "iseed",            iseed_run)
    call ckpt_attr_dbl(group_id, "BoxSize",          box)
    call ckpt_attr_dbl(group_id, "zmean_zre",        zmean_zre)
    call ckpt_attr_dbl(group_id, "alpha_zre",        alpha_zre)
    call ckpt_attr_dbl(group_id, "kb_zre",           kb_zre)
    call ckpt_attr_dbl(group_id, "b0_zre",           b0_zre)
    call h5gclose_f(group_id, error)

    call h5fclose_f(ckpt_file_id, error)
    ckpt_file_id = -1

    return
  end subroutine ckpt_close


!------------------------------------------------------------------------------!


  subroutine ckpt_attr_int(loc_id, name, value)
    ! Default
    implicit none


    ! Subroutine arguments
    integer(HID_T), intent(in) :: loc_id
    character(*),   intent(in) :: name
    integer(4),     intent(in) :: value


    ! Local variables
    integer(4)         :: error
    integer(4), target :: v
    integer(HID_T)     :: dspace_id,dset_id
    type(C_PTR)        :: f_ptr


    v     = value
    f_ptr = c_loc(v)
    call h5screate_f(H5S_SCALAR_F, dspace_id, error)
    call h5dcreate_f(loc_id, name, H5T_NATIVE_INTEGER, dspace_id, dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_INTEGER, f_ptr, error)
    call h5dclose_f(dset_id, error)
    call h5sclose_f(dspace_id, error)

    return
  end subroutine ckpt_attr_int


!------------------------------------------------------------------------------!


  subroutine ckpt_attr_dbl(loc_id, name, value)
    ! Default
    implicit none


    ! Subroutine arguments
    integer(HID_T), intent(in) :: loc_id
    character(*),   intent(in) :: name
    real(8),        intent(in) :: value


    ! Local variables
    integer(4)     :: error
    integer(HID_T) :: dspace_id,dset_id
    integer(HSIZE_T), dimension(1) :: ddims


    ddims = (/ 1 /)
    call h5screate_f(H5S_SCALAR_F, dspace_id, error)
    call h5dcreate_f(loc_id, name, H5T_NATIVE_DOUBLE, dspace_id, dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, value, ddims, error)
    call h5dclose_f(dset_id, error)
    call h5sclose_f(dspace_id, error)

    return
  end subroutine ckpt_attr_dbl


!------------------------------------------------------------------------------!


  subroutine ckpt_group(name, group_id)
    ! Open the named group, creating it the first time. Several routines write
    ! more than one array, so the group outlives any single call.
    !
    ! Default
    implicit none


    ! Subroutine arguments
    character(*),   intent(in)  :: name
    integer(HID_T), intent(out) :: group_id


    ! Local variables
    integer(4) :: error
    logical    :: exists


    call h5lexists_f(ckpt_file_id, name, exists, error)
    if (exists) then
       call h5gopen_f(ckpt_file_id, name, group_id, error)
    else
       call h5gcreate_f(ckpt_file_id, name, group_id, error)
    endif

    return
  end subroutine ckpt_group


!------------------------------------------------------------------------------!


  subroutine ckpt_scalar(gname, dname, a, nv, n2, n3)
    ! Write the physical region of a padded real-space scalar field:
    ! a(1:nv,1:n2,1:n3) out of a(nv+2,n2,n3). densityA/B, zreion, rho, ion and
    ! tbg have this layout. Only valid in real space -- a field that has been
    ! forward transformed goes through ckpt_kspace instead.
    !
    ! Default
    implicit none


    ! Subroutine arguments
    character(*), intent(in) :: gname,dname
    integer(4),   intent(in) :: nv,n2,n3
    real(8),      intent(in), dimension(nv+2,n2,n3) :: a


    ! Local variables
    integer(4)     :: error
    integer(HID_T) :: group_id,dset_id,memspace,dspace
    integer(HSIZE_T), dimension(3) :: mem_dims,offset,count3,out_dims


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2


    if (.not. ckpt_on()) return

    call time(ts1)
    tr1 = omp_get_wtime()

    mem_dims = (/ nv+2, n2, n3 /)
    offset   = (/ 0, 0, 0 /)
    count3   = (/ nv, n2, n3 /)
    out_dims = (/ nv, n2, n3 /)

    call ckpt_group(gname, group_id)
    call h5screate_simple_f(3, mem_dims, memspace, error)
    call h5sselect_hyperslab_f(memspace, H5S_SELECT_SET_F, offset, count3, error)
    call h5screate_simple_f(3, out_dims, dspace, error)
    call h5dcreate_f(group_id, dname, H5T_NATIVE_DOUBLE, dspace, dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, a, mem_dims, error, &
         memspace, dspace)
    call h5dclose_f(dset_id, error)
    call h5sclose_f(dspace, error)
    call h5sclose_f(memspace, error)
    call h5gclose_f(group_id, error)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2, &
         '  Called ckpt '//gname//'/'//dname
    return
  end subroutine ckpt_scalar


!------------------------------------------------------------------------------!


  subroutine ckpt_kspace(gname, dname, a, nv, n2, n3)
    ! Write a forward-transformed field in full: all of a(nv+2,n2,n3).
    !
    ! After the in-place real-to-complex FFT the first dimension holds nv/2+1
    ! complex values stored as interleaved (re,im) pairs, kx = 0 .. nv/2. The
    ! last two columns are the kx = nv/2 Nyquist plane, which is data here, not
    ! padding, so ckpt_scalar's 1:nv slice would drop it. From Python the
    ! dataset is shape (n3, n2, nv+2); a[..., 0::2] + 1j*a[..., 1::2] recovers
    ! the complex array. delta1 after calc_delta_field and delta2 after
    ! calc_gradphi_2 have this layout.
    !
    ! Default
    implicit none


    ! Subroutine arguments
    character(*), intent(in) :: gname,dname
    integer(4),   intent(in) :: nv,n2,n3
    real(8),      intent(in), dimension(nv+2,n2,n3) :: a


    ! Local variables
    integer(4)     :: error
    integer(HID_T) :: group_id,dset_id,dspace
    integer(HSIZE_T), dimension(3) :: out_dims


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2


    if (.not. ckpt_on()) return

    call time(ts1)
    tr1 = omp_get_wtime()

    out_dims = (/ nv+2, n2, n3 /)

    call ckpt_group(gname, group_id)
    call h5screate_simple_f(3, out_dims, dspace, error)
    call h5dcreate_f(group_id, dname, H5T_NATIVE_DOUBLE, dspace, dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, a, out_dims, error)
    call h5dclose_f(dset_id, error)
    call h5sclose_f(dspace, error)
    call h5gclose_f(group_id, error)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2, &
         '  Called ckpt '//gname//'/'//dname
    return
  end subroutine ckpt_kspace


!------------------------------------------------------------------------------!


  subroutine ckpt_comp_last(gname, dname, a, nv, n2, n3, nc, ic)
    ! One component of a padded vector field whose component index is last:
    ! a(nv+2,n2,n3,nc), as gradphi is stored.
    !
    ! Default
    implicit none


    ! Subroutine arguments
    character(*), intent(in) :: gname,dname
    integer(4),   intent(in) :: nv,n2,n3,nc,ic
    real(8),      intent(in), dimension(nv+2,n2,n3,nc) :: a


    ! Local variables
    integer(4)     :: error
    integer(HID_T) :: group_id,dset_id,memspace,dspace
    integer(HSIZE_T), dimension(4) :: mem_dims,offset,count4
    integer(HSIZE_T), dimension(3) :: out_dims


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2


    if (.not. ckpt_on()) return

    call time(ts1)
    tr1 = omp_get_wtime()

    mem_dims = (/ nv+2, n2, n3, nc /)
    offset   = (/ 0, 0, 0, ic-1 /)
    count4   = (/ nv, n2, n3, 1 /)
    out_dims = (/ nv, n2, n3 /)

    call ckpt_group(gname, group_id)
    call h5screate_simple_f(4, mem_dims, memspace, error)
    call h5sselect_hyperslab_f(memspace, H5S_SELECT_SET_F, offset, count4, error)
    call h5screate_simple_f(3, out_dims, dspace, error)
    call h5dcreate_f(group_id, dname, H5T_NATIVE_DOUBLE, dspace, dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, a, mem_dims, error, &
         memspace, dspace)
    call h5dclose_f(dset_id, error)
    call h5sclose_f(dspace, error)
    call h5sclose_f(memspace, error)
    call h5gclose_f(group_id, error)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2, &
         '  Called ckpt '//gname//'/'//dname
    return
  end subroutine ckpt_comp_last


!------------------------------------------------------------------------------!


  subroutine ckpt_comp_first(gname, dname, a, nc, n1, n2, n3, ic)
    ! One component of an unpadded vector field whose component index is first:
    ! a(nc,n1,n2,n3), as velocityA/B are stored.
    !
    ! Default
    implicit none


    ! Subroutine arguments
    character(*), intent(in) :: gname,dname
    integer(4),   intent(in) :: nc,n1,n2,n3,ic
    real(8),      intent(in), dimension(nc,n1,n2,n3) :: a


    ! Local variables
    integer(4)     :: error
    integer(HID_T) :: group_id,dset_id,memspace,dspace
    integer(HSIZE_T), dimension(4) :: mem_dims,offset,count4
    integer(HSIZE_T), dimension(3) :: out_dims


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2


    if (.not. ckpt_on()) return

    call time(ts1)
    tr1 = omp_get_wtime()

    mem_dims = (/ nc, n1, n2, n3 /)
    offset   = (/ ic-1, 0, 0, 0 /)
    count4   = (/ 1, n1, n2, n3 /)
    out_dims = (/ n1, n2, n3 /)

    call ckpt_group(gname, group_id)
    call h5screate_simple_f(4, mem_dims, memspace, error)
    call h5sselect_hyperslab_f(memspace, H5S_SELECT_SET_F, offset, count4, error)
    call h5screate_simple_f(3, out_dims, dspace, error)
    call h5dcreate_f(group_id, dname, H5T_NATIVE_DOUBLE, dspace, dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, a, mem_dims, error, &
         memspace, dspace)
    call h5dclose_f(dset_id, error)
    call h5sclose_f(dspace, error)
    call h5sclose_f(memspace, error)
    call h5gclose_f(group_id, error)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2, &
         '  Called ckpt '//gname//'/'//dname
    return
  end subroutine ckpt_comp_first


!------------------------------------------------------------------------------!


  subroutine ckpt_map(gname, dname, a, n1, n2)
    ! An unpadded 2D map. Cheap at every grid size, so always written in full.
    !
    ! Default
    implicit none


    ! Subroutine arguments
    character(*), intent(in) :: gname,dname
    integer(4),   intent(in) :: n1,n2
    real(8),      intent(in), dimension(n1,n2) :: a


    ! Local variables
    integer(4)     :: error
    integer(HID_T) :: group_id,dset_id,dspace
    integer(HSIZE_T), dimension(2) :: out_dims


    if (.not. ckpt_on()) return

    out_dims = (/ n1, n2 /)

    call ckpt_group(gname, group_id)
    call h5screate_simple_f(2, out_dims, dspace, error)
    call h5dcreate_f(group_id, dname, H5T_NATIVE_DOUBLE, dspace, dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, a, out_dims, error)
    call h5dclose_f(dset_id, error)
    call h5sclose_f(dspace, error)
    call h5gclose_f(group_id, error)

    return
  end subroutine ckpt_map


!------------------------------------------------------------------------------!


  subroutine write_gaussian_random_field
    ! Save the real-space initial field as <dir_out>/grf.hdf5.
    !
    ! This is the reproducibility anchor for the port: the GPU loads this exact
    ! field rather than trying to make cuRAND reproduce MKL's MT19937 stream
    ! order. The seed in the header regenerates the same file on any machine
    ! with MKL, so the two are redundant on purpose -- the seed is four bytes of
    ! insurance, the file is the copy that needs no Intel toolchain to read.
    !
    ! Default
    implicit none


    ! Local variables
    integer(4)      :: error
    integer(HID_T)  :: file_id,dset_id,data_id,head_id
    integer(HID_T)  :: memspace,dspace
    character(1000) :: fn
    integer(HSIZE_T), dimension(3) :: mem_dims,offset,count3,out_dims


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2


    if (.not. save_grf) return

    call time(ts1)
    tr1 = omp_get_wtime()

    fn = trim(dir_out)//fn_grf
    write(*,*) 'Writing ',trim(fn)

    call h5open_f(error)
    call h5fcreate_f(trim(fn), H5F_ACC_TRUNC_F, file_id, error)

    call h5gcreate_f(file_id, "/header", head_id, error)
    call ckpt_attr_int(head_id, "Ndm",     Ndm)
    call ckpt_attr_int(head_id, "N_grid",  N_grid)
    call ckpt_attr_int(head_id, "iseed",   iseed_run)
    call ckpt_attr_dbl(head_id, "BoxSize", box)
    call h5gclose_f(head_id, error)

    ! Physical region only: delta1 is dimensioned (Ndm+2,Ndm,Ndm) and the last
    ! two columns of the first dimension are FFT scratch, not part of the field.
    call h5gcreate_f(file_id, "/data", data_id, error)

    mem_dims = (/ Ndm+2, Ndm, Ndm /)
    offset   = (/ 0, 0, 0 /)
    count3   = (/ Ndm, Ndm, Ndm /)
    out_dims = (/ Ndm, Ndm, Ndm /)

    call h5screate_simple_f(3, mem_dims, memspace, error)
    call h5sselect_hyperslab_f(memspace, H5S_SELECT_SET_F, offset, count3, error)
    call h5screate_simple_f(3, out_dims, dspace, error)
    call h5dcreate_f(data_id, "delta1", H5T_NATIVE_DOUBLE, dspace, dset_id, error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, delta1, mem_dims, error, &
         memspace, dspace)
    call h5dclose_f(dset_id, error)
    call h5sclose_f(dspace, error)
    call h5sclose_f(memspace, error)
    call h5gclose_f(data_id, error)
    call h5fclose_f(file_id, error)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2, &
         '  Called write gaussian random field'
    return
  end subroutine write_gaussian_random_field


!------------------------------------------------------------------------------!


  subroutine read_gaussian_random_field
    ! Load <dir_out>/grf.hdf5 in place of drawing a new field.
    !
    ! The file holds the field in real space, so calc_delta_field still has to
    ! take its forward FFT -- unlike the raw-binary format this replaced, which
    ! stored the already-transformed array and made the transform conditional.
    !
    ! Default
    implicit none


    ! Local variables
    integer(4)         :: i,j,k,error
    integer(4), target :: ndm_file,iseed_file
    real(8)            :: d,davg,dsig,dmax,dmin
    integer(HID_T)     :: file_id,dset_id,memspace,dspace
    type(C_PTR)        :: f_ptr
    character(1000)    :: fn
    integer(HSIZE_T), dimension(3) :: mem_dims,offset,count3,out_dims


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    fn = trim(dir_out)//fn_grf
    write(*,*) 'Reading ',trim(fn)

    call h5open_f(error)
    call h5fopen_f(trim(fn), H5F_ACC_RDONLY_F, file_id, error)
    if (error /= 0) then
       write(*,*) "read_gaussian_random_field: cannot open ",trim(fn)
       stop 1
    endif

    ! Refuse a field built for a different grid rather than reading garbage.
    call h5dopen_f(file_id, "/header/Ndm", dset_id, error)
    f_ptr = c_loc(ndm_file)
    call h5dread_f(dset_id, H5T_NATIVE_INTEGER, f_ptr, error)
    call h5dclose_f(dset_id, error)
    if (ndm_file /= Ndm) then
       write(*,*) "read_gaussian_random_field: file has Ndm = ",ndm_file, &
            " but this build has Ndm = ",Ndm
       stop 1
    endif

    ! Carry the originating seed forward so a replay's products still name the
    ! realization they came from, and the log line matches a generating run's.
    call h5dopen_f(file_id, "/header/iseed", dset_id, error)
    f_ptr = c_loc(iseed_file)
    call h5dread_f(dset_id, H5T_NATIVE_INTEGER, f_ptr, error)
    call h5dclose_f(dset_id, error)
    iseed_run = iseed_file
    write(*,*) "GRF seed: ",iseed_run

    ! Zero the array first: the read fills only the physical region, and the FFT
    ! padding must not carry whatever init_fields or a previous sim left there.
    !$omp parallel do     &
    !$omp default(shared) &
    !$omp private(k)
    do k=1,Ndm
       delta1(:,:,k) = 0
    enddo
    !$omp end parallel do

    mem_dims = (/ Ndm+2, Ndm, Ndm /)
    offset   = (/ 0, 0, 0 /)
    count3   = (/ Ndm, Ndm, Ndm /)
    out_dims = (/ Ndm, Ndm, Ndm /)

    call h5screate_simple_f(3, mem_dims, memspace, error)
    call h5sselect_hyperslab_f(memspace, H5S_SELECT_SET_F, offset, count3, error)
    call h5screate_simple_f(3, out_dims, dspace, error)
    call h5dopen_f(file_id, "/data/delta1", dset_id, error)
    call h5dread_f(dset_id, H5T_NATIVE_DOUBLE, delta1, mem_dims, error, &
         memspace, dspace)
    call h5dclose_f(dset_id, error)
    call h5sclose_f(dspace, error)
    call h5sclose_f(memspace, error)
    call h5fclose_f(file_id, error)

    ! Same check make_gaussian_random_field prints, so the two are comparable
    ! line for line in the run log.
    davg = 0
    dsig = 0
    dmax = 0
    dmin = huge(dmin)

    !$omp parallel do            &
    !$omp default(shared)        &
    !$omp private(i,j,k,d)       &
    !$omp reduction(+:davg,dsig) &
    !$omp reduction(max:dmax)    &
    !$omp reduction(min:dmin)
    do k=1,Ndm
       do j=1,Ndm
          do i=1,Ndm
             d    = delta1(i,j,k)
             davg = davg + d
             dsig = dsig + d**2
             dmax = max(dmax,d)
             dmin = min(dmin,d)
          enddo
       enddo
    enddo
    !$omp end parallel do

    ! Field is normalized so that sigma**2(cell) = 1
    davg = davg/Npart
    dsig = sqrt(dsig/Npart - davg**2)
    write(*,*) "GRF: ",real((/davg,dsig,dmin,dmax/))


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2, &
         '  Called read gaussian random field'
    return
  end subroutine read_gaussian_random_field


end module checkpoint_tools
