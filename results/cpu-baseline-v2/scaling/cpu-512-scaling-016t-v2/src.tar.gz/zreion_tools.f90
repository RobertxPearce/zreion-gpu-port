module zreion_tools
  ! Intel
  use IFPORT
  use OMP_LIB


  ! Global
  use global


  ! Tools
  use general_tools
  use cosmo_tools
  use field_tools
  use fft_tools
  use checkpoint_tools


  ! Default
  implicit none


contains


  subroutine calc_zreion
    ! Default
    implicit none


    ! Local parameters
    real(8), parameter :: Ak = 2*pi/ngridr


    ! Local variables
    integer(4) :: i,j,k,iz
    real(8)    :: kx,ky,kz,kr
    real(8)    :: wcell,wsmooth,x
    real(8)    :: z,zavg,zstd,zmax,zmin,zval,xavg,xmavg


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Compute density field at z = zmean_zre
    density1  => densityA
    velocity1 => velocityA
    call calc_density_velocity_fields(zmean_zre,density1,velocity1)

    ! First and only unnested call, at z = zmean_zre. calc_ksz_t21_fields makes
    ! the other 21, which differ only in redshift.
    call ckpt_scalar('calc_density_velocity_fields','density', &
         densityA,N_grid,N_grid,N_grid)
    call ckpt_comp_first('calc_density_velocity_fields','velocity_x', &
         velocityA,3,N_grid,N_grid,N_grid,1)
    call ckpt_comp_first('calc_density_velocity_fields','velocity_y', &
         velocityA,3,N_grid,N_grid,N_grid,2)
    call ckpt_comp_first('calc_density_velocity_fields','velocity_z', &
         velocityA,3,N_grid,N_grid,N_grid,3)

    ! Copy density field to zreion field
    !$omp parallel do     &
    !$omp default(shared) &
    !$omp private(i,j,k)
    do k=1,N_grid
       do j=1,N_grid
          do i=1,N_grid
             zreion(i,j,k) = density1(i,j,k) - 1
          enddo
       enddo
    enddo
    !$omp end parallel do

    ! Forward FFT of density field
    call fft_3d('f',N_grid,N_grid,N_grid,zreion)

    ! Calculate zreion field in Fourier space
    !$omp parallel do               &
    !$omp default(shared)           &
    !$omp private(i,j,k,kx,ky,kz,x) &
    !$omp private(kr,wcell,wsmooth)
    do k=1,N_grid
       if (k <= N_grid/2+1) then
          kz = Ak*(k-1)
       else
          kz = Ak*(k-1-N_grid)
       endif

       do j=1,N_grid
          if (j <= N_grid/2+1) then
             ky = Ak*(j-1)
          else
             ky = Ak*(j-1-N_grid)
          endif

          do i=1,N_grid+2,2
             kx = Ak*((i-1)/2)
             kr = sqrt(kx**2 + ky**2 + kz**2)*ndmr/box

             ! Deconvolve cell
             wcell = (sinc(kx/2)*sinc(ky/2)*sinc(kz/2))**2

             ! Smooth with top hat window
             x = kr*Rsmooth_zre
             wsmooth = tophat(x)

             ! Apply bias relation
             zreion(i:i+1,j,k) = zreion(i:i+1,j,k)*bias(kr)*wsmooth/wcell
          enddo
       enddo
    enddo
    !$omp end parallel do

    ! Inverse FFT of zreion field
    call fft_3d('b',N_grid,N_grid,N_grid,zreion)

    ! Calculate zreion field and statistics
    zavg = 0
    zstd = 0
    zmax = 0
    zmin = huge(zmin)

    !$omp parallel do            &
    !$omp default(shared)        &
    !$omp private(i,j,k,z)       &
    !$omp reduction(+:zavg,zstd) &
    !$omp reduction(max:zmax)    &
    !$omp reduction(min:zmin)
    do k=1,N_grid
       do j=1,N_grid
          do i=1,N_grid
             z = zmean_zre + (1+zmean_zre)*zreion(i,j,k)
             zreion(i,j,k) = z

             zavg = zavg + z
             zstd = zstd + z**2
             zmax = max(z,zmax)
             zmin = min(z,zmin)
          enddo
       enddo
    enddo
    !$omp end parallel do

    ! Write out zreion properties
    zavg = zavg/ncellr
    zstd = sqrt(zstd/ncellr - zavg**2)
    write(*,*) "zreion: ",real((/ zavg,zstd,zmax,zmin /))

    ! Compute full reionization history
    do iz=1,Nredshift
       zval  = zval_list(iz)
       xavg  = 0
       xmavg = 0
       !$omp parallel do             &
       !$omp default(shared)         &
       !$omp private(i,j,k)          &
       !$omp reduction(+:xavg,xmavg)
       do k=1,N_grid
          do j=1,N_grid
             do i=1,N_grid
                if (zreion(i,j,k) < zval) then
                   xavg  = xavg + 1
                   xmavg = xmavg + density1(i,j,k)
                endif
             enddo
          enddo
       enddo
       !$omp end parallel do

       xavg  = xavg/ncellr
       xmavg = xmavg / ncellr
       xval_list(iz)  = xavg
       xmval_list(iz) = xmavg
       write(*,"(a,3f7.3)") "z, x, xm: ", zval, xavg, xmavg
    enddo


    call ckpt_scalar('calc_zreion','zreion',zreion,N_grid,N_grid,N_grid)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called calc zreion'
    return


  contains


    pure function bias(kr)
      ! Default
      implicit none

      ! Function arguments
      real(8), intent(in) :: kr
      real(8)             :: bias

      bias = b0_zre/(1 + kr/kb_zre)**alpha_zre
      return
    end function bias


  end subroutine calc_zreion


end module zreion_tools
