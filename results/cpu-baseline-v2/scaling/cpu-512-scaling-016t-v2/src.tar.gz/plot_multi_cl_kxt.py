#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import datetime
import h5py
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from bin_cl import bin_cl

dark_background = True
if dark_background:
    plt.style.use("dark_background")
    transparent = True
    ax_color = "w"
else:
    transparent = False
    ax_color = "k"

# general analysis/plot options
log_width = 0.2
plot_ells = False  # True = xcorr(ell), False = xcorr(z)
plot_wedge = True

if plot_wedge:
    cl_fn = "cl_arrays_window_wedge.hdf5"
    binned_file = "binned_cl_kxt_wedge.hdf5"
else:
    cl_fn = "cl_arrays_window.hdf5"
    binned_file = "binned_cl_kxt.hdf5"

# read in Cl spectrum
root_dir = "/jet/home/plaplant/scratch_ml/ksz/fiducial"
output_dirs = sorted([d for d in os.listdir(root_dir) if "output_00" in d])

# matplotlib options
matplotlib.rc("text", usetex=True)
matplotlib.rc("font", family="serif")
matplotlib.rc("lines", linewidth=2)

# initialize figure
fig = plt.figure()
ax = plt.gca()
ax.axhline(y=0.0, color=ax_color, linestyle="--")

# get representative window values
cl_fn = os.path.join(root_dir, output_dirs[0], cl_fn)
with h5py.File(cl_fn, "r") as h5f:
    tcmb0 = h5f["header/Tcmb0"][()]
    window_zvals = h5f["data/window_zvals"][()]
tfac = tcmb0 * 1e6

# read in file if already computed
try:
    with h5py.File(binned_file, "r") as h5f:
        binned_ells = h5f["binned_ells"][()]
        binned_cl = h5f["binned_cl"][()]
        binned_cl2 = h5f["binned_cl2"][()]
except (IOError, OSError):
    navg = 0
    for idir, dirname in enumerate(output_dirs):
        cl_fn = os.path.join(root_dir, dirname, cl_fn)
        print(f"reading {cl_fn}...")
        with h5py.File(cl_fn, "r") as h5f:
            cl_kxt = h5f["data/cl_kxt"][()]

        cl_kxt[:, :, :, 1:3] *= tfac**2

        ells = cl_kxt[:, :, 1:, 0]
        cl = cl_kxt[:, :, 1:, 1]
        cl2 = cl_kxt[:, :, 1:, 1]**2

        if idir == 0:
            # bin up spectra
            binned_ells, temp_cl = bin_cl(
                ells[0, 0, :], cl[0, 0, :], log_bins=True, log_width=log_width
            )
            binned_cl = np.zeros(
                (cl.shape[0], cl.shape[1], temp_cl.shape[0]), dtype=np.float64
            )
            binned_cl2 = np.zeros(
                (cl.shape[0], cl.shape[1], temp_cl.shape[0]), dtype=np.float64
            )
            for i in range(cl.shape[0]):
                for j in range(cl.shape[1]):
                    binned_cl[i, j, :] = bin_cl(
                        ells[i, j, :], cl[i, j, :], log_bins=True, log_width=log_width
                    )[1]
                    binned_cl2[i, j, :] = bin_cl(
                        ells[i, j, :], cl2[i, j, :], log_bins=True, log_width=log_width
                    )[1]
        else:
            for i in range(cl.shape[0]):
                for j in range(cl.shape[1]):
                    binned_cl[i, j, :] += bin_cl(
                        ells[i, j, :], cl[i, j, :], log_bins=True, log_width=log_width
                    )[1]
                    binned_cl2[i, j, :] += bin_cl(
                        ells[i, j, :], cl2[i, j, :], log_bins=True, log_width=log_width
                    )[1]

        navg += 1

    # finish computing statistics once we're done
    binned_cl /= navg
    binned_cl2 = np.sqrt(binned_cl2 / (navg - 1) - binned_cl**2) / np.sqrt(navg)

    # save it for later
    with h5py.File(binned_file, "w") as h5f:
        dset = h5f.create_dataset("binned_ells", data=binned_ells)
        dset = h5f.create_dataset("binned_cl", data=binned_cl)
        dset = h5f.create_dataset("binned_cl2", data=binned_cl2)

if plot_ells:
    for i in range(0, window_zvals.shape[1], 2):
        idx0 = 11
        idx1 = i
        z1 = window_zvals[idx0, idx1, 0]
        z2 = window_zvals[idx0, idx1, 1]
        if i == 0:
            zmean = (z1 + z2) / 2.0
        label = rf"${z1:0.2f} \leq z \leq {z2:0.2f}$"
        dl = binned_ells * (binned_ells + 1) * binned_cl[idx0, idx1, :] / (2 * np.pi)
        dl2 = binned_ells * (binned_ells + 1) * binned_cl2[idx0, idx1, :] / (2 * np.pi)
        fuzzed_ells = binned_ells * (1 + (i - 2) / 100)
        ax.errorbar(fuzzed_ells[3:], dl[3:], yerr=dl2[3:], label=label, alpha=0.5)

    pk_fn = os.path.join(root_dir, output_dirs[0], "pk_arrays.hdf5")
    with h5py.File(pk_fn, "r") as h5f:
        zval_list = h5f["data/zval_list"][()]
        xval_list = h5f["data/xval_list"][()]

    xe = 1 - np.interp(zmean, zval_list, xval_list)

    # make plot pretty
    ax.set_xscale("log")
    ax.set_xlabel(r"$\ell$")
    ax.set_ylabel(r"$\ell(\ell+1)C_\ell /2\pi$ [mK $\mu$K$^2$]")
    ax.set_title(rf"kSZ$^2$--21cm cross-correlation, $x_e = {xe:0.2f}$")
    leg = ax.legend(loc=0)

    plot_dir = datetime.date.today().strftime("%y%m%d")
    plot_dir = os.path.join(root_dir, "plots", plot_dir)
    if not os.path.isdir(plot_dir):
        os.makedirs(plot_dir)
    if plot_wedge:
        out_fn = os.path.join(plot_dir, "cl_kxt_wedge.pdf")
    else:
        out_fn = os.path.join(plot_dir, "cl_kxt.pdf")
    print(f"saving {out_fn}...")
    fig.savefig(out_fn, bbox_inches="tight", transparent=transparent)
    plt.close(fig)
else:
    ells = [500, 1000, 3000, 10000]

    for iell, ell in enumerate(ells):
        zvals = np.zeros((window_zvals.shape[0],), dtype=np.float64)
        dl_vals = np.zeros_like(zvals)
        dl2_vals = np.zeros_like(zvals)
        for i in range(window_zvals.shape[0]):
            idx0 = i
            idx1 = 6  # Delta z = 1
            z1 = window_zvals[idx0, idx1, 0]
            z2 = window_zvals[idx0, idx1, 1]
            zvals[i] = (z1 + z2) / 2.0
            dl = (binned_ells * (binned_ells + 1) * binned_cl[idx0, idx1, :]
                  / (2 * np.pi)
            )
            dl2 = (binned_ells * (binned_ells + 1) * binned_cl2[idx0, idx1, :]
                   / (2 * np.pi)
            )
            dl_vals[i] = np.interp(ell, binned_ells, dl)
            dl2_vals[i] = np.interp(ell, binned_ells, dl2)

        # plot result
        label = rf"$\ell={ell}$"
        fuzzed_zvals = zvals + (iell - 1.5) * 0.05
        ax.errorbar(fuzzed_zvals, dl_vals, yerr=dl2_vals, label=label, alpha=0.5)

    # make plot pretty
    ax.set_xlabel(r"$z$")
    ax.set_ylabel(r"$\ell(\ell+1)C_\ell /2\pi$ [mK $\mu$K$^2$]")
    leg = ax.legend(loc=0)
    ax.set_title(r"kSZ$^2$--21cm cross correlation")

    # add secondary axis on top
    pk_fn = os.path.join(root_dir, output_dirs[0], "pk_arrays.hdf5")
    with h5py.File(pk_fn, "r") as h5f:
        zval_list = h5f["data/zval_list"][()]
        xval_list = h5f["data/xval_list"][()]
    def forward(x):
        return 1 - np.interp(x, zval_list, xval_list)
    ax2 = ax.twiny()
    tick_locations = [6, 7, 8, 9, 10, 11]
    ax2.set_xlim(ax.get_xlim())
    ax2.set_xticks(tick_locations)
    ax2.set_xticklabels([f"{x:0.2f}" for x in forward(tick_locations)])
    ax2.set_xlabel("$x_e$")

    plot_dir = datetime.date.today().strftime("%y%m%d")
    plot_dir = os.path.join(root_dir, "plots", plot_dir)
    if not os.path.isdir(plot_dir):
        os.makedirs(plot_dir)
    if plot_wedge:
        out_fn = os.path.join(plot_dir, "cl_kxt_of_z_wedge.pdf")
    else:
        out_fn = os.path.join(plot_dir, "cl_kxt_of_z.pdf")
    print(f"saving {out_fn}...")
    fig.savefig(out_fn, bbox_inches="tight", transparent=transparent)
    plt.close(fig)
