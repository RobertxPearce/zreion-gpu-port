# -*- coding: utf-8 -*-

import h5py
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import gridspec

output_vals = np.genfromtxt("output_values_cmb.txt")
ells_int = output_vals[:, 0]
cl_int = output_vals[:, 1]

# read comparison data
ref_vals = np.genfromtxt("cmb_squared.txt")

ells_ref = ref_vals[:, 0]
cl_ref = ref_vals[:, 1]

# plot comparison
matplotlib.rc("text", usetex=True)
matplotlib.rc("font", family="serif")

gs = gridspec.GridSpec(2, 1, height_ratios=[2, 1], hspace=0.0)
fig = plt.figure()
ax1 = plt.subplot(gs[0])
ax2 = plt.subplot(gs[1], sharex=ax1)
ax2.axhline(y=0.0, color="k", linestyle="--")

dl_int = ells_int * (ells_int + 1) * cl_int / (2 * np.pi)
dl_ref = ells_ref * (ells_ref + 1) * cl_ref / (2 * np.pi)

ax1.loglog(ells_int, dl_int, label="Convolution integral", color="C0", alpha=0.5)
ax1.loglog(ells_ref, dl_ref, label="from maps", color="C1", alpha=0.5)
comp_vals = np.interp(ells_ref, ells_int, dl_int)
pct_diff = dl_ref / comp_vals - 1
ax2.semilogx(ells_ref, pct_diff, color="C1", alpha=0.5)

ax2.set_xlabel(r"$\ell$")
ax1.set_ylabel(r"$\ell(\ell+1)C_\ell/2\pi$ [$\mu$K$^2$]")
ax1.legend(loc=0)
ax1.set_ylim((1e4, 1e8))

output = "cl_convolve_comparison_cmb.pdf"
print(f"saving {output}...")
fig.savefig(output, bbox_inches="tight")
plt.close(fig)
