# -*- coding: utf-8 -*-

import sys
import os
import datetime
import h5py
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

extended_dir = "/ocean/projects/ast180004p/jsipple/ksz/extended_output"
early_dir = "/ocean/projects/ast180004p/jsipple/ksz/early_output"
short_dir = "/jet/home/plaplant/scratch_ml/ksz/fiducial/bt_bias"

hist = "ext"
if hist == "ext":
    root_dir = extended_dir
elif hist == "early":
    root_dir = early_dir
elif hist == "short":
    root_dir = short_dir
else:
    print("invalid history choice")
    sys.exit(1)

output_dirs = sorted([d for d in os.listdir(root_dir) if "output_00" in d])
input_fn = "cl_arrays_window_s4_ilc.hdf5"
output_fn = f"data/cl_ksz_{hist}.hdf5"

use_ksz2 = False
if "window" in input_fn:
    dim4 = True
else:
    dim4 = False

try:
    with h5py.File(output_fn, "r") as h5f:
        total_array = h5f["cl_ksz"][()]
        if use_ksz2:
            total_array2 = h5f["cl_ks2"][()]

    ells = total_array[:, 0]
    cl = total_array[:, 1]
    cl2 = total_array[:, 2]

    if use_ksz2:
        cls = total_array2[:, 1]
        cls2 = total_array2[:, 2]

    have_data = True

except (OSError, KeyError):
    have_data = False

if not have_data:
    # loop through spectra
    navg = 0
    for idir, dirname in enumerate(output_dirs):
        cl_fn = os.path.join(root_dir, dirname, input_fn)
        print(f"reading {cl_fn}...")
        with h5py.File(cl_fn, "r") as h5f:
            tcmb0 = h5f["header/Tcmb0"][()]
            cl_ksz = h5f["data/cl_ksz"][()]
            if use_ksz2:
                cl_ks2 = h5f["data/cl_ks2"][()]

        tfac = tcmb0 * 1e6

        if idir == 0:
            if dim4:
                # only extract one spectrum--they should all be the same!
                ells = cl_ksz[0, 0, :, 0]
                cl = cl_ksz[0, 0, :, 1] * tfac**2
                cl2 = (cl_ksz[0, 0, :, 1] * tfac**2)**2
            else:
                ells = cl_ksz[:, 0]
                cl = cl_ksz[:, 1] * tfac**2
                cl2 = (cl_ksz[:, 1] * tfac**2)**2

            if use_ksz2:
                if dim4:
                    cls = cl_ks2[0, 0, :, 1] * tfac**4
                    cls2 = (cl_ks2[0, 0, :, 1] * tfac**4)**2
                else:
                    cls = cl_ksz2[:, 1] * tfac**4
                    cls2 = (cl_ksz2[:, 1] * tfac**4)**2
        else:
            if dim4:
                cl += cl_ksz[0, 0, :, 1] * tfac**2
                cl2 += (cl_ksz[0, 0, :, 1] * tfac**2)**2
            else:
                cl += cl_ksz[:, 1] * tfac**2
                cl2 += (cl_ksz[:, 1] * tfac**2)**2

            if use_ksz2:
                if dim4:
                    cls += cl_ks2[0, 0, :, 1] * tfac**4
                    cls2 += (cl_ks2[0, 0, :, 1] * tfac**4)**2
                else:
                    cls += cl_ks2[:, 1] * tfac**4
                    cls2 += (cl_ks2[:, 1] * tfac**4)**2

        navg += 1

    # finish computing ensemble average
    cl /= navg
    cl2 = np.sqrt(cl2 / (navg - 1) - cl**2) / np.sqrt(navg)

    if use_ksz2:
        cls /= navg
        cls2 = np.sqrt(cls2 / (navg - 1) - cls**2) / np.sqrt(navg)

    total_array = np.zeros((len(cl), 3), dtype=np.float64)
    total_array[:, 0] = ells
    total_array[:, 1] = cl
    total_array[:, 2] = cl2

    if use_ksz2:
        total_array2 = np.zeros((len(cls), 3), dtype=np.float64)
        total_array2[:, 0] = ells
        total_array2[:, 1] = cls
        total_array2[:, 2] = cls2

    print(f"writing {output_fn}...")
    with h5py.File(output_fn, "w") as h5f:
        dset = h5f.create_dataset("Tcmb0", data=tcmb0)
        dset = h5f.create_dataset("cl_ksz", data=total_array)
        if use_ksz2:
            dset = h5f.create_dataset("cl_ks2", data=total_array2)

if False:
    matplotlib.rc("text", usetex=True)
    matplotlib.rc("font", family="serif")
    matplotlib.rc("lines", linewidth=1)

    fig = plt.figure()
    ax = plt.gca()
    dl = ells * (ells + 1) * cl / (2 * np.pi)
    dl2 = ells * (ells + 1) * cl2 / (2 * np.pi)
    ax.errorbar(ells, dl, yerr=dl2, label=r"kSZ [$\mu$K$^2$]")

    if use_ksz2:
        dls = ells * (ells + 1) * cls / (2 * np.pi)
        dls2 = ells * (ells + 1) * cls2 / (2 * np.pi)
        ax.errorbar(ells, dls, yerr=dls2, label=r"kSZ$^2$ [$\mu$K$^4$]")

    ax.set_xlabel(r"$z$")
    ax.set_ylabel(r"$\ell(\ell+1)C_\ell/2\pi$")
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.legend(loc=0)

    plot_dir = datetime.date.today().strftime("%y%m%d")
    plot_dir = os.path.join(root_dir, "plots", plot_dir)
    if not os.path.isdir(plot_dir):
        os.makedirs(plot_dir)
    output = os.path.join(plot_dir, "cl_ksz.pdf")
    print(f"saving {output}...")
    fig.savefig(output, bbox_inches="tight")
    plt.close(fig)
