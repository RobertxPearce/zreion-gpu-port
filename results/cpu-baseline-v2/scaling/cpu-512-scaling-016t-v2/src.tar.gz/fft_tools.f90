! MKL
include 'mkl_dfti.f90'


module fft_tools
  ! Intel
  use IFPORT
  use MKL_DFTI
  use OMP_LIB
  use, intrinsic :: iso_c_binding


  ! Default
  implicit none


  ! Interfaces for different precisions
  interface fft_2d
     module procedure fft_2d_s, fft_2d_d
  end interface fft_2d

  interface fft_3d
     module procedure fft_3d_s, fft_3d_d
  end interface fft_3d


contains


  subroutine init_fft
    ! Default
    implicit none


    ! Timing variables
    real(8)      :: tr1,tr2
    character(8) :: ts1,ts2
    call time(ts1)
    tr1 = omp_get_wtime()


    call time(ts2)
    tr2 = omp_get_wtime()
    write(*,"(f8.2,2a10,a)") tr2-tr1,ts1,ts2,'  Called init fft'
    return
  end subroutine init_fft


!------------------------------------------------------------------------------!


  subroutine fft_3d_s(c,n1,n2,n3,a)
    ! Default
    implicit none


    ! Subroutine arguments
    character  :: c
    integer(4) :: n1,n2,n3
    real(4), dimension(n1+2,n2,n3), target :: a


    ! Local variables
    integer(4)  :: status
    integer(8)  :: Nfft
    real(8)     :: bscale
    type(C_PTR) :: fft_ptr
    integer, dimension(3) :: Lfft
    integer, dimension(4) :: strides_in,strides_out
    type(DFTI_DESCRIPTOR), pointer :: desc
    real(4), pointer, dimension(:) :: a_fft


    ! Timing variables
    real(8)      :: tr1,tr2
    character(8) :: ts1,ts2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Create pointer
    Nfft    = int(n1+2,kind=8)*int(n2,kind=8)*int(n3,kind=8)
    fft_ptr = c_loc(a)
    call c_f_pointer(fft_ptr,a_fft,[Nfft])


    ! Choose direction
    select case (c)
    case ('f')
       ! Initialize
       Lfft        = (/n1,n2,n3/)
       strides_in  = (/0,1,n1+2,(n1+2)*n2/)
       strides_out = (/0,1,n1/2+1,(n1/2+1)*n2/)

       ! Initialize descriptor
       status = DftiCreateDescriptor(desc,DFTI_DOUBLE,DFTI_REAL,3,Lfft)
       status = DftiSetValue(desc,DFTI_CONJUGATE_EVEN_STORAGE,DFTI_COMPLEX_COMPLEX)
       status = DftiSetValue(desc,DFTI_INPUT_STRIDES ,strides_in)
       status = DftiSetValue(desc,DFTI_OUTPUT_STRIDES,strides_out)
       status = DftiCommitDescriptor(desc)

       ! Compute transform
       status = DftiComputeForward(desc,a_fft)
       !write(*,*) DftiErrorMessage(status)

       ! Free descriptor
       status = DftiFreeDescriptor(desc)
    case ('b')
       ! Initialize
       Lfft        = (/n1,n2,n3/)
       strides_in  = (/0,1,n1/2+1,(n1/2+1)*n2/)
       strides_out = (/0,1,n1+2,(n1+2)*n2/)
       bscale      = 1D0/(int(n1,kind=8)*int(n2,kind=8)*int(n3,kind=8))

       ! Initialize descriptor
       status = DftiCreateDescriptor(desc,DFTI_DOUBLE,DFTI_REAL,3,Lfft)
       status = DftiSetValue(desc,DFTI_CONJUGATE_EVEN_STORAGE,DFTI_COMPLEX_COMPLEX)
       status = DftiSetValue(desc,DFTI_INPUT_STRIDES ,strides_in)
       status = DftiSetValue(desc,DFTI_OUTPUT_STRIDES,strides_out)
       status = DftiSetValue(desc,DFTI_BACKWARD_SCALE,bscale)
       status = DftiCommitDescriptor(desc)

       ! Compute transform
       status = DftiComputeBackward(desc,a_fft)
       !write(*,*) DftiErrorMessage(status)

       ! Free descriptor
       status = DftiFreeDescriptor(desc)
    end select


    call time(ts2)
    tr2 = omp_get_wtime()
    !write(*,"(f8.2,2a10,a)") tr2-tr1,ts1,ts2,'  Called fft 3d'
    return
  end subroutine fft_3d_s


!------------------------------------------------------------------------------!


  subroutine fft_3d_d(c,n1,n2,n3,a)
    ! Default
    implicit none


    ! Subroutine arguments
    character  :: c
    integer(4) :: n1,n2,n3
    real(8), dimension(n1+2,n2,n3), target :: a


    ! Local variables
    integer(4)  :: status
    integer(8)  :: Nfft
    real(8)     :: bscale
    type(C_PTR) :: fft_ptr
    integer, dimension(3) :: Lfft
    integer, dimension(4) :: strides_in,strides_out
    type(DFTI_DESCRIPTOR), pointer :: desc
    real(8), pointer, dimension(:) :: a_fft


    ! Timing variables
    real(8)      :: tr1,tr2
    character(8) :: ts1,ts2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Create pointer
    Nfft    = int(n1+2,kind=8)*int(n2,kind=8)*int(n3,kind=8)
    fft_ptr = c_loc(a)
    call c_f_pointer(fft_ptr,a_fft,[Nfft])


    ! Choose direction
    select case (c)
    case ('f')
       ! Initialize
       Lfft        = (/n1,n2,n3/)
       strides_in  = (/0,1,n1+2,(n1+2)*n2/)
       strides_out = (/0,1,n1/2+1,(n1/2+1)*n2/)

       ! Initialize descriptor
       status = DftiCreateDescriptor(desc,DFTI_DOUBLE,DFTI_REAL,3,Lfft)
       status = DftiSetValue(desc,DFTI_CONJUGATE_EVEN_STORAGE,DFTI_COMPLEX_COMPLEX)
       status = DftiSetValue(desc,DFTI_INPUT_STRIDES ,strides_in)
       status = DftiSetValue(desc,DFTI_OUTPUT_STRIDES,strides_out)
       status = DftiCommitDescriptor(desc)

       ! Compute transform
       status = DftiComputeForward(desc,a_fft)
       !write(*,*) DftiErrorMessage(status)

       ! Free descriptor
       status = DftiFreeDescriptor(desc)
    case ('b')
       ! Initialize
       Lfft        = (/n1,n2,n3/)
       strides_in  = (/0,1,n1/2+1,(n1/2+1)*n2/)
       strides_out = (/0,1,n1+2,(n1+2)*n2/)
       bscale      = 1D0/(int(n1,kind=8)*int(n2,kind=8)*int(n3,kind=8))

       ! Initialize descriptor
       status = DftiCreateDescriptor(desc,DFTI_DOUBLE,DFTI_REAL,3,Lfft)
       status = DftiSetValue(desc,DFTI_CONJUGATE_EVEN_STORAGE,DFTI_COMPLEX_COMPLEX)
       status = DftiSetValue(desc,DFTI_INPUT_STRIDES ,strides_in)
       status = DftiSetValue(desc,DFTI_OUTPUT_STRIDES,strides_out)
       status = DftiSetValue(desc,DFTI_BACKWARD_SCALE,bscale)
       status = DftiCommitDescriptor(desc)

       ! Compute transform
       status = DftiComputeBackward(desc,a_fft)
       !write(*,*) DftiErrorMessage(status)

       ! Free descriptor
       status = DftiFreeDescriptor(desc)
    end select


    call time(ts2)
    tr2 = omp_get_wtime()
    !write(*,"(f8.2,2a10,a)") tr2-tr1,ts1,ts2,'  Called fft 3d'
    return
  end subroutine fft_3d_d


!------------------------------------------------------------------------------!


  subroutine fft_2d_s(c,n1,n2,a)
    ! Default
    implicit none


    ! Subroutine arguments
    character(1) :: c
    integer(4)   :: n1,n2
    real(4), dimension(n1+2,n2), target :: a


    ! Local variables
    integer(4)  :: status
    integer(8)  :: Nfft
    real(8)     :: bscale
    type(C_PTR) :: fft_ptr
    integer, dimension(2) :: Lfft
    integer, dimension(3) :: strides_in,strides_out
    type(DFTI_DESCRIPTOR), pointer :: desc
    real(4), pointer, dimension(:) :: a_fft


    ! Timing variables
    real(8)      :: tr1,tr2
    character(8) :: ts1,ts2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Create pointer
    Nfft = int(n1+2,kind=8)*int(n2,kind=8)
    fft_ptr = c_loc(a)
    call c_f_pointer(fft_ptr,a_fft,[Nfft])


    ! Choose direction
    select case (c)
    case ('f')
       ! Initialize
       Lfft        = (/n1,n2/)
       strides_in  = (/0,1,n1+2/)
       strides_out = (/0,1,n1/2+1/)

       ! Initialize descriptor
       status = DftiCreateDescriptor(desc,DFTI_SINGLE,DFTI_REAL,2,Lfft)
       status = DftiSetValue(desc,DFTI_CONJUGATE_EVEN_STORAGE,&
            DFTI_COMPLEX_COMPLEX)
       status = DftiSetValue(desc,DFTI_INPUT_STRIDES ,strides_in)
       status = DftiSetValue(desc,DFTI_OUTPUT_STRIDES,strides_out)
       status = DftiCommitDescriptor(desc)

       ! Compute transform
       status = DftiComputeForward(desc,a_fft)

       ! Free descriptor
       status = DftiFreeDescriptor(desc)
    case ('b')
       ! Initialize
       Lfft        = (/n1,n2/)
       strides_in  = (/0,1,n1/2+1/)
       strides_out = (/0,1,n1+2/)
       bscale = 1D0/(int(n1,kind=8)*int(n2,kind=8))

       ! Initialize descriptor
       status = DftiCreateDescriptor(desc,DFTI_SINGLE,DFTI_REAL,2,Lfft)
       status = DftiSetValue(desc,DFTI_CONJUGATE_EVEN_STORAGE,&
            DFTI_COMPLEX_COMPLEX)
       status = DftiSetValue(desc,DFTI_INPUT_STRIDES ,strides_in)
       status = DftiSetValue(desc,DFTI_OUTPUT_STRIDES,strides_out)
       status = DftiSetValue(desc,DFTI_BACKWARD_SCALE,bscale)
       status = DftiCommitDescriptor(desc)

       ! Compute transform
       status = DftiComputeBackward(desc,a_fft)

       ! Free descriptor
       status = DftiFreeDescriptor(desc)
    end select


    call time(ts2)
    tr2 = omp_get_wtime()
    ! write(*,"(f8.2,2a10,a)") tr2-tr1,ts1,ts2,'  Called fft 2d'
    return
  end subroutine fft_2d_s


  subroutine fft_2d_d(c,n1,n2,a)
    ! Default
    implicit none


    ! Subroutine arguments
    character(1) :: c
    integer(4)   :: n1,n2
    real(8), dimension(n1+2,n2), target :: a


    ! Local variables
    integer(4)  :: status
    integer(8)  :: Nfft
    real(8)     :: bscale
    type(C_PTR) :: fft_ptr
    integer, dimension(2) :: Lfft
    integer, dimension(3) :: strides_in,strides_out
    type(DFTI_DESCRIPTOR), pointer :: desc
    real(8), pointer, dimension(:) :: a_fft


    ! Timing variables
    real(8)      :: tr1,tr2
    character(8) :: ts1,ts2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Create pointer
    Nfft = int(n1+2,kind=8)*int(n2,kind=8)
    fft_ptr = c_loc(a)
    call c_f_pointer(fft_ptr,a_fft,[Nfft])


    ! Choose direction
    select case (c)
    case ('f')
       ! Initialize
       Lfft        = (/n1,n2/)
       strides_in  = (/0,1,n1+2/)
       strides_out = (/0,1,n1/2+1/)

       ! Initialize descriptor
       status = DftiCreateDescriptor(desc,DFTI_DOUBLE,DFTI_REAL,2,Lfft)
       status = DftiSetValue(desc,DFTI_CONJUGATE_EVEN_STORAGE,&
            DFTI_COMPLEX_COMPLEX)
       status = DftiSetValue(desc,DFTI_INPUT_STRIDES ,strides_in)
       status = DftiSetValue(desc,DFTI_OUTPUT_STRIDES,strides_out)
       status = DftiCommitDescriptor(desc)

       ! Compute transform
       status = DftiComputeForward(desc,a_fft)

       ! Free descriptor
       status = DftiFreeDescriptor(desc)
    case ('b')
       ! Initialize
       Lfft        = (/n1,n2/)
       strides_in  = (/0,1,n1/2+1/)
       strides_out = (/0,1,n1+2/)
       bscale = 1D0/(int(n1,kind=8)*int(n2,kind=8))

       ! Initialize descriptor
       status = DftiCreateDescriptor(desc,DFTI_DOUBLE,DFTI_REAL,2,Lfft)
       status = DftiSetValue(desc,DFTI_CONJUGATE_EVEN_STORAGE,&
            DFTI_COMPLEX_COMPLEX)
       status = DftiSetValue(desc,DFTI_INPUT_STRIDES ,strides_in)
       status = DftiSetValue(desc,DFTI_OUTPUT_STRIDES,strides_out)
       status = DftiSetValue(desc,DFTI_BACKWARD_SCALE,bscale)
       status = DftiCommitDescriptor(desc)

       ! Compute transform
       status = DftiComputeBackward(desc,a_fft)

       ! Free descriptor
       status = DftiFreeDescriptor(desc)
    end select


    call time(ts2)
    tr2 = omp_get_wtime()
    ! write(*,"(f8.2,2a10,a)") tr2-tr1,ts1,ts2,'  Called fft 2d'
    return
  end subroutine fft_2d_d


end module fft_tools
