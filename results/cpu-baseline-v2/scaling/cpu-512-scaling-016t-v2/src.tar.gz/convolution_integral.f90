program main
  ! Intel
  use IFPORT
  use OMP_LIB


  ! HDF5
  use ISO_C_BINDING
  use HDF5


  ! Tools
  use general_tools, only: interpolate


  ! Default
  implicit none


  !! Parameters
  ! Computation and constants
  integer(4),   parameter :: N_cpu      = 4
  real(8),      parameter :: pi         = acos(-1D0)
  real(8),      parameter :: amin2rad   = pi/180D0/60D0
  real(8),      parameter :: asec2rad   = pi/180D0/60D0/60D0

  ! I/O
  character(*), parameter :: hist       = "short"  ! "short", "ext", "early"
  character(*), parameter :: expt       = "so"     ! "so", "s4", "hd"
  character(*), parameter :: noise      = ""       ! "_ilc", "" (naive noise)

  character(*), parameter :: cl_ksz_fn  = "data/cl_ksz_"//hist//".hdf5"
  character(*), parameter :: cl_cmb_fn  = "../cmb_map/camb_output.hdf5"
  character(*), parameter :: cl_tt_fn   = &
       "data/cl_tt_"//hist//"_"//expt//noise//".hdf5"
  character(*), parameter :: f_ell_fn_short = &
       "../cmb_map/f_ell_"//expt//noise//".hdf5"
  character(*), parameter :: f_ell_fn_early = &
       "/ocean/projects/ast180004p/jsipple/ksz/early_output/f_ell_"&
       //expt//noise//".hdf5"
  character(*), parameter :: f_ell_fn_ext   = &
       "/ocean/projects/ast180004p/jsipple/ksz/extended_output/f_ell_"&
       //expt//noise//".hdf5"
  character(*), parameter :: output_fn  = &
       "data/cl_t2t2_"//hist//"_"//expt//noise//".txt"
  logical,      parameter :: read_tt    = .false.

  ! Integral parameters
  real(8),      parameter :: ell_min    = 0
  real(8),      parameter :: ell_max    = 10000
  real(8),      parameter :: d_ell      = 50
  integer(4),   parameter :: N_ell      = 1 + (ell_max-ell_min)/d_ell

  ! Filter options
  logical,      parameter :: use_fell   = .true.
  real(8),      parameter :: lfilt_min  = 1d2
  real(8),      parameter :: lfilt_max  = 1d3

  ! Experiment parameters
  character(*), parameter :: noise_fn      = "data/orphics_"//expt//".txt"
  real(8),      parameter :: rescale_fac   = 1D0  ! divide noise by this factor
  real(8),      parameter :: delta_t_so    = 10  * amin2rad  ! uK-arcmin->uK-rad
  real(8),      parameter :: delta_t_s4    = 2   * amin2rad  ! uK-arcmin->uK-rad
  real(8),      parameter :: delta_t_hd    = 0.6 * amin2rad  ! uK-arcmin->uK-rad
  real(8),      parameter :: theta_fwhm_so = 1.4D0 * amin2rad  ! arcmin->rad
  real(8),      parameter :: theta_fwhm_s4 = 1.4D0 * amin2rad  ! arcmin->rad
  real(8),      parameter :: theta_fwhm_hd = 10D0  * asec2rad  ! arcsec->rad


  !! Variables
  integer(4)      :: lmax_int
  character(1000) :: f_ell_fn
  logical         :: read_noise


  !! Arrays
  real(8), dimension(:,:), allocatable :: cl_ksz,cl_cmb,cl_tt,output_array,f_ell
  real(8), dimension(:,:), allocatable :: nl_array


  ! Initialize
  call OMP_SET_NUM_THREADS(N_cpu)
  lmax_int = 0
  select case(hist)
  case("ext")
     ! Extended = Fiducial
     f_ell_fn = f_ell_fn_ext
  case("early")
     f_ell_fn = f_ell_fn_early
  case("short")
     f_ell_fn = f_ell_fn_short
  case default
     write(*,*) "bad choise for hist; stopping"
     stop
  end select

  if (noise == "_ilc") then
     read_noise = .true.
  else
     read_noise = .false.
  endif

  ! Read in spectra
  if (use_fell) then
     call read_f_ell
  endif
  if (read_noise) then
     call read_noise_file
  endif
  if (read_tt) then
     call read_cl_tt
  else
     call read_cl_ksz
     call read_cl_cmb
     call compute_cl_tt
     call write_cl_tt
  endif

  if (.false.) then
     ! Test
     call probe_integrands
  endif

  ! Compute integral
  call compute_integral

  ! Save out
  call save_output


contains


  subroutine read_f_ell
    ! Default
    implicit none


    ! Local variables
    character(1000)  :: fn
    integer(4)       :: error
    integer(HID_T)   :: file_id,dset_id,dspace_id
    integer(HSIZE_T) :: dims(2),maxdims(2)


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Read in file
    fn = trim(f_ell_fn)
    write(*,*) "Reading ",trim(fn)
    call h5open_f(error)
    call h5fopen_f(fn, H5F_ACC_RDONLY_F, file_id, error)
    call h5dopen_f(file_id, "f_ell", dset_id, error)
    call h5dget_space_f(dset_id, dspace_id, error)
    call h5sget_simple_extent_dims_f(dspace_id, dims, maxdims, error)
    allocate(f_ell(dims(1),dims(2)))
    call h5dread_f(dset_id, H5T_NATIVE_DOUBLE, f_ell, dims, error)
    call h5sclose_f(dspace_id, error)
    call h5dclose_f(dset_id, error)
    call h5fclose_f(file_id, error)
    call h5close_f(error)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called read f_ell'
    return
  end subroutine read_f_ell


!------------------------------------------------------------------------------!


  subroutine read_cl_tt
    ! Default
    implicit none


    ! Local variables
    character(1000)  :: fn
    integer(4)       :: i,error,nvals
    integer(HID_T)   :: file_id,dset_id,dspace_id
    integer(HSIZE_T) :: dims(1),maxdims(1)
    real(8), dimension(:), allocatable :: io_vals


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Read in file
    fn = cl_tt_fn
    call h5open_f(error)
    call h5fopen_f(fn, H5F_ACC_RDONLY_F, file_id, error)
    call h5dopen_f(file_id, "cl_tt", dset_id, error)
    call h5dget_space_f(dset_id, dspace_id, error)
    call h5sget_simple_extent_dims_f(dspace_id, dims, maxdims, error)
    nvals = dims(1)
    allocate(cl_tt(2,nvals))
    allocate(io_vals(nvals))
    call h5dread_f(dset_id, H5T_NATIVE_DOUBLE, io_vals, dims, error)
    call h5sclose_f(dspace_id, error)
    call h5dclose_f(dset_id, error)
    call h5fclose_f(file_id, error)
    call h5close_f(error)

    do i=1,nvals
       cl_tt(1,i) = i - 1
       cl_tt(2,i) = io_vals(i)
    enddo

    lmax_int = max(lmax_int,int(cl_tt(1,nvals)))


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called read cl tt'
    return
  end subroutine read_cl_tt


!------------------------------------------------------------------------------!


  subroutine read_cl_ksz
    ! Default
    implicit none


    ! Local variables
    character(1000)  :: fn
    integer(4)       :: error,nvals
    integer(HID_T)   :: file_id,dset_id,dspace_id
    integer(HSIZE_T) :: dims(2),maxdims(2)
    real(8), dimension(:,:), allocatable :: io_vals


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Read in file
    fn = cl_ksz_fn
    call h5open_f(error)
    call h5fopen_f(fn, H5F_ACC_RDONLY_F, file_id, error)
    call h5dopen_f(file_id, "cl_ksz", dset_id, error)
    call h5dget_space_f(dset_id, dspace_id, error)
    call h5sget_simple_extent_dims_f(dspace_id, dims, maxdims, error)
    nvals = dims(2)
    allocate(cl_ksz(2,nvals))
    allocate(io_vals(3,nvals))
    call h5dread_f(dset_id, H5T_NATIVE_DOUBLE, io_vals, dims, error)
    call h5sclose_f(dspace_id, error)
    call h5dclose_f(dset_id, error)
    call h5fclose_f(file_id, error)
    call h5close_f(error)

    cl_ksz(:,:) = io_vals(1:2,:)

    lmax_int = max(lmax_int,int(cl_ksz(1,nvals)))


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called read cl ksz'
    return
  end subroutine read_cl_ksz


!------------------------------------------------------------------------------!


  subroutine read_cl_cmb
    ! Default
    implicit none


    ! Local variables
    character(1000)  :: fn
    integer(4)       :: i,error,nvals
    real(8)          :: ell
    integer(HID_T)   :: file_id,dset_id,dspace_id
    integer(HSIZE_T) :: dims(2),maxdims(2)
    real(8), dimension(:,:), allocatable :: io_vals


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Read in file
    fn = cl_cmb_fn
    call h5open_f(error)
    call h5fopen_f(fn, H5F_ACC_RDONLY_F, file_id, error)
    call h5dopen_f(file_id, "data/lensed_scalar", dset_id, error)
    call h5dget_space_f(dset_id, dspace_id, error)
    call h5sget_simple_extent_dims_f(dspace_id, dims, maxdims, error)
    nvals = dims(2)
    allocate(cl_cmb(2,nvals))
    allocate(io_vals(4,nvals))
    call h5dread_f(dset_id, H5T_NATIVE_DOUBLE, io_vals, dims, error)
    call h5sclose_f(dspace_id, error)
    call h5dclose_f(dset_id, error)
    call h5fclose_f(file_id, error)
    call h5close_f(error)

    do i=1,nvals
       ell = i - 1
       cl_cmb(1,i) = ell
       if (ell > 0) then
          cl_cmb(2,i) = io_vals(1,i) * 2*pi / ell / (ell + 1)
       else
          cl_cmb(2,i) = io_vals(1,i)
       endif
    enddo

    lmax_int = max(lmax_int,int(cl_cmb(1,nvals)))


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called read cl cmb'
    return
  end subroutine read_cl_cmb


!------------------------------------------------------------------------------!


  subroutine read_noise_file
    ! Default
    implicit none


    ! Local variables
    integer(4) :: un,i,nrows
    real(8)    :: ell,nl


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Read in data
    un = 11
    write(*,*) "Reading ",trim(noise_fn)
    open(un,file=noise_fn)
    nrows = 0
    do
       read(un,*,end=1) ell,nl
       nrows = nrows + 1
    enddo
1   continue

    ! Allocate array
    allocate(nl_array(2,nrows))
    nl_array = 0

    ! Read in data for real now
    rewind(un)
    do i=1,nrows
       read(un,*) ell,nl
       nl_array(1,i) = ell
       nl_array(2,i) = nl/rescale_fac
    enddo
    close(un)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called read noise file'
    return
  end subroutine read_noise_file


!------------------------------------------------------------------------------!


  pure function lowz_cl(ell)
    ! Compute the post-reionization kSZ signal from Park et al. 2018 (ApJ 853 2)
    ! Returns C_ell in (rad-uK)^2

    ! Default
    implicit none

    ! Local parameters
    real(8), parameter :: dl_3k = 1.38D0  ! uK^2 amptlitude at ell=3000
    real(8), parameter :: gamma = 0.21D0  ! power-law index

    ! Function arguments
    real(8), intent(in) :: ell
    real(8)             :: lowz_cl

    ! Local variables
    real(8) :: dell

    if (ell > 0) then
       ! Compute D_ell
       dell = dl_3k * (ell/3000)**gamma

       ! Convert to C_ell
       lowz_cl = dell * 2*pi / ell / (ell + 1)
    else
       lowz_cl = 0
    endif

    return
  end function lowz_cl


!------------------------------------------------------------------------------!


  subroutine compute_cl_tt
    ! Default
    implicit none


    ! Local variables
    integer(4) :: iell,nvals
    real(8)    :: ell,nl,clk,clc,cll,theta_fwhm,delta_t


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Build total array
    nvals = size(cl_cmb,dim=2)
    allocate(cl_tt(2,nvals))
    cl_tt = 0

    ! Decide on experiment
    select case(expt)
    case("so")
       ! SO
       delta_t    = delta_t_so
       theta_fwhm = theta_fwhm_so
    case("s4")
       ! S4
       delta_t    = delta_t_s4
       theta_fwhm = theta_fwhm_s4
    case("hd")
       ! HD
       delta_t    = delta_t_hd
       theta_fwhm = theta_fwhm_hd
    case default
       ! S4
       delta_t    = delta_t_s4
       theta_fwhm = theta_fwhm_s4
    end select

    do iell=1,nvals
       ell = iell - 1
       if (read_noise) then
          nl = interpolate(ell,nl_array,1,2,'lin')
       else
          nl  = delta_t**2 * exp(theta_fwhm**2 * ell**2 / (8D0 * log(2D0)))
       endif
       clk = interpolate(ell,cl_ksz,1,2,'lin')
       clc = cl_cmb(2,iell)
       cll = lowz_cl(ell)
       cl_tt(1,iell) = ell
       cl_tt(2,iell) = clk + clc + nl + cll
    enddo


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called compute Cl^TT'
    return
  end subroutine compute_cl_tt


!------------------------------------------------------------------------------!


  subroutine write_cl_tt
    ! Default
    implicit none


    ! Local variables
    integer(4)       :: error,nvals
    integer(HID_T)   :: file_id,dset_id,dspace_id
    integer(HSIZE_T) :: dims(1)
    real(8), dimension(:), allocatable :: io_array


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Initialize
    write(*,*) "Writing ",trim(cl_tt_fn)
    call h5open_f(error)
    call h5fcreate_f(trim(cl_tt_fn), H5F_ACC_TRUNC_F, file_id, error)

    ! Write data
    nvals = size(cl_tt,dim=2)
    allocate(io_array(nvals))
    io_array = cl_tt(2,:)

    dims = (/ nvals /)
    call h5screate_simple_f(1, dims, dspace_id, error)
    call h5dcreate_f(file_id, "cl_tt", H5T_NATIVE_DOUBLE, dspace_id, dset_id, &
         error)
    call h5dwrite_f(dset_id, H5T_NATIVE_DOUBLE, io_array, dims, error)
    call h5dclose_f(dset_id, error)
    call h5sclose_f(dspace_id, error)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called write Cl^TT'
    return
  end subroutine write_cl_tt


!------------------------------------------------------------------------------!


  function convolve_cl(ell)
    ! Default
    implicit none


    ! Local parameters
    integer(4), parameter :: N_integrate = 1000
    real(8),    parameter :: theta_min   = 0
    real(8),    parameter :: theta_max   = 2*pi
    real(8),    parameter :: d_theta     = (theta_max-theta_min)/N_integrate
    real(8),    parameter :: lmin_int    = 0

    ! Function arguments
    real(8), intent(in) :: ell
    real(8)             :: convolve_cl

    ! Local variables
    integer(4) :: il,ith
    real(8)    :: dl_int
    real(8)    :: L,theta,lprime,tmp
    real(8)    :: cl1,cl2,res,fL,flp

    ! Initialize
    dl_int = (lmax_int-lmin_int)/N_integrate

    ! Do double integral in parallel
    res = 0
    !$omp parallel do             &
    !$omp default(shared)         &
    !$omp private(il,ith,L,theta) &
    !$omp private(cl1,cl2,fL,flp) &
    !$omp private(lprime,tmp)     &
    !$omp reduction(+:res)
    do il=1,N_integrate
       L   = (il-0.5)*dl_int + lmin_int
       cl1 = interpolate(L,cl_tt,1,2,'lin')
       if (use_fell) then
          fL  = interpolate(L,f_ell,1,2,'lin')
       else
          if (L < lfilt_min .or. L > lfilt_max) then
             fL = 0
          else
             fL = 1
          endif
       endif

       tmp = 0
       do ith=1,N_integrate
          theta  = (ith-0.5)*d_theta + theta_min
          lprime = sqrt(ell**2 + L**2 - 2*ell*L*cos(theta))
          cl2    = interpolate(lprime,cl_tt,1,2,'lin')
          if (use_fell) then
             flp = interpolate(lprime,f_ell,1,2,'lin')
          else
             if (lprime < lfilt_min .or. lprime > lfilt_max) then
                flp = 0
             else
                flp = 1
             endif
          endif
          tmp = tmp + cl2*flp**2
       enddo
       res = res + (cl1*fL**2)*tmp*L
    enddo
    !$omp end parallel do

    ! add measure
    res = res * d_theta*dl_int

    convolve_cl = 2*res/(2*pi)**2
    return
  end function convolve_cl


!------------------------------------------------------------------------------!


  subroutine compute_integral
    ! Default
    implicit none


    ! Local variables
    integer(4) :: iell
    real(8)    :: ell,r0


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    allocate(output_array(2,N_ell))
    output_array = 0

    do iell=1,N_ell
       ell = (iell-1)*d_ell + ell_min
       r0  = convolve_cl(ell)
       output_array(1,iell) = ell
       output_array(2,iell) = r0
    enddo


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called compute integral'
    return
  end subroutine compute_integral


!------------------------------------------------------------------------------!


  subroutine save_output
    ! Default
    implicit none


    ! Local variables
    integer(4) :: un,i


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Write out the result
    un = 11
    open(un,file=output_fn)
    do i=1,N_ell
       write(un,"(2es16.8)") output_array(:,i)
    enddo
    close(un)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called save output'
    return
  end subroutine save_output


!------------------------------------------------------------------------------!


  subroutine probe_integrands
    ! Default
    implicit none


    ! Local parameters
    integer(4), parameter :: N_integrate = 1000
    real(8),    parameter :: theta_min   = 0
    real(8),    parameter :: theta_max   = 2*pi
    real(8),    parameter :: d_theta     = (theta_max-theta_min)/N_integrate
    real(8),    parameter :: lmin_int    = 0


    ! Local variables
    character(100) :: fn
    integer(4)     :: il,ith,un
    real(8)        :: dl_int,ell,tmp
    real(8)        :: L,theta,lprime
    real(8)        :: cl1,cl2,fL,flp
    real(8)        :: Lvals(5),res(5)


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Initialize
    dl_int = (lmax_int-lmin_int)/N_integrate
    Lvals  = (/ 5d2, 1d3, 3d3, 5d3, 8d3 /)

    ! extract values at several values of theta
    un  = 11
    fn  = "integrand_inner.txt"
    ell = 1000
    open(un,file=fn)
    do ith=1,N_integrate
       theta  = (ith-0.5)*d_theta + theta_min
       do il=1,5
          L = Lvals(il)
          lprime  = sqrt(ell**2 + L**2 - 2*ell*L*cos(theta))
          cl2     = interpolate(lprime,cl_tt,1,2,'lin')
          if (use_fell) then
             flp     = interpolate(lprime,f_ell,1,2,'lin')
          else
             if (lprime < lfilt_min .or. lprime > lfilt_max) then
                flp = 0
             else
                flp = 1
             endif
          endif
          res(il) = cl2*flp**2
       enddo
       write(un,"(6es16.8)") theta,res
    enddo
    close(un)

    ! Do some integrating
    un = 11
    fn = "integrand_outer.txt"
    open(un,file=fn)
    do il=1,N_integrate
       L   = (il-0.5)*dl_int + lmin_int
       cl1 = interpolate(L,cl_tt,1,2,'lin')
       if (use_fell) then
          fL  = interpolate(L,f_ell,1,2,'lin')
       else
          if (L < lfilt_min .or. L > lfilt_max) then
             fL = 0
          else
             fL = 1
          endif
       endif

       tmp = 0
       !$omp parallel do             &
       !$omp default(shared)         &
       !$omp private(ith,theta)      &
       !$omp private(cl2,flp,lprime) &
       !$omp reduction(+:tmp)
       do ith=1,N_integrate
          theta  = (ith-0.5)*d_theta + theta_min
          lprime = sqrt(ell**2 + L**2 - 2*ell*L*cos(theta))
          cl2    = interpolate(lprime,cl_tt,1,2,'lin')
          if (use_fell) then
             flp    = interpolate(lprime,f_ell,1,2,'lin')
          else
             if (lprime < lfilt_min .or. lprime > lfilt_max) then
                flp = 0
             else
                flp = 1
             endif
          endif
          tmp    = tmp + cl2*flp**2
       enddo
       !$omp end parallel do
       tmp = tmp * d_theta

       write(un,"(2es16.8)") L,tmp*L*(cl1*fL**2)
    enddo
    close(un)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called probe integrands'
    return
  end subroutine probe_integrands


end program main
