# -*- coding: utf-8 -*-

import os
import datetime
import h5py
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

add_watermark = False

dark_background = False
if dark_background:
    plt.style.use("dark_background")
    transparent = True
else:
    transparent = False

apply_mask = True

hist = "ext"
experiment = "s4"
noise_model = "ilc"

short_dir = "/jet/home/plaplant/scratch_ml/ksz/paul_short/"
ext_dir = "/jet/home/plaplant/scratch_ml/ksz/jackson_extended/"
early_dir = "/jet/home/plaplant/scratch_ml/ksz/jackson_early/"

short_data_dir = "/jet/home/plaplant/scratch_ml/ksz/fiducial/bt_bias/"
# ext_data_dir = "/ocean/projects/ast180004p/jsipple/ksz/extended_output/"
ext_data_dir = "/jet/home/plaplant/scratch_ml/ksz/jackson_extended/"
early_data_dir = "/ocean/projects/ast180004p/jsipple/ksz/early_output/"

if hist == "ext":
    root_dir = ext_dir
    data_dir = ext_data_dir
elif hist == "short":
    root_dir = short_dir
    data_dir = short_data_dir
elif hist == "early":
    root_dir = early_dir
    data_dir = early_data_dir

snr_fn = os.path.join(root_dir, f"snr_{hist}_{experiment}_{noise_model}_wide_z.hdf5")
output_fn = f"snr_{hist}_{experiment}_{noise_model}.pdf"
window_fn = os.path.join(data_dir, "output_0001", f"cl_arrays_window_{experiment}_{noise_model}.hdf5")
plot_title = False
title = "CMB-S4"
compute_zvals = False

fontsize = 20
sm_fontsize = 14

with h5py.File(snr_fn, "r") as h5f:
    snr = h5f["snr"][()]

with h5py.File(window_fn, "r") as h5f:
    if compute_zvals:
        window_zvals = h5f["data/window_zvals"][()]
    else:
        mid_vals = h5f["data/z_mid"][()]
        width_vals = h5f["data/delta_z"][()]

if compute_zvals:
    # compute the window midpoints and widths
    zvals_width = window_zvals[-1, :, :]
    width_vals = zvals_width[:, 1] - zvals_width[:, 0]

    zvals_mid = window_zvals[:, -1, :]
    mid_vals = np.average(zvals_mid, axis=1)

# plot result
matplotlib.rc("text", usetex=True)
matplotlib.rc("font", family="serif")

snr = 1.0 / snr.T
fig = plt.figure()
ax = plt.gca()

x = mid_vals
y = width_vals
XX, YY = np.meshgrid(x, y)

if apply_mask:
    # mask invalid values
    snr_mask = np.where(XX - YY / 2.0 < 6.0, 0.0, snr)
    snr_mask = np.where(XX + YY / 2.0 > 15.0, 0.0, snr_mask)
    im = ax.pcolormesh(XX, YY, snr_mask, shading="gouraud")
    # im = ax.pcolormesh(XX, YY, snr, shading="gouraud")
    # ax.plot(x, 2 * (x - 6), color="k", linestyle="--")
else:
    im = ax.pcolormesh(XX, YY, snr, shading="gouraud")
cb = plt.colorbar(im)
if plot_title:
    ax.set_title(title)

ax.set_xlabel(r"$z_0$", fontsize=fontsize)
ax.set_ylabel(r"$\Delta z$", fontsize=fontsize)
# cb.set_label(r"$\left(\frac{\Delta \mathcal{A}_{\mathrm{kSZ}^2}}{\mathcal{A}_{\mathrm{kSZ}^2}}\right)^{-1}$", fontsize=fontsize)
cb.set_label(r"S/N", fontsize=fontsize)
ax.set_xlim((7, 12))
if apply_mask:
    ax.set_ylim(width_vals[0], width_vals[-1])
ax.tick_params(axis="both", labelsize=sm_fontsize)
cb.ax.tick_params(labelsize=sm_fontsize)

if add_watermark:
    ax.text(
        0.5,
        0.5,
        "Preliminary",
        transform=ax.transAxes,
        fontsize=40,
        color="0.7",
        alpha=0.5,
        ha="center",
        va="center",
        rotation="30",
    )

date = datetime.date.today().strftime("%y%m%d")
plots_dir = os.path.join(root_dir, "plots", date)
if not os.path.isdir(plots_dir):
    os.makedirs(plots_dir)
output = os.path.join(plots_dir, output_fn)
print(f"saving {output}...")
fig.savefig(output, bbox_inches="tight", transparent=transparent)
plt.close(fig)
