module cosmo_tools
  ! Intel
  use IFPORT
  use OMP_LIB


  ! Global
  use global


  ! Tools
  use general_tools
  use fft_tools


  ! Default
  implicit none


  ! Local parameters
  integer(4), parameter :: N_scalefactor = 1000000


contains


  pure function E_of_a(a)
    ! Assumes we have a flat universe (OmegaK = 0)
    ! Default
    implicit none


    ! Function arguments
    real(8), intent(in) :: a
    real(8)             :: E_of_a


    ! Calculate Hubble parameter E(a)
    E_of_a = sqrt(OmegaM/a**3 + OmegaR/a**4 + OmegaL/a**(3*(1+wde)))
    return
  end function E_of_a


!------------------------------------------------------------------------------!


  pure function D_of_z(z)
    ! Default
    implicit none


    ! Local parameters
    real(8), parameter :: w   = wde
    real(8), parameter :: om  = omegam
    real(8), parameter :: ol  = omegal
    real(8), parameter :: or  = omegar
    real(8), parameter :: aeq = or/om


    ! Function arguments
    real(8), intent(in) :: z
    real(8)             :: D_of_z(2)


    ! Local variables
    real(8) :: a,ah,aw,af,H,q,c0,c1
    real(8) :: da,D,Dh,dDda,dDdah


    af   = 1D0/(1+z)
    a    = max(aeq,1D-6)
    D    = a + 2d0/3*aeq
    dDda = 1
    do while (a < af)
       da   = min(max(af-a,1D-8),1D-6)

       aw    = a**(3*(1+w))
       H     = sqrt(om/a**3 + or/a**4 + ol/aw)
       q     = (om/a**3 + 2*or/a**4 - 2*ol/aw)/H**2/2
       c0    = -1.5*om/H**2/a**5
       c1    = (2-q)/a
       Dh    = D + dDda*da/2
       dDdah = dDda - (c1*dDda+c0*D)*da/2
       ah    = a + da/2

       aw    = ah**(3*(1+w))
       H     = sqrt(om/ah**3 + or/ah**4 + ol/aw)
       q     = (om/ah**3 + 2*or/ah**4 - 2*ol/aw)/H**2/2
       c0    = -1.5*om/H**2/ah**5
       c1    = (2-q)/ah
       D     = D + dDdah*da
       dDda  = dDda - (c1*dDdah+c0*Dh)*da
       a     = a + da
    enddo

    D_of_z(1) = D
    D_of_z(2) = dDda*a/D

    do while (a < 1)
       da    = min(max(1-a,1D-8),1D-6)

       aw    = a**(3*(1+w))
       H     = sqrt(om/a**3 + or/a**4 + ol/aw)
       q     = (om/a**3 + 2*or/a**4 - 2*ol/aw)/H**2/2
       c0    = -1.5*om/H**2/a**5
       c1    = (2-q)/a
       Dh    = D + dDda*da/2
       dDdah = dDda - (c1*dDda+c0*D)*da/2
       ah    = a + da/2

       aw    = ah**(3*(1+w))
       H     = sqrt(om/ah**3 + or/ah**4 + ol/aw)
       q     = (om/ah**3 + 2*or/ah**4 - 2*ol/aw)/H**2/2
       c0    = -1.5*om/H**2/ah**5
       c1    = (2-q)/a
       D     = D + dDdah*da
       dDda  = dDda - (c1*dDdah+c0*Dh)*da
       a     = a + da
    enddo

    D_of_z(1) = D_of_z(1)/D

    return
  end function D_of_z


!------------------------------------------------------------------------------!


  subroutine calc_cosmo_var(z)
    ! Default
    implicit none


    ! Local parameters
    real(8), parameter :: om = omegam
    real(8), parameter :: ol = omegal
    real(8), parameter :: ob = omegab
    real(8), parameter :: or = omegar
    real(8), parameter :: h0 = hubble0


    ! Subroutine arguments
    real(8), intent(in) :: z


    ! Local variables
    real(8) :: a,hsq,oma
    real(8) :: D(2),f1,f2


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Cosmo
    a           = 1D0/(1+z)
    redshift    = z
    scalefactor = a
    hsq         = om/a**3 + ol/a**(3*(1+wde)) + or/a**4
    Hubble      = H0_cgs*h0*sqrt(hsq)
    rho_crit    = 3*Hubble**2/(8*pi*G_cgs)
    oma         = om/a**3/hsq**2


    ! Grid to physical values (cgs)
    x_unit    = (a*box/h0/Ndm)*Mpc2cm
    rho_unit  = rhoc_cgs*om*h0**2/a**3
    time_unit = 2/(3*H0_cgs*h0*sqrt(om))*a**2
    vel_unit  = x_unit/time_unit
    acc_unit  = x_unit/time_unit**2


    ! Density and velocity factors
    D        = D_of_z(z)
    Dfactor1 = D(1)
    Dfactor2 = -3d0/7*Dfactor1**2*oma**(-1D0/143)
    f1       = D(2)
    f2       = 2*oma**(6D0/11)
    vfactor1 = Dfactor1*f1*Hubble
    vfactor2 = Dfactor2*f2*Hubble


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called calc cosmo var'
    return
  end subroutine calc_cosmo_var


!------------------------------------------------------------------------------!


  subroutine calc_cosmo_distance
    ! Default
    implicit none


    ! Local variables
    integer(4) :: i
    real(8)    :: a,H,da


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Initialize
    allocate(d_comoving(2,N_scalefactor))
    d_comoving = 0


    ! Numerically integrate to calculate time
    ! chi[a] = Integrate[c/(ap)^2/H[ap], {ap, 1, a}]
    da = 1D0/N_scalefactor

    ! Comoving distance in Mpc/h
    d_comoving(1,N_scalefactor) = 1
    d_comoving(2,N_scalefactor) = 0

    do i=N_scalefactor-1,1,-1
       a = (i-0.5)*da
       H = 100*E_of_a(a)

       d_comoving(1,i) = a
       d_comoving(2,i) = d_comoving(2,i+1) + (c_cgs/1D5/H)*da/a**2
    enddo


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called calc cosmo distance'
    return
  end subroutine calc_cosmo_distance


!------------------------------------------------------------------------------!


  subroutine calc_angular_distance
    ! Assumes we have a flat universe (i.e., OmegaK = 0)
    ! Default
    implicit none


    ! Local variables
    integer(4) :: i
    real(8)    :: a,z


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Initialize
    allocate(angular_distance(2,N_scalefactor))
    angular_distance = 0


    ! Compute angular diameter distance
    ! For a universe with OmegaK = 0, D_A(z) = D_c(z)/(1+z)
    do i=1,N_scalefactor
       a = d_comoving(1,i)
       z = 1/a - 1

       angular_distance(1,i) = a
       angular_distance(2,i) = d_comoving(2,i)/(1 + z)
    enddo


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called calc angular distance'
    return
  end subroutine calc_angular_distance


!------------------------------------------------------------------------------!


  subroutine calc_tau
    ! Default
    implicit none


    ! Local variables
    integer(4) :: i
    real(8)    :: a,z,da
    real(8)    :: ne,nHe,xval
    real(8)    :: dtau,dchi
    real(8), dimension(2,Nredshift) :: x_interp


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Perform numeric integral to compute tau(z)
    ! tau(z) = \int_0^chi(z') d chi n_e(z') * sigma_T * (1+z')**2

    ! Initialize
    if (.not. allocated(tau_vals)) then
       allocate(tau_vals(2,N_scalefactor))
    endif
    tau_vals = 0

    x_interp(1,:) = zval_list
    x_interp(2,:) = xmval_list

    tau_vals(1,N_scalefactor) = 0
    tau_vals(2,N_scalefactor) = 0

    ! Do integral
    da = 1D0/N_scalefactor
    do i=N_scalefactor-1,1,-1
       a = (i-0.5)*da
       z = 1/a - 1

       dchi = abs(d_comoving(2,i+1) - d_comoving(2,i))
       ! Assume helium is doubly ionized at z<=3, tracks hydrogen earlier
       if (z <= 3) then
          nHe = 2
       else
          nHe = 1
       endif
       if (z <= zval_list(1)) then
          ! Things should be totally ionized
          xval = 1
       else if (z >= zval_list(Nredshift)) then
          ! Totally neutral
          xval = 0
       else
          ! Linearly interpolate
          xval = 1 - interpolate(z,x_interp,1,2,'lin')
       endif
       ne = xval*(1-(4-nHe)*YHe/4.0)*OmegaB*rhoc_cgs/mH_cgs*hubble0**2

       dtau = sT_cgs*ne*(1+z)**2*dchi*Mpc2cm/hubble0

       tau_vals(1,i) = z
       tau_vals(2,i) = tau_vals(2,i+1) + dtau
    enddo


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called calc tau'
    return
  end subroutine calc_tau


!------------------------------------------------------------------------------!


  subroutine calc_linear_power_spectrum
    ! Default
    implicit none


    ! Local variables
    integer(4)      :: k,k1,k2,un
    real(8)         :: kr,dk,dlnk,var,x
    real(8)         :: tcdm,tbar,tmat
    character(1000) :: tmp
    real(8), dimension(7) :: data


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Get transfer functions from CAMB
    un = 11
    write(*,'(2a)') "Reading ",fn_pkl
    open(un,file=fn_pkl)
    k = 0

    ! Throw away header
    read(un,*) tmp

    do
       ! Read CAMB transfer functions
       read(un,*,end=1) data

       k    = k + 1
       kr   = data(1)
       tcdm = data(2)
       tbar = data(3)
       tmat = data(7)


       ! Linear density field at z = 0
       ! Density and velocity growth factors
       pk_lin(1,k) = kr
       pk_lin(3,k) = kr**(3+nsinit)*tcdm**2/(2*pi**2)
       pk_lin(4,k) = kr**(3+nsinit)*tbar**2/(2*pi**2)
       pk_lin(5,k) = kr**(3+nsinit)*tmat**2/(2*pi**2)
    enddo
1   continue
    close(un)
    Npkl = k


    ! Compute dk
    do k=1,Npkl
       if (k == 1) then
          k1 = k
          k2 = k + 1
       else if (k == Npkl) then
          k1 = k - 1
          k2 = k
       else
          k1 = k - 1
          k2 = k + 1
       endif

       kr          = pk_lin(1,k)
       dlnk        = log(pk_lin(1,k2)/pk_lin(1,k1))/(k2-k1)
       pk_lin(2,k) = kr*dlnk
    enddo

    ! Normalize to sigma8
    ! Compute variance in 8 Mpc/h spheres
    var = 0
    do k=1,Npkl
       kr  = pk_lin(1,k)
       dk  = pk_lin(2,k)
       x   = kr*8
       var = var + pk_lin(5,k)*tophat(x)**2*dk/kr
    enddo
    pk_lin(3:5,:) = pk_lin(3:5,:)*(sigma8**2/var)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called calc linear pk'
    return
  end subroutine calc_linear_power_spectrum


!------------------------------------------------------------------------------!


  subroutine window_field(field,norm,type)
    ! These window function follow the convention for even windows implemented
    !   by scipy.signal.windows. Currently only cosine and Blackman-Harris
    !   windows are implemented.

    ! Default
    implicit none


    ! Subroutine arguments
    real(8),      intent(out)          :: norm
    character(*), intent(in), optional :: type
    real(8), dimension(N_grid+2,N_grid), intent(inout) :: field


    ! Local variables
    integer(4)   :: i,j
    real(8)      :: wx,wy,nr,a(0:3)
    character(3) :: tp


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Initialize
    nr = 0
    if (present(type)) then
       tp = type
    else
       tp = 'cos'
    endif

    ! Select case of window function
    select case(tp)
    case('cos')
       ! Cosine window
       !$omp parallel do        &
       !$omp private(i,j,wx,wy) &
       !$omp reduction(+:nr)
       do j=1,N_grid
          wy = cos(pi*(j-0.5)/ngridr - pi/2)

          do i=1,N_grid
             wx = cos(pi*(i-0.5)/ngridr - pi/2)

             nr = nr + (wx*wy)**2
             field(i,j) = field(i,j) * wx*wy
          enddo
       enddo
       !$omp end parallel do

       nr = nr/ngridr**2
    case('bh')
       ! Blackman-Harris window
       a(0) = 0.35875D0
       a(1) = 0.48829D0
       a(2) = 0.14128D0
       a(3) = 0.01168D0

       !$omp parallel do        &
       !$omp private(i,j,wx,wy) &
       !$omp reduction(+:nr)
       do j=1,N_grid
          wy =   a(0) &
               - a(1)*cos(2*pi*(j-1)/(ngridr-1)) &
               + a(2)*cos(4*pi*(j-1)/(ngridr-1)) &
               - a(3)*cos(6*pi*(j-1)/(ngridr-1))

          do i=1,N_grid
             wx =   a(0) &
                  - a(1)*cos(2*pi*(i-1)/(ngridr-1)) &
                  + a(2)*cos(4*pi*(i-1)/(ngridr-1)) &
                  - a(3)*cos(6*pi*(i-1)/(ngridr-1))

             nr = nr + (wx*wy)**2
             field(i,j) = field(i,j) * wx*wy
          enddo
       enddo
       !$omp end parallel do

       nr = nr/ngridr**2
    case default
       ! Do nothing
       nr = 1
    end select

    ! Return to the user
    norm = sqrt(nr)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called window field'
    return
  end subroutine window_field


!------------------------------------------------------------------------------!


  subroutine filter_field_tophat(field,ell_min,ell_max)
    ! Default
    implicit none


    ! Subroutine parameters
    real(8), parameter :: theta_fwhm = 1.4D0 * pi/180D0/60D0 ! arcmin -> rad


    ! Subroutine arguments
    real(8), intent(in) :: ell_min,ell_max
    real(8), dimension(N_grid+2,N_grid), intent(inout) :: field


    ! Local variables
    integer(4) :: i,j
    real(8)    :: lx,ly,ell,bell


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Assume field is already in k-space
    !$omp parallel do        &
    !$omp default(shared)    &
    !$omp private(i,j,lx,ly) &
    !$omp private(ell,bell)
    do j=1,N_grid
       if (j <= N_grid/2+1) then
          ly = 2*pi/theta_max_ksz*(j-1)
       else
          ly = 2*pi/theta_max_ksz*(j-1-N_grid)
       endif

       do i=1,N_grid+2,2
          lx = 2*pi/theta_max_ksz*((i-1)/2)

          ell  = sqrt(lx**2 + ly**2)
          bell = exp(-theta_fwhm**2 * ell**2 / (8*log(2D0)))

          if (ell < ell_min .or. ell > ell_max) then
             field(i:i+1,j) = 0
          else
             field(i:i+1,j) = field(i:i+1,j)*bell
          endif
       enddo
    enddo
    !$omp end parallel do


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called filter field tophat'
    return
  end subroutine filter_field_tophat


!------------------------------------------------------------------------------!


  subroutine filter_field_wiener(field)
    ! Default
    implicit none


    ! Subroutine arguments
    real(8), dimension(N_grid+2,N_grid), intent(inout) :: field


    ! Local variables
    integer(4) :: i,j
    real(8)    :: lx,ly,ell,filt


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Assume field is already in k-space
    !$omp parallel do        &
    !$omp default(shared)    &
    !$omp private(i,j,lx,ly) &
    !$omp private(ell,filt)
    do j=1,N_grid
       if (j <= N_grid/2+1) then
          ly = 2*pi/theta_max_ksz*(j-1)
       else
          ly = 2*pi/theta_max_ksz*(j-1-N_grid)
       endif

       do i=1,N_grid+2,2
          lx = 2*pi/theta_max_ksz*((i-1)/2)

          ell = sqrt(lx**2 + ly**2)

          ! Interpolate to get filter value
          filt = interpolate(ell,f_ell,1,2,'lin')

          field(i:i+1,j) = field(i:i+1,j)*filt
       enddo
    enddo
    !$omp end parallel do

    tr2 = omp_get_wtime()
    call time(ts2)
    ! write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called filter field wiener'
    return
  end subroutine filter_field_wiener


!------------------------------------------------------------------------------!


  subroutine square_field(field)
    ! Default
    implicit none


    ! Subroutine arguments
    real(8), dimension(N_grid+2,N_grid), intent(inout) :: field


    ! Local variables
    integer(4) :: i,j


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Square field pixel-by-pixel
    !$omp parallel do     &
    !$omp default(shared) &
    !$omp private(i,j)
    do j=1,N_grid
       do i=1,N_grid
          field(i,j) = field(i,j)**2
       enddo
    enddo
    !$omp end parallel do


    tr2 = omp_get_wtime()
    call time(ts2)
    ! write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called square field'
    return
  end subroutine square_field


!------------------------------------------------------------------------------!


  subroutine calc_cl_spectrum(field1,field2,cl_array,square1,square2)
    ! Default
    implicit none

    ! Filter?
    logical, parameter :: filter  = .true.
    logical, parameter :: tophat  = .false.  ! .true. = tophat, .false. = wiener
    logical, parameter :: apodize = .false.
    real(8), parameter :: l_min   = 1e3  ! tophat min
    real(8), parameter :: l_max   = 1e4  ! tophat max


    ! Subroutine arguments
    real(8), dimension(3,N_grid)      :: cl_array
    real(8), dimension(N_grid,N_grid) :: field1,field2
    logical, optional                 :: square1,square2


    ! Local variables
    integer(4) :: i,j,k
    real(8)    :: lx,ly,ell
    real(8)    :: norm1,norm2,p,w
    logical    :: sq1,sq2


    ! Local arrays
    real(8), dimension(3,N_grid)        :: cl
    real(8), dimension(N_grid+2,N_grid) :: field1_fft,field2_fft


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Initialize
    cl = 0
    if (present(square1)) then
       sq1 = square1
    else
       sq1 = .false.
    endif
    if (present(square2)) then
       sq2 = square2
    else
       sq2 = .false.
    endif

    ! Copy array over
    !$omp parallel        &
    !$omp default(shared) &
    !$omp private(i,j)
    !$omp do
    do j=1,N_grid
       do i=1,N_grid
          field1_fft(i,j) = field1(i,j)
       enddo
    enddo
    !$omp end do
    !$omp do
    do j=1,N_grid
       do i=1,N_grid
          field2_fft(i,j) = field2(i,j)
       enddo
    enddo
    !$omp end do
    !$omp end parallel

    ! FFT into Fourier space
    if (apodize) then
       call window_field(field1_fft,norm1,'cos')
       call window_field(field2_fft,norm2,'cos')
    else
       norm1 = 1
       norm2 = 1
    endif
    ! write(*,*) "norms: ", norm1,norm2
    if (sq1) then
       if (filter) then
          call fft_2d('f',N_grid,N_grid,field1_fft)
          if (tophat) then
             call filter_field_tophat(field1_fft,l_min,l_max)
          else
             call filter_field_wiener(field1_fft)
          endif
          call fft_2d('b',N_grid,N_grid,field1_fft)
       endif
       call square_field(field1_fft)
    endif
    if (sq2) then
       if (filter) then
          call fft_2d('f',N_grid,N_grid,field2_fft)
          if (tophat) then
             call filter_field_tophat(field2_fft,l_min,l_max)
          else
             call filter_field_wiener(field2_fft)
          endif
          call fft_2d('b',N_grid,N_grid,field2_fft)
       endif
       call square_field(field2_fft)
    endif
    call fft_2d('f',N_grid,N_grid,field1_fft)
    call fft_2d('f',N_grid,N_grid,field2_fft)

    ! Compute Cl spectra
    !$omp parallel do        &
    !$omp default(shared)    &
    !$omp private(i,j,k,w,p) &
    !$omp private(lx,ly,ell) &
    !$omp reduction(+:cl)
    do j=1,N_grid
       if (j <= N_grid/2+1) then
          ly = 2*pi/theta_max_ksz*(j-1)
       else
          ly = 2*pi/theta_max_ksz*(j-1-N_grid)
       endif

       do i=1,N_grid+2,2
          lx = 2*pi/theta_max_ksz*((i-1)/2)
          if (i == 1 .or. i == N_grid+1) then
             w = 1
          else
             w = 2
          endif

          ell = sqrt(lx**2 + ly**2)

          if (ell > 0) then
             p = sum(field1_fft(i:i+1,j)/ngridr**2/norm1 &
                    *field2_fft(i:i+1,j)/ngridr**2/norm2)

             ! Calculate bin
             k = nint(ell/(2*pi/theta_max_ksz))

             ! Add to bin
             cl(1,k) = cl(1,k) + w
             cl(2,k) = cl(2,k) + w*p
             cl(3,k) = cl(3,k) + w*p**2
          endif
       enddo
    enddo
    !$omp end parallel do

    ! Finish computing spectrum
    do k=1,N_grid
       if (cl(1,k) > 0) then
          cl(2:3,k) = cl(2:3,k)/cl(1,k)
          cl(  3,k) = sqrt(max((cl(3,k) - cl(2,k)**2) &
               /max(cl(1,k)-1,1D0),0D0))
       else
          cl(2:3,k) = 0
       endif

       ! Fill in ell-modes
       cl(1,k) = 2*pi/theta_max_ksz*k

       ! Add theta factors
       cl(2:3,k) = cl(2:3,k) * theta_max_ksz**2
    enddo

    ! Save in target array
    cl_array = cl


    tr2 = omp_get_wtime()
    call time(ts2)
    ! write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called calc cl spectrum'
    return
  end subroutine calc_cl_spectrum


!------------------------------------------------------------------------------!


  subroutine calc_map_variance(field,cl_array)
    ! Default
    implicit none


    ! Subroutine arguments
    real(8), dimension(3,N_grid)      :: cl_array
    real(8), dimension(N_grid,N_grid) :: field


    ! Local variables
    integer(4) :: i,j
    real(8)    :: l,cl,clint
    real(8)    :: t,tavg,tvar,tfac


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Initialize
    tfac = 1d6*Tcmb0

    ! Compute the map-space variance of the map
    tavg = 0
    tvar = 0
    !$omp parallel do            &
    !$omp default(shared)        &
    !$omp private(i,j,t)         &
    !$omp reduction(+:tavg,tvar)
    do j=1,N_grid
       do i=1,N_grid
          t    = field(i,j) * tfac
          tavg = tavg + t
          tvar = tvar + t**2
       enddo
    enddo
    !$omp end parallel do

    ! Finish computing statistics
    tavg = tavg/ngridr**2
    tvar = tvar/ngridr**2 - tavg**2

    ! Compute integral of the C_l spectrum
    clint = 0
    do i=1,N_grid/2
       l     = cl_array(1,i)
       cl    = cl_array(2,i) * tfac**2
       clint = clint + l*cl
    enddo
    clint = clint/(2*pi)

    ! Write out the results
    write(*,*) "tavg:  ",tavg
    write(*,*) "tvar:  ",tvar
    write(*,*) "cl:    ",clint


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called cal map variance'
    return
  end subroutine calc_map_variance


!------------------------------------------------------------------------------!


  subroutine calc_pspec(field1,field2,pk_out)
    ! Default
    implicit none


    ! Subroutine arguments
    real(8), dimension(3,N_grid)               :: pk_out
    real(8), dimension(N_grid+2,N_grid,N_grid) :: field1,field2


    ! Local variables
    integer(4) :: i,j,k,kk
    real(8)    :: kx,ky,kz,kr
    real(8)    :: p,w


    ! Local arrays
    real(8), dimension(3,N_grid) :: pk


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Initialize
    pk = 0

    ! Compute cross spectrum between fields
    ! We assume fields have already been Fourier transformed
    !$omp parallel do            &
    !$omp default(shared)        &
    !$omp private(i,j,k,kk,w)    &
    !$omp private(kx,ky,kz,kr,p) &
    !$omp reduction(+:pk)
    do k=1,N_grid
       if (k <= N_grid/2+1) then
          kz = 2*pi/ngridr*(k-1)
       else
          kz = 2*pi/ngridr*(k-1-N_grid)
       endif

       do j=1,N_grid
          if (j <= N_grid/2+1) then
             ky = 2*pi/ngridr*(j-1)
          else
             ky = 2*pi/ngridr*(j-1-N_grid)
          endif

          do i=1,N_grid+2,2
             kx = 2*pi/ngridr*((i-1)/2)
             if (i == 1 .or. i == N_grid+1) then
                w = 1
             else
                w = 2
             endif

             kr = sqrt(kx**2 + ky**2 + kz**2)

             if (kr > 0) then
                kk = nint(kr/(2*pi/ngridr))

                p = sum(field1(i:i+1,j,k)/ncellr &
                       *field2(i:i+1,j,k)/ncellr)

                ! Add to bin
                pk(1,kk) = pk(1,kk) + w
                pk(2,kk) = pk(2,kk) + w*p
                pk(3,kk) = pk(3,kk) + w*p**2
             endif
          enddo
       enddo
    enddo
    !$omp end parallel do

    ! Calculate power spectrum
    do k=1,N_grid
       if (pk(1,k) > 0) then
          pk(2:3,k) = pk(2:3,k)/pk(1,k)
          pk(  3,k) = sqrt(max((pk(3,k) - pk(2,k)**2)/max(pk(1,k)-1,1D0),0D0))
       else
          pk(2:3,k) = 0
       endif

       ! Compute Delta^2(k)
       pk(  1,k) = 2*pi*k/box
       pk(2:3,k) = pk(2:3,k)*4*pi*k**3

       ! Convert to P(k)
       kr        = pk(1,k)
       pk(2:3,k) = pk(2:3,k)*2*pi**2/kr**3
    enddo

    ! Save in output array
    pk_out = pk


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called calc pspec'
    return
  end subroutine calc_pspec


!------------------------------------------------------------------------------!


  subroutine apply_wedge_filter
    ! Default
    implicit none


    ! Local variables
    integer(4) :: i,j,k
    real(8)    :: kx,ky,kz,wz,ns
    real(8)    :: kperp,kpara,slp


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Initialize
    ns = Nsightpix

    ! Apodize window along line-of-sight axis
    !$omp parallel do       &
    !$omp default(shared)   &
    !$omp private(i,j,k,wz)
    do k=1,Nsightpix
       wz = cos(pi*(k-0.5)/ns - pi/2)
       do j=1,N_grid
          do i=1,N_grid
             t21_box(i,j,k) = t21_box(i,j,k)*wz
          enddo
       enddo
    enddo
    !$omp end parallel do

    ! Apply FFT
    call fft_3d('f',N_grid,N_grid,Nsightpix,t21_box)

    ! Compute wedge slope for a middling redshift
    slp = wedge_slope(8D0)

    ! Apply wedge filter
    !$omp parallel do          &
    !$omp default(shared)      &
    !$omp private(i,j,k)       &
    !$omp private(kx,ky,kz)    &
    !$omp private(kperp,kpara)
    do k=1,Nsightpix
       if (k <= Nsightpix/2+1) then
          kz = 2*pi/ns*(k-1)
       else
          kz = 2*pi/ns*(k-1-Nsightpix)
       endif

       kpara = abs(kz)

       do j=1,N_grid
          if (j <= N_grid/2+1) then
             ky = 2*pi/ngridr*(j-1)
          else
             ky = 2*pi/ngridr*(j-1-N_grid)
          endif

          do i=1,N_grid+2,2
             kx = 2*pi/ngridr*((i-1)/2)

             kperp = sqrt(kx**2 + ky**2)

             if (kpara <= kperp*slp) then
                t21_box(i:i+1,j,k) = 0
             endif
          enddo
       enddo
    enddo
    !$omp end parallel do

    ! Inverse FFT
    call fft_3d('b',N_grid,N_grid,Nsightpix,t21_box)


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called apply wedge filter'
    return


  contains


    pure function wedge_slope(z)
      ! Function for computing the slope of the foreground wedge m, such that:
      !   k_parallel = m * k_perp
      ! We derive this expression by using Eqs. 5 and 6 of Thyagarajan et al. 2015
      !   and setting k_parallel = k_perp, and using tau=tau_horizon, so
      !   |b| = tau*c.
      ! The full expression is:
      !   m = (lambda*D*f21*H0*E(z))/(c^2 * (1+z)^2),
      ! where lambda is the wavelength of the 21 cm line at redshift z, D is the
      !   comoving distance to the specified redshift, f21 is the rest-frame
      !   wavelength of the 21 cm transition, H0 is the Hubble constant, E(z)
      !   is the reduced Hubble parameter, and c is the speed of light. For the
      !   redshifts of interest, m ~ 3.
      !
      ! Defaualt
      implicit none

      ! Function arguments
      real(8), intent(in) :: z
      real(8)             :: wedge_slope

      ! Local variables
      real(8) :: a,lambda,D,f21,Ez

      ! Init
      a = 1D0/(1+z)

      ! Compute comoving distance of redshift, convert to cgs/h
      D = interpolate(a,d_comoving,1,2,'lin')*Mpc2cm

      ! Compute E(z)
      Ez = E_of_a(a)

      ! Compute wavelength of redshifted 21cm line
      lambda = lam21_cgs*(1+z)

      ! Compute rest-frame frequency of 21cm line
      f21 = c_cgs/lam21_cgs

      ! Put it all together
      wedge_slope = lambda*D*f21*H0_cgs*Ez/(c_cgs**2 * (1+z)**2)
      return
    end function wedge_slope


  end subroutine apply_wedge_filter


end module cosmo_tools
