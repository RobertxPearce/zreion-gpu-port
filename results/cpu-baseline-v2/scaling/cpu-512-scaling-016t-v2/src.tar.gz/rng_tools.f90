! MKL
include 'mkl_vsl.fi'


module rng_tools
  ! Intel
  use IFPORT
  use OMP_LIB


  ! MKL
  use MKL_VSL_TYPE
  use MKL_VSL


  ! Global
  use global


  ! Default
  implicit none


contains


  subroutine make_gaussian_random_field
    ! Default
    implicit none


    ! Local variables
    integer(4) :: i,j,k
    integer(4) :: brng,method,errcode
    real(8)    :: a,b,sigma
    real(8)    :: d,davg,dsig,dmax,dmin
    type(VSL_STREAM_STATE) :: stream
    integer(4), dimension(Ndm) :: iseed
    real(8),    dimension(Ndm) :: xseed


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Initialize seeds.
    !
    ! Everything below is a deterministic function of iseed(1): one MT19937
    ! stream turns it into Ndm per-slab seeds, and each k-slab then draws from
    ! its own stream. The field is therefore independent of thread count and
    ! scheduling, and four bytes are enough to replay it exactly. iseed_run is
    ! the run's record of that number -- set it from the command line to repeat
    ! a realization, leave it 0 to draw a fresh one from system entropy.
    if (iseed_run == 0) then
       call random_seed()
       call random_number(d)
       i = d * huge(0)
       ! 0 is the sentinel for "draw one", so it must not also be a valid seed.
       if (i == 0) i = 1
       iseed_run = i
    endif
    iseed(1) = iseed_run
    write(*,*) "GRF seed: ",iseed_run
    a        = 0
    b        = 1
    brng     = VSL_BRNG_MT19937
    method   = VSL_RNG_METHOD_UNIFORM_STD_ACCURATE
    errcode  = vslnewstream(stream,brng,iseed(1))
    errcode  = vdrnguniform(method,stream,Ndm,xseed,a,b)
    iseed    = int(xseed*huge(0))

    ! Generate Gaussian random numbers
    brng   = VSL_BRNG_MT19937
    method = VSL_RNG_METHOD_GAUSSIAN_BOXMULLER2
    a      = 0
    sigma  = 1

    !$omp parallel do                &
    !$omp default(shared)            &
    !$omp private(j,k,stream,errcode)
    do k=1,Ndm
       ! Initialize stream
       errcode = vslnewstream(stream,brng,iseed(k))

       ! Generate random numbers
       do j=1,Ndm
          errcode = vdrnggaussian(method,stream,Ndm,delta1(1:Ndm,j,k),a,sigma)
       enddo

       ! Delete stream
       errcode = vsldeletestream(stream)
    enddo
    !$omp end parallel do

    ! Check gaussian random field
    davg = 0
    dsig = 0
    dmax = 0
    dmin = huge(dmin)

    !$omp parallel do            &
    !$omp private(i,j,k,d)       &
    !$omp reduction(+:davg,dsig) &
    !$omp reduction(max:dmax)    &
    !$omp reduction(min:dmin)
    do k=1,Ndm
       do j=1,Ndm
          do i=1,Ndm
             d    = delta1(i,j,k)
             davg = davg + d
             dsig = dsig + d**2
             dmax = max(dmax,d)
             dmin = min(dmin,d)
          enddo
       enddo
    enddo
    !$omp end parallel do


    ! Field is normalized so that sigma**2(cell) = 1
    davg = davg/Npart
    dsig = sqrt(dsig/Npart - davg**2)
    write(*,*) "GRF: ",real((/davg,dsig,dmin,dmax/))


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,&
         '  Called make gaussian random field'
    return
  end subroutine make_gaussian_random_field


end module rng_tools
