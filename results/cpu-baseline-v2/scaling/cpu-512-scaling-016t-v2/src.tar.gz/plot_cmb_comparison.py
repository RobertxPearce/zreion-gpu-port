# -*- coding: utf-8 -*-

import h5py
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import gridspec

# read in CMB from CAMB
with h5py.File("../cmb_map/camb_output.hdf5", "r") as h5f:
    cl_lensed = h5f["data/lensed_scalar"][()]

# read in our spectrum
cl_estimate = np.genfromtxt("cmb_estimate.txt")

ells_camb = np.arange(cl_lensed.shape[0])
dl_camb = cl_lensed[:, 0]

ells_est = cl_estimate[:, 0]
dl_est = ells_est * (ells_est + 1) * cl_estimate[:, 1] / (2 * np.pi)

matplotlib.rc("text", usetex=True)
matplotlib.rc("font", family="serif")

fig = plt.figure()
gs = gridspec.GridSpec(2, 1, height_ratios=[2, 1], hspace=0.0)
ax1 = plt.subplot(gs[0])
ax2 = plt.subplot(gs[1], sharex=ax1)
ax2.axhline(y=0.0, color="k", linestyle="--")

ax1.loglog(ells_camb, dl_camb, label="CAMB", color="C0", alpha=0.5)
ax1.loglog(ells_est, dl_est, label="From map", color="C1", alpha=0.5)

interp_vals = np.interp(ells_est, ells_camb, dl_camb)
pct_diff = dl_est / interp_vals - 1
ax2.semilogx(ells_est, pct_diff, color="C1", alpha=0.5)

ax1.legend(loc=0)
ax1.set_ylim((1e-2, 1e4))
ax2.set_ylim((-0.1, 0.1))
yticks = ax2.get_yticks()
ax2.set_yticks(yticks[:-1])
ax2.set_xlabel(r"$\ell$")
ax1.set_ylabel(r"$\ell(\ell+1)C_\ell/2\pi$ [$\mu$K$^2$]")
ax2.set_ylabel("Relative difference")
output = "plots/camb_comparison.pdf"
print(f"saving {output}...")
fig.savefig(output, bbox_inches="tight")
plt.close(fig)
