#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import numpy as np
import h5py

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# read in data files
root_dir = "/jet/home/plaplant/scratch_ml/ksz/output_0001"
fn = os.path.join(root_dir, "pk_arrays.hdf5")
with h5py.File(fn, "r") as h5f:
    zvals = h5f["data/zval_list"][()]
    xvals = h5f["data/xval_list"][()]
    pk_dd = h5f["data/pk_dd"][()]
    pk_xx = h5f["data/pk_xx"][()]
    pk_dx = h5f["data/pk_dx"][()]

nmax = pk_dd.shape[1] // 2

# matplotlib options
matplotlib.rc("text", usetex=True)
matplotlib.rc("font", family="serif")

# make plots
fig_xx = plt.figure()
ax_xx = plt.gca()
fig_dx = plt.figure()
ax_dx = plt.gca()
fig_dd = plt.figure()
ax_dd = plt.gca()

# loop over redshift
for iz, z in enumerate(zvals):
    if z < 5.5:
        continue
    if z > 15:
        continue
    label = fr"$z = {z}$"

    if iz > 10:
        linestyle = "--"
    else:
        linestyle = "-"

    k = pk_xx[iz, :nmax, 0]
    p = pk_xx[iz, :nmax, 1]
    ax_xx.loglog(k, p, label=label, alpha=0.5, linestyle=linestyle)

    k = pk_dd[iz, :nmax, 0]
    p = pk_dd[iz, :nmax, 1]
    ax_dd.loglog(k, p, label=label, alpha=0.5, linestyle=linestyle)

    k = pk_dx[iz, :nmax, 0]
    p = pk_dx[iz, :nmax, 1]
    ax_dx.semilogx(k, p, label=label, alpha=0.5, linestyle=linestyle)

# make plots pretty
ax_xx.set_xlabel(r"$k$ [$h$Mpc$^{-1}$]")
ax_xx.set_ylabel(r"$P(k)$ [($h^{-1}$Mpc)$^3$]")
ax_xx.legend(loc=0)

ax_dd.set_xlabel(r"$k$ [$h$Mpc$^{-1}$]")
ax_dd.set_ylabel(r"$P(k)$ [($h^{-1}$Mpc)$^3$]")
ax_dd.legend(loc=0)

ax_dx.set_xlabel(r"$k$ [$h$Mpc$^{-1}$]")
ax_dx.set_ylabel(r"$P(k)$ [($h^{-1}$Mpc)$^3$]")
ax_dx.legend(loc=0)

output = "pk_xx.pdf"
print(f"saving {output}...")
fig_xx.savefig(output, bbox_inches="tight")
output = "pk_dd.pdf"
print(f"saving {output}...")
fig_dd.savefig(output, bbox_inches="tight")
output = "pk_dx.pdf"
print(f"saving {output}...")
fig_dx.savefig(output, bbox_inches="tight")
