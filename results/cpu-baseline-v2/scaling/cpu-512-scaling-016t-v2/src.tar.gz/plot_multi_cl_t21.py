#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import datetime
import h5py
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.offsetbox import AnchoredText

from bin_cl import bin_cl

dark_background = False
if dark_background:
    plt.style.use("dark_background")
    transparent = True
    ax_color = "w"
else:
    transparent = False
    ax_color = "k"

fontsize = 20
sm_fontsize = 14

# general analysis/plot options
experiment = "so"
log_width = 0.2
binned_file = f"data/binned_cl_t21.hdf5"
plot_ells = False
plot_z = True
plot_actual_errors = False
cl_window_fn = f"cl_arrays_window_{experiment}_ilc.hdf5"
plot_title = False

# read in Cl spectrum
root_dir = "/jet/home/plaplant/scratch_ml/ksz/fiducial/bt_bias"
output_dirs = sorted([d for d in os.listdir(root_dir) if "output_00" in d])

# matplotlib options
matplotlib.rc("text", usetex=True)
matplotlib.rc("font", family="serif")
matplotlib.rc("lines", linewidth=1.1)

# get representative window values
cl_fn = os.path.join(root_dir, output_dirs[0], cl_window_fn)
with h5py.File(cl_fn, "r") as h5f:
    window_zvals = h5f["data/window_zvals"][()]

# read in file if already computed
try:
    with h5py.File(binned_file, "r") as h5f:
        binned_ells = h5f["binned_ells"][()]
        binned_cl = h5f["binned_cl"][()]
        binned_cl2 = h5f["binned_cl2"][()]

    have_data = True
except (IOError, OSError):
    have_data = False

if not have_data:
    navg = 0
    for idir, dirname in enumerate(output_dirs):
        cl_fn = os.path.join(root_dir, dirname, cl_window_fn)
        print(f"reading {cl_fn}...")
        with h5py.File(cl_fn, "r") as h5f:
            cl_t21 = h5f["data/cl_t21"][()]

        ells = cl_t21[:, :, 1:, 0]
        cl = cl_t21[:, :, 1:, 1]
        cl2 = cl_t21[:, :, 1:, 1]**2

        if idir == 0:
            # bin up spectra
            binned_ells, temp_cl = bin_cl(
                ells[0, 0, :], cl[0, 0, :], log_bins=True, log_width=log_width
            )
            binned_cl = np.zeros(
                (cl.shape[0], cl.shape[1], temp_cl.shape[0]), dtype=np.float64
            )
            binned_cl2 = np.zeros(
                (cl.shape[0], cl.shape[1], temp_cl.shape[0]), dtype=np.float64
            )
            for i in range(cl.shape[0]):
                for j in range(cl.shape[1]):
                    binned_cl[i, j, :] = bin_cl(
                        ells[i, j, :], cl[i, j, :], log_bins=True, log_width=log_width
                    )[1]
                    binned_cl2[i, j, :] = bin_cl(
                        ells[i, j, :], cl2[i, j, :], log_bins=True, log_width=log_width
                    )[1]
        else:
            for i in range(cl.shape[0]):
                for j in range(cl.shape[1]):
                    binned_cl[i, j, :] += bin_cl(
                        ells[i, j, :], cl[i, j, :], log_bins=True, log_width=log_width
                    )[1]
                    binned_cl2[i, j, :] += bin_cl(
                        ells[i, j, :], cl2[i, j, :], log_bins=True, log_width=log_width
                    )[1]

        navg += 1

    # finish computing statistics once we're done
    binned_cl /= navg
    binned_cl2 = np.sqrt(binned_cl2 / navg - binned_cl**2) / np.sqrt(navg)

    # save it for later
    with h5py.File(binned_file, "w") as h5f:
        dset = h5f.create_dataset("binned_ells", data=binned_ells)
        dset = h5f.create_dataset("binned_cl", data=binned_cl)
        dset = h5f.create_dataset("binned_cl2", data=binned_cl2)

if plot_ells:
    skip_interval = 5
    xe_idx = [5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    for xidx in xe_idx:
        # initialize figure
        fig = plt.figure()
        ax = plt.gca()
        ax.axhline(y=0.0, color=ax_color, linestyle="--")

        linestyles = ["-", "--", "-.", ":"]

        for enum, i in enumerate(range(skip_interval, window_zvals.shape[1] - skip_interval, skip_interval)):
            idx0 = xidx
            idx1 = i
            z1 = window_zvals[idx0, idx1, 0]
            z2 = window_zvals[idx0, idx1, 1]
            if i == skip_interval:
                zmean = (z1 + z2) / 2.0
            label = rf"${z1:0.2f} \leq z \leq {z2:0.2f}$"
            dl = binned_ells * (binned_ells + 1) * binned_cl[idx0, idx1, :] / (2 * np.pi)
            dl2 = binned_ells * (binned_ells + 1) * binned_cl2[idx0, idx1, :] / (2 * np.pi)
            fuzzed_ells = binned_ells * (1 + (enum - 2) / 100)
            ax.errorbar(fuzzed_ells[3:], dl[3:], yerr=dl2[3:], label=label, alpha=0.5, linestyle=linestyles[enum])

        pk_fn = os.path.join(root_dir, output_dirs[0], "pk_arrays.hdf5")
        with h5py.File(pk_fn, "r") as h5f:
            zval_list = h5f["data/zval_list"][()]
            xval_list = h5f["data/xval_list"][()]

        xe = 1 - np.interp(zmean, zval_list, xval_list)
        at = AnchoredText(
            rf"$x_{{\mathrm{{HII}}}} \sim {xe:0.2f}$",
            prop={"size": sm_fontsize},
            frameon=False,
            loc="upper left",
        )
        # at.patch.set_boxstyle("round,pad=0.,rounding_size=0.2")
        ax.add_artist(at)

        # make plot pretty
        ax.set_ylim((-0.002, 0.025))
        ax.set_xscale("log")
        ax.set_xlabel(r"$\ell$", fontsize=fontsize)
        ax.set_ylabel(r"$\ell(\ell+1)C_\ell /2\pi$ [$\mu$K$^2$]", fontsize=fontsize)
        if plot_title:
            ax.set_title(rf"kSZ$^2$--galaxy cross-correlation, $x_e = {xe:0.2f}$")
        if experiment == "so" and xidx == 13:
            loc = 8
        else:
            loc = 0
        leg = ax.legend(loc=loc, prop={"size": sm_fontsize})
        ax.tick_params(axis="both", labelsize=sm_fontsize)

        plot_dir = datetime.date.today().strftime("%y%m%d")
        plot_dir = os.path.join(root_dir, "plots", plot_dir)
        if not os.path.isdir(plot_dir):
            os.makedirs(plot_dir)
        output_fn = f"cl_t21_{experiment}_{xidx}.pdf"
        out_fn = os.path.join(plot_dir, output_fn)
        print(f"saving {out_fn}...")
        fig.savefig(out_fn, bbox_inches="tight", transparent=transparent)
        plt.close(fig)

if plot_z:
    # initialize figure
    fig = plt.figure()
    ax = plt.gca()
    ax.axhline(y=0.0, color=ax_color, linestyle="--")

    ells = [500, 1000, 3000, 10000]

    for iell, ell in enumerate(ells):
        zvals = np.zeros((window_zvals.shape[0],), dtype=np.float64)
        dl_vals = np.zeros_like(zvals)
        dl2_vals = np.zeros_like(zvals)
        for i in range(window_zvals.shape[0]):
            idx0 = i
            idx1 = 9  # Delta z = 1
            z1 = window_zvals[idx0, idx1, 0]
            z2 = window_zvals[idx0, idx1, 1]
            zvals[i] = (z1 + z2) / 2.0
            dl = (binned_ells * (binned_ells + 1) * binned_cl[idx0, idx1, :]
                  / (2 * np.pi)
            )
            dl2 = (binned_ells * (binned_ells + 1) * binned_cl2[idx0, idx1, :]
                   / (2 * np.pi)
            )
            dl_vals[i] = np.interp(ell, binned_ells, dl)
            dl2_vals[i] = np.interp(ell, binned_ells, dl2)

        # plot result
        label = rf"$\ell={ell}$"
        fuzzed_zvals = zvals + (iell - 1.5) * 0.05
        ax.errorbar(fuzzed_zvals, dl_vals, yerr=dl2_vals, label=label, alpha=0.5)

    # make plot pretty
    ax.set_xlabel(r"$z$", fontsize=fontsize)
    ax.set_ylabel(r"$\ell(\ell+1)C_\ell /2\pi$ [mK$^2$]", fontsize=fontsize)
    leg = ax.legend(loc=0, prop={"size": sm_fontsize})
    if plot_title:
        ax.set_title(r"21\,cm auto power spectrum")
    ax.tick_params(axis="both", labelsize=sm_fontsize)

    # add secondary axis on top
    pk_fn = os.path.join(root_dir, output_dirs[0], "pk_arrays.hdf5")
    with h5py.File(pk_fn, "r") as h5f:
        zval_list = h5f["data/zval_list"][()]
        xval_list = h5f["data/xval_list"][()]
    def forward(x):
        return 1 - np.interp(x, zval_list, xval_list)
    ax2 = ax.twiny()
    tick_locations = [6, 7, 8, 9, 10, 11]
    ax2.set_xlim(ax.get_xlim())
    ax2.set_xticks(tick_locations)
    ax2.set_xticklabels([f"{x:0.2f}" for x in forward(tick_locations)])
    ax2.set_xlabel("$x_{\mathrm{HII}}$", fontsize=fontsize)
    ax2.tick_params(axis="x", labelsize=sm_fontsize)

    plot_dir = datetime.date.today().strftime("%y%m%d")
    plot_dir = os.path.join(root_dir, "plots", plot_dir)
    if not os.path.isdir(plot_dir):
        os.makedirs(plot_dir)
    output_fn = f"cl_t21_of_z_{experiment}.pdf"
    out_fn = os.path.join(plot_dir, output_fn)
    print(f"saving {out_fn}...")
    fig.savefig(out_fn, bbox_inches="tight", transparent=transparent)
    plt.close(fig)

if plot_actual_errors:
    # initialize figure
    fig = plt.figure()
    ax = plt.gca()
    ax.axhline(y=0.0, color=ax_color, linestyle="--")

    ells = [500, 1000, 3000]
    narrow_range = True
    if narrow_range:
        ell_ranges = [[475, 525], [950, 1050], [2850, 3150]]
        in_suffix = "_v2"
        out_suffix = "_narrow"
    else:
        ell_ranges = [[250, 750], [500, 1500], [1500, 4500]]
        in_suffix = ""
        out_suffix = ""

    # get zmid values
    window_fn = os.path.join(root_dir, "output_0001", "cl_arrays_window_hd_naive.hdf5")
    with h5py.File(window_fn, "r") as h5f:
        zmid_vals = h5f["data/z_mid"][()]
        width_vals = h5f["data/delta_z"][()]

    for iell, ell in enumerate(ells):
        # read in snr file
        snr_file = os.path.join(root_dir, f"snr_hd_naive_{ell}{in_suffix}.hdf5")
        with h5py.File(snr_file, "r") as h5f:
            snr = h5f["snr"][()]

        snr = 1.0 / snr

        # plot actual data
        zvals = zmid_vals[3::5]
        dl_vals = np.zeros_like(zvals)
        dl2_vals = np.zeros_like(zvals)
        for i, zv in enumerate(zvals):
            idx0 = np.argmin(np.abs(zv - zmid_vals))
            idx1 = 9  # Delta z = 1
            assert np.isclose(width_vals[idx1], 1.0)
            dl = (binned_ells * (binned_ells + 1) * binned_cl[idx0, idx1, :]
                  / (2 * np.pi)
            )
            dlval = 0
            elrange = np.arange(ell_ranges[iell][0], ell_ranges[iell][1])
            for el in elrange:
                dlval += np.interp(el, binned_ells, dl)
            dl_vals[i] = dlval / elrange.size
            dl2_vals[i] = dl_vals[i] / snr[idx0, idx1]

        # plot result
        label = rf"$\ell={ell}$"
        fuzzed_zvals = zvals + (iell - 1.5) * 0.05
        ax.errorbar(fuzzed_zvals, dl_vals, yerr=dl2_vals, label=label, alpha=0.5)

    # make plot pretty
    ax.set_ylim((-5e-3, 2e-2))
    ax.set_xlabel(r"$z$", fontsize=fontsize)
    ax.set_ylabel(r"$\ell(\ell+1)C_\ell /2\pi$ [$\mu$K$^2$]", fontsize=fontsize)
    leg = ax.legend(loc=0, prop={"size": sm_fontsize})
    if plot_title:
        ax.set_title(r"kSZ$^2$--galaxy cross correlation")
    ax.tick_params(axis="both", labelsize=sm_fontsize)

    # add secondary axis on top
    pk_fn = os.path.join(root_dir, output_dirs[0], "pk_arrays.hdf5")
    with h5py.File(pk_fn, "r") as h5f:
        zval_list = h5f["data/zval_list"][()]
        xval_list = h5f["data/xval_list"][()]
    def forward(x):
        return 1 - np.interp(x, zval_list, xval_list)
    ax2 = ax.twiny()
    tick_locations = [6, 7, 8, 9, 10, 11]
    ax2.set_xlim(ax.get_xlim())
    ax2.set_xticks(tick_locations)
    ax2.set_xticklabels([f"{x:0.2f}" for x in forward(tick_locations)])
    ax2.set_xlabel("$x_{\mathrm{HII}}$", fontsize=fontsize)
    ax2.tick_params(axis="x", labelsize=sm_fontsize)

    plot_dir = datetime.date.today().strftime("%y%m%d")
    plot_dir = os.path.join(root_dir, "plots", plot_dir)
    if not os.path.isdir(plot_dir):
        os.makedirs(plot_dir)
    output_fn = f"cl_t21_of_z_hd_naive_real{out_suffix}.pdf"
    out_fn = os.path.join(plot_dir, output_fn)
    print(f"saving {out_fn}...")
    fig.savefig(out_fn, bbox_inches="tight", transparent=transparent)
    plt.close(fig)
