# -*- coding: utf-8 -*-

import os
import datetime
import h5py
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import gridspec

# read in Cl spectrum
root_dir = "/jet/home/plaplant/scratch_ml/ksz/fiducial"
output_dirs = sorted([d for d in os.listdir(root_dir) if "output_00" in d])
cl_fn = "cl_arrays_window.hdf5"
cl_apod_fn = "cl_arrays_window_apodize.hdf5"

n_dir = len(output_dirs)

for idir, dirname in enumerate(output_dirs):
    full_fn = os.path.join(root_dir, dirname, cl_fn)
    full_fn_apod = os.path.join(root_dir, dirname, cl_apod_fn)

    print(f"reading {full_fn}...")
    with h5py.File(full_fn, "r") as h5f:
        if idir == 0:
            tcmb = h5f["header/Tcmb0"][()]
            tfac = tcmb * 1e6
            cl_kxg = h5f["data/cl_kxg"][()]
        else:
            cl_kxg += h5f["data/cl_kxg"][()]

    print(f"reading {full_fn_apod}...")
    with h5py.File(full_fn_apod, "r") as h5f:
        if idir == 0:
            cl_kxg_apod = h5f["data/cl_kxg"][()]
        else:
            cl_kxg_apod += h5f["data/cl_kxg"][()]

cl_kxg /= n_dir
cl_kxg[:, :, :, 1:] *= tfac**2
cl_kxg_apod /= n_dir
cl_kxg_apod[:, :, :, 1:] *= tfac**2 * np.sqrt(2)

imid = 15
iwidth = -1

# make a plot
matplotlib.rc("text", usetex=True)
matplotlib.rc("font", family="serif")

fig = plt.figure()
gs = gridspec.GridSpec(2, 1, height_ratios=[2, 1], hspace=0.0)
ax1 = plt.subplot(gs[0])
ax2 = plt.subplot(gs[1], sharex=ax1)
ax2.axhline(y=0.0, color="k", linestyle="--")

ells = cl_kxg[imid, iwidth, :, 0]
dl = ells * (ells + 1) * cl_kxg[imid, iwidth, :, 1] / (2 * np.pi)
ax1.loglog(ells, dl, label="Non-apodized", color="C0", alpha=0.7)

ells = cl_kxg_apod[imid, iwidth, :, 0]
dl_apod = ells * (ells + 1) * cl_kxg_apod[imid, iwidth, :, 1] / (2 * np.pi)
ax1.loglog(ells, dl_apod, label="Apodized", color="C1", alpha=0.7)

pct_diff = dl_apod / dl - 1
ax2.semilogx(ells, pct_diff, color="C1", alpha=0.7)

ax2.set_xlabel(r"$\ell$")
ax1.set_ylabel(r"$\ell(\ell+1)C_\ell/2\pi$ [$\mu$K$^2$]")
ax2.set_ylabel("Relative diff")
ax2.set_ylim((-1, 1))
ax1.legend(loc=0)
yticks = ax2.get_yticks()
ax2.set_yticks(yticks[:-1])

date = datetime.date.today().strftime("%y%m%d")
plot_dir = os.path.join(root_dir, "plots", date)
if not os.path.isdir(plot_dir):
    os.makedirs(plot_dir)
output = os.path.join(plot_dir, "kxg_comparison_renorm.pdf")
print(f"saving {output}...")
fig.savefig(output, bbox_inches="tight")
plt.close(fig)
