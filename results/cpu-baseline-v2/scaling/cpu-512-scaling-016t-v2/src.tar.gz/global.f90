! Grid size is selected at compile time
#ifndef NDM_VALUE
#define NDM_VALUE 1024
#endif

#ifndef NGRID_VALUE
#define NGRID_VALUE 1024
#endif

! Thread count is selected at compile time too: N_cpu sizes sight_cpu, dm_cpu and
! hoc_cpu and bounds the parallel loop in calc_ksz_t21_fields, so OMP_NUM_THREADS
! cannot change it. A thread-scaling sweep therefore needs one build per point.
#ifndef NCPU_VALUE
#define NCPU_VALUE 128
#endif


module global
  ! Global
  use cosmo_parameters
  use physical_constants


  ! Default
  implicit none


  ! Parameters


  ! Parallelization
  integer(4), parameter :: N_cpu = NCPU_VALUE

  ! Seed for the domain subdivision search in init_domain. Deliberately NOT
  ! N_cpu: at N_cpu = 2 the search returns a 2x2x2 grid in which every domain
  ! borders every other, so set_domain spins and deposition serialises. Pinning
  ! it at 128 keeps one decomposition -- and one floating-point summation order
  ! -- across every thread count, which is what makes a scaling sweep a
  ! measurement of parallelism rather than of three different algorithms. At
  ! N_cpu = 128 this reproduces the production decomposition exactly.
  integer(4), parameter :: N_dom_seed = 128


  ! IO
  integer(4),   parameter :: N_sims   = 1
  character(*), parameter :: dir      = &
       '/jet/home/plaplant/scratch_ml/ksz/fiducial/bt_bias/'
  character(*), parameter :: dir_grf  = dir//'GRF/'
  character(*), parameter :: dir_out0 = &
       '/jet/home/plaplant/scratch_ml/ksz/jackson_extended/'
  character(*), parameter :: fn_out   = 'obs_grids.hdf5'
  character(*), parameter :: fn_cl    = 'cl_arrays.hdf5'
  character(*), parameter :: fn_clw   = 'cl_arrays_window_s4_ilc.hdf5'
  character(*), parameter :: fn_pk    = 'pk_arrays.hdf5'
  character(*), parameter :: dir_filt = &
       !'/jet/home/plaplant/ksz/cmb_map/'
       '/ocean/projects/ast180004p/jsipple/ksz/extended_output/'
  character(*), parameter :: fn_filt  = 'f_ell_s4_ilc.hdf5'
  character(*), parameter :: fn_grf  = 'grf.hdf5'
  character(*), parameter :: fn_ckpt = 'checkpoints.hdf5'
  logical,      parameter :: read_all_fields = .true.


  ! Particles
  integer(4), parameter :: Ndm    = NDM_VALUE
  integer(8), parameter :: Npart  = int(Ndm,kind=8)**3
  real(8),    parameter :: ndmr   = Ndm
  real(8),    parameter :: npartr = Npart


  ! Grid
  integer(4), parameter :: N_grid      = NGRID_VALUE
  integer(8), parameter :: Ncell       = int(N_grid,kind=8)**3
  real(8),    parameter :: ngridr      = N_grid
  real(8),    parameter :: ncellr      = Ncell
  real(8),    parameter :: x_dm_gr     = ngridr/ndmr
  real(8),    parameter :: x_grid_box  = box/ngridr
  integer(4), parameter :: los_axis    = 1
  integer(4), parameter :: i0          = 0
  integer(4), parameter :: j0          = 0
  integer(4), parameter :: k0          = 0
  integer(8), parameter :: N_sightline = int(N_grid,kind=8)**2


  ! Power spectrum
  integer(4),   parameter :: Npkl_max = 10000
  character(*), parameter :: fn_pkl   = 'planck_2018_transfer_z000.dat'


  ! Node redshifts
  integer(4), parameter :: Nredshift = 26
  real(8),    parameter, dimension(Nredshift) :: zval_list = (/ &
       5.0D0, 5.5D0, 6.0D0, 6.5D0, 7.0D0, 7.5D0, 8.0D0, 8.5D0, 9.0D0,  &
       9.5D0, 10.0D0, 10.5D0, 11.0D0, 11.5D0, 12.0D0, 12.5D0, 13.0D0,  &
       13.5D0, 14.0D0, 14.5D0, 15.0D0, 16.0D0, 17.0D0, 18.0D0, 19.0D0, &
       20.0D0 /)
  real(8), parameter :: z_start = zval_list(3)
  real(8), parameter :: z_end   = 15D0  ! overkill, but safe


  ! Redshift window parameters

  integer(4), parameter :: N_mid   = 35
  real(8),    parameter, dimension(N_mid) :: z_mid = (/ &
        6D0,  6.2D0,  6.4D0,  6.6D0,  6.8D0, &
        7D0,  7.2D0,  7.4D0,  7.6D0,  7.8D0, &
        8D0,  8.2D0,  8.4D0,  8.6D0,  8.8D0, &
        9D0,  9.2D0,  9.4D0,  9.6D0,  9.8D0, &
       10D0, 10.2D0, 10.4D0, 10.6D0, 10.8D0, &
       11D0, 11.2D0, 11.4D0, 11.6D0, 11.8D0, &
       12D0, 12.2D0, 12.4D0, 12.6D0, 12.8D0  &
       /)

  integer(4), parameter :: N_width = 60
  real(8),    parameter, dimension(N_width) :: delta_z = (/ &
       0.1D0, 0.2D0, 0.3D0, 0.4D0, 0.5D0, 0.6D0, 0.7D0, 0.8D0, 0.9D0, 1.0D0, &
       1.1D0, 1.2D0, 1.3D0, 1.4D0, 1.5D0, 1.6D0, 1.7D0, 1.8D0, 1.9D0, 2.0D0, &
       2.1D0, 2.2D0, 2.3D0, 2.4D0, 2.5D0, 2.6D0, 2.7D0, 2.8D0, 2.9D0, 3.0D0, &
       3.1D0, 3.2D0, 3.3D0, 3.4D0, 3.5D0, 3.6D0, 3.7D0, 3.8D0, 3.9D0, 4.0D0, &
       4.1D0, 4.2D0, 4.3D0, 4.4D0, 4.5D0, 4.6D0, 4.7D0, 4.8D0, 4.9D0, 5.0D0, &
       5.1D0, 5.2D0, 5.3D0, 5.4D0, 5.5D0, 5.6D0, 5.7D0, 5.8D0, 5.9D0, 6.0D0  &
       /)


  ! Parameters for t21
  real(8), parameter :: z1_t21 = 7.9D0
  real(8), parameter :: z2_t21 = 8.1D0


  ! Parameters for galaxy map
  real(8),      parameter :: z1_gal = 7.9D0
  real(8),      parameter :: z2_gal = 8.1D0
  real(8),      parameter :: b_gal  = 10D0
  logical,      parameter :: use_bt = .false.  ! if .false., use b_gal above
  character(*), parameter :: fn_bt = "data/bt_bias.txt"


  ! Power spectrum calculations
  logical, parameter :: calc_pk = .true.


  ! Light cones
  logical, parameter :: save_t21_lightcone = .false.
  logical, parameter :: save_gal_lightcone = .false.


!------------------------------------------------------------------------------!


  ! Derived types


  ! DM
  type dm_type
     real(4), dimension(3) :: x,v
  end type dm_type


!------------------------------------------------------------------------------!


  ! Variables


  ! IO
  character(1000) :: dir_out

  ! Baseline instrumentation, all set from the command line by process_args.
  !   read_grf          read the initial field from fn_grf instead of drawing one
  !   save_grf          write the initial field to fn_grf
  !   checkpoint_level  0 none, 1 full routine-boundary arrays
  !   iseed_run         RNG seed actually used; 0 on input means draw from entropy
  logical    :: read_grf         = .false.
  logical    :: save_grf         = .false.
  integer(4) :: checkpoint_level = 0
  integer(4) :: iseed_run        = 0


  ! Sim variables
  integer(4) :: Ndomain,isim,Nsightpix,windx1,windx2
  real(8)    :: x_unit,vel_unit,acc_unit,time_unit,rho_unit


  ! Cosmo variables
  real(8) :: redshift,scalefactor
  real(8) :: Hubble,rho_crit
  real(8) :: Dfactor1,Dfactor2,vfactor1,vfactor2
  real(8) :: b0_zre,zmean_zre,alpha_zre,kb_zre


  ! Power spectrum
  integer(4) :: Npkl


  ! Observables
  real(8), target :: theta_max_ksz


!------------------------------------------------------------------------------!


  ! Arrays


  ! Reshift values of sightlines
  real(8), allocatable, dimension(:) :: zvals


  ! Cosmology
  real(8), allocatable, dimension(:,:) :: d_comoving,angular_distance,tau_vals


  ! Particles
  type(dm_type), allocatable, dimension(:,:,:), target  :: dm
  type(dm_type),              dimension(:),     pointer :: dm_ip
  integer(8),    allocatable, dimension(:)              :: ll_dm
  integer(8),    allocatable, dimension(:,:)            :: dm_cpu,sight_cpu
  integer(8),    allocatable, dimension(:,:,:)          :: hoc_dm,hoc_cpu


  ! Initial conditions
  real(8),              dimension(5,Npkl_max) :: pk_lin
  real(8), allocatable, dimension(:,:,:)      :: delta1,delta2
  real(8), allocatable, dimension(:,:,:,:)    :: gradphi


  ! Domain decomposition
  integer(4), allocatable, target, dimension(:,:)   :: domain
  integer(4), allocatable, target, dimension(:,:,:) :: indx_dom


  ! Fields
  real(8), allocatable,          dimension(:,:)     :: ksz_map,t21_map,gal_map
  real(8), allocatable,          dimension(:,:)     :: tau_map
  real(8), allocatable,          dimension(:,:,:)   :: density_ksz,velocity_ksz
  real(8), allocatable,          dimension(:,:,:)   :: t21_box,gal_box
  real(8), allocatable,          dimension(:,:,:)   :: zreion,rho,ion,tbg
  real(8), allocatable, target,  dimension(:,:,:)   :: densityA,densityB
  real(8), allocatable, target,  dimension(:,:,:,:) :: velocityA,velocityB
  real(8),              pointer, dimension(:,:,:)   :: density1,density2
  real(8),              pointer, dimension(:,:,:,:) :: velocity1,velocity2


  ! Cl arrays
  real(8), allocatable, dimension(:,:)     :: cl_ksz,cl_t21,cl_gal
  real(8), allocatable, dimension(:,:)     :: cl_kxt,cl_kxg,cl_ks2
  real(8), allocatable, dimension(:,:,:,:) :: cl_ksz_window,cl_t21_window
  real(8), allocatable, dimension(:,:,:,:) :: cl_gal_window,cl_kxt_window
  real(8), allocatable, dimension(:,:,:,:) :: cl_kxg_window,cl_ks2_window


  ! Pk arrays
  real(8), allocatable, dimension(:,:,:) :: pk_xx,pk_dd,pk_dx,pk_tt


  ! vrms array
  real(8), allocatable, dimension(:,:) :: vrms


  ! Ionization fraction
  real(8), dimension(Nredshift) :: xval_list,xmval_list


  ! 21cm global temperature
  real(8), allocatable, dimension(:) :: t0vals


  ! Redshift window values
  real(8), dimension(2,N_width,N_mid) :: window_zvals


  ! Wiener filter
  real(8), dimension(:,:), allocatable :: f_ell


  ! Galaxy bias
  real(8), dimension(:,:), allocatable :: bt_bias


end module global
