#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import datetime
import h5py
import numpy as np
from numba import jit
from scipy.interpolate import interp1d
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.offsetbox import AnchoredText

from bin_cl import bin_cl

dark_background = False
if dark_background:
    plt.style.use("dark_background")
    transparent = True
    ax_color = "w"
else:
    transparent = False
    ax_color = "k"

fontsize = 20
sm_fontsize = 14

# define C_ell function
@jit(nopython=True)
def compute_cl(fft_array, theta):
    nx, ny = fft_array.shape
    ak = 2 * np.pi / theta
    nmax = max(nx, ny)
    cl = np.zeros((nmax, 2), dtype=np.float64)
    for i in range(nx):
        if i < (nx // 2) + 1:
            lx = ak * i
        else:
            lx = ak * (i - nx)

        for j in range(ny):
            ly = ak * j

            ell = np.sqrt(lx**2 + ly**2)
            iell = int(np.round(ell/ak))

            if iell > 0:
                cl[iell, 0] += 1
                cl[iell, 1] += np.abs(fft_array[i, j])**2

    # finish computing statistics
    for i in range(nmax):
        if cl[i, 0] > 0:
            cl[i, 1] /= cl[i, 0]
        else:
            cl[i, 1] = 0
        cl[i, 0] = 2 * np.pi / theta * i

    return cl

# define directories
root_dir = "/ocean/projects/ast180004p/jsipple/ksz/extended_output"
output_dirs = sorted([d for d in os.listdir(root_dir) if "output_00" in d])
save_dir = "/jet/home/plaplant/scratch_ml/ksz"
binned_file = "data/cl_arrays_density_ion.hdf5"

# matplotlib options
matplotlib.rc("text", usetex=True)
matplotlib.rc("font", family="serif")
matplotlib.rc("lines", linewidth=1.1)

# read in BlueTides bias value
bt_bias_fn = "data/bt_bias.txt"
bt_bias = np.genfromtxt(bt_bias_fn)
bt_interp = interp1d(bt_bias[:, 0], bt_bias[:, 1], fill_value="extrapolate")

# read in file if already computed
try:
    with h5py.File(binned_file, "r") as h5f:
        cl_arrays = h5f["cl_arrays"][()]
        zmid = h5f["zvals"][()]
        xmid = h5f["xvals"][()]

    have_data = True
except (IOError, OSError):
    have_data = False

if not have_data:
    # get ionization values
    pk_fn = os.path.join(root_dir, output_dirs[0], "pk_arrays.hdf5")
    print(f"reading {pk_fn}...")
    with h5py.File(pk_fn, "r") as h5f:
        zvals_hist = h5f["data/zval_list"][()]
        xvals_hist = h5f["data/xval_list"][()]
    # make an interpolator
    xval_interp = interp1d(zvals_hist, xvals_hist, fill_value="extrpolate")
    # do prep work
    nredshift = 20
    zmid = np.linspace(6.0, 12.0, num=nredshift, endpoint=True)
    xmid = xval_interp(zmid)

    data_fn = os.path.join(root_dir, output_dirs[0], "obs_grids.hdf5")
    print(f"reading {data_fn}...")
    with h5py.File(data_fn, "r") as h5f:
        # get important metadata
        theta_max = h5f["header/theta_max_ksz"][()]

        # get non-overlapping windows
        zvals = h5f["data/zvals"][()]
        deltaz = 1.0

        array_dims = h5f["data/gal_box"].shape
        nmax = array_dims[1]
        cl_arrays = np.empty((nredshift, nmax, 2))
        for iz, z0 in enumerate(zmid):
            print("iz, z0: ", iz, z0)
            # get galaxy bias
            bgal = bt_interp(z0)

            # get redshift values
            z1 = z0 - deltaz / 2.0
            z2 = z0 + deltaz / 2.0
            # convert to indices
            i1 = np.argmin(np.abs(zvals - z1))
            i2 = np.argmin(np.abs(zvals - z2))

            # pull fields out
            density = h5f["data/gal_box"][i1:i2, :, :] / bgal
            ion = np.where(np.isclose(h5f["data/t21_box"][i1:i2, :, :], 0.0), 1.0, 0.0)
            rho_ion = density * ion
            rho_ion = np.average(rho_ion, axis=0)

            # compute Cl array
            rho_ion_ft = np.fft.rfft2(rho_ion)
            cl = compute_cl(rho_ion_ft, theta_max)

            # save in main array
            cl_arrays[iz, :, :] = cl

    # save it for later
    print(f"saving {binned_file}...")
    with h5py.File(binned_file, "w") as h5f:
        dset = h5f.create_dataset("cl_arrays", data=cl_arrays)
        dset = h5f.create_dataset("zvals", data=zmid)
        dset = h5f.create_dataset("xvals", data=xmid)

# make plot
fig = plt.figure()
ax = plt.gca()

for iz, zval in enumerate(zmid):
    if iz % 2 == 0:
        continue
    if iz < 5:
        linestyle = "-"
    elif iz < 10:
        linestyle = "--"
    elif iz < 15:
        linestyle = "-."
    else:
        linestyle = ":"

    imax = 512
    label = f"$x_i = {1 - xmid[iz]:0.2f}$"
    ells = cl_arrays[iz, :512, 0]
    dl = cl_arrays[iz, :512, 1] * ells * (ells + 1) / (2 * np.pi)
    if True:
        new_ell, new_dl = bin_cl(ells, dl, log_bins=True, log_width=0.1)
        ax.loglog(new_ell, new_dl, label=label, linestyle=linestyle, alpha=0.7)
    else:
        ax.loglog(ells, dl, label=label, linestyle=linestyle, alpha=0.7)

# make plot pretty
ax.set_xlim((2e2, 1e4))
ax.set_ylim((1e8, 1e11))
ax.set_xlabel(r"$\ell$")
ax.set_ylabel(r"$\ell(\ell+1)C_\ell/2\pi$")
ax.legend(loc=0)

# save it out
date = datetime.date.today().strftime("%y%m%d")
plots_dir = os.path.join(save_dir, "plots", date)
if not os.path.isdir(plots_dir):
    os.makedirs(plots_dir)
output = os.path.join(plots_dir, "cl_density_ion.pdf")
print(f"saving {output}...")
fig.savefig(output, bbox_inches="tight", transparent=transparent)
plt.close(fig)
