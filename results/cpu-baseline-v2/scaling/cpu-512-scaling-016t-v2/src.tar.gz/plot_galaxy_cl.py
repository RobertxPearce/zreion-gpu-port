# -*- coding: utf-8 -*-

import os
import datetime
import h5py
import numpy as np
from scipy.integrate import quad
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

dark_background = True
if dark_background:
    plt.style.use("dark_background")
    transparent = True
else:
    transparent = False

# define other plotting options
fontsize = 20
sm_fontsize = 14

# define files
root_dir = "/jet/home/plaplant/scratch_ml/ksz/fiducial/bt_bias"
cl_fn = "cl_arrays_window_so_ilc.hdf5"

# define survey properties
omega = 2200 / (4 * np.pi * (180.0 / np.pi)**2)  # rad

# numbers from Finkelstein
roman_num = np.asarray(
    [
        [6, 3_300_000],
        [7, 530_000],
        [8, 280_000],
        [9, 75_000],
        [10, 19_000]
    ],
    dtype=np.float64,
)

# numbers from BlueTides
roman_dndz = np.genfromtxt("data/dndz.txt")
def integrand(z):
    return np.interp(z, roman_dndz[:, 0], roman_dndz[:, 3])

iwidth = 9  # Delta z = 1

output_dirs = sorted([d for d in os.listdir(root_dir) if "output_" in d])
n_dirs = len(output_dirs)
for i, odir in enumerate(output_dirs):
    full_path = os.path.join(root_dir, odir, cl_fn)
    print(f"reading {full_path}...")
    with h5py.File(full_path, "r") as h5f:
        if i == 0:
            cl_gal = h5f["data/cl_gal"][:, iwidth, :, :]
            window_zvals = h5f["data/window_zvals"][()]
        else:
            cl_gal += h5f["data/cl_gal"][:, iwidth, :, :]

cl_gal /= n_dirs

# make a plot
matplotlib.rc("text", usetex=True)
matplotlib.rc("font", family="serif")

fig = plt.figure()
ax = plt.gca()

zmid = [7.0, 8.0, 9.0, 10.0]
mid_idx = [5, 10, 15, 20]
labels = []
lines = []
for idx, (imid, zval) in enumerate(zip(mid_idx, zmid)):
    ngals_hls = np.interp(zval, roman_num[:, 0], roman_num[:, 1])

    z1 = window_zvals[imid, iwidth, 0]
    z2 = window_zvals[imid, iwidth, 1]
    ngals_bt = quad(integrand, z1, z2)[0]
    sn_hls = omega / ngals_hls
    sn_bt = omega / ngals_bt
    cl = cl_gal[imid, :, :]
    ells = cl[:, 0]
    dl_cluster = ells * (ells + 1) * cl[:, 1] / (2 * np.pi)
    dl_sn_hls = ells * (ells + 1) * sn_hls / (2 * np.pi)
    dl_sn_bt = ells * (ells + 1) * sn_bt / (2 * np.pi)
    dl_tot = dl_cluster + dl_sn_bt

    # plot total signal
    label = f"$z_0 = {zval}$"
    labels.append(label)
    line, = ax.loglog(ells, dl_tot, color=f"C{idx}", alpha=0.7)
    lines.append(line)
    # plot clustering contribution
    line, = ax.loglog(ells, dl_cluster, linestyle="--", color=f"C{idx}", alpha=0.5)
    lines.append(line)
    # also plot shot noise contribution
    line, = ax.loglog(ells, dl_sn_bt, linestyle=":", color=f"C{idx}", alpha=0.3)
    lines.append(line)
    # line, = ax.loglog(ells, dl_sn_hls, linestyle="-.", color=f"C{idx}", alpha=0.3)
    # lines.append(line)

ax.set_xlabel(r"$\ell$", fontsize=fontsize)
ax.set_ylabel(r"$\ell(\ell+1)C_\ell/2\pi$", fontsize=fontsize)
labels.extend(["$C_\ell^{\delta_g\delta_g}$", "$C_\ell^{\mathrm{clust}}$", r"$C_\ell^\mathrm{SN}$"])
lines_to_label = lines[::3] + lines[:3]
ax.legend(lines_to_label, labels, loc=0, ncol=2, prop={"size": sm_fontsize})
ax.tick_params(axis="both", labelsize=sm_fontsize)

date = datetime.date.today().strftime("%y%m%d")
plots_dir = os.path.join(root_dir, "plots", date)
if not os.path.isdir(plots_dir):
    os.makedirs(plots_dir)
output = os.path.join(plots_dir, "galaxy_cl.pdf")
print(f"saving {output}...")
fig.savefig(output, bbox_inches="tight", transparent=transparent)
plt.close(fig)
