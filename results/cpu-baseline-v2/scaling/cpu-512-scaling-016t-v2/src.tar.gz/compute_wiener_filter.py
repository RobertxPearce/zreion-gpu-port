# -*- coding: utf-8 -*-

import h5py
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from bin_cl import bin_cl

dark_background = True

if dark_background:
    plt.style.use("dark_background")
    transparent = True
else:
    transparent = False

fontsize = 20
sm_fontsize = 14
amin2rad = np.pi / 180.0 / 60.0
asec2rad = amin2rad / 60.0

# amount to divide "naive" orphics output by
ilc_rescale_factor = 1

cl_ksz_fn = "data/cl_ksz_avg.hdf5"
cl_cmb_fn = "../cmb_map/camb_output.hdf5"
f_ell_so_fn = "../cmb_map/f_ell_so.hdf5"
f_ell_s4_fn = "../cmb_map/f_ell_s4.hdf5"
f_ell_hd_fn = "../cmb_map/f_ell_hd.hdf5"
f_ell_low_fn = "../cmb_map/f_ell_low.hdf5"
if ilc_rescale_factor != 1:
    f_ell_so_ilc_fn = f"../cmb_map/f_ell_so_ilc_scale{ilc_rescale_factor}.hdf5"
    f_ell_s4_ilc_fn = f"../cmb_map/f_ell_s4_ilc_scale{ilc_rescale_factor}.hdf5"
    f_ell_hd_ilc_fn = f"../cmb_map/f_ell_hd_ilc_scale{ilc_rescale_factor}.hdf5"
else:
    f_ell_so_ilc_fn = f"../cmb_map/f_ell_so_ilc.hdf5"
    f_ell_s4_ilc_fn = f"../cmb_map/f_ell_s4_ilc.hdf5"
    f_ell_hd_ilc_fn = f"../cmb_map/f_ell_hd_ilc.hdf5"

# noise properties -- SO-like experiment
delta_t_so = 10 * amin2rad  # 10 uK-arcmin -> uK-rad
theta_fwhm_so = 1.4 * amin2rad  # 1.4 arcmin -> rad

# S4-like experiment (best case)
delta_t_s4 = 2 * amin2rad  # 2 uK-arcmin -> uK-rad
theta_fwhm_s4 = 1.4 * amin2rad  # 1.4 arcmin -> rad

# CMB-HD
delta_t_hd = 0.6 * amin2rad  # 0.6 uK-arcmin -> uK-rad
theta_fwhm_hd = 10.0 * asec2rad  # 10 arcsec -> rad

# S4-like experiment (post-ILC)
theta_fwhm_s4_ilc = 1.4 * np.pi / 180.0 / 60.0  # 1.4 arcmin -> rad

# CMB-HD-like experiment
theta_fwhm_hd_ilc = 10.0 * np.pi / 180.0 / 60.0 / 60.0  # 10 arcsec -> rad

# read in average kSZ spectrum
with h5py.File(cl_ksz_fn, "r") as h5f:
    tcmb0 = h5f["Tcmb0"][()]
    cl_ksz = h5f["cl_ksz"][()]

# read in CMB spectrum
with h5py.File(cl_cmb_fn, "r") as h5f:
    cl_lensed = h5f["data/lensed_scalar"][()]

# generate ells and convert D_ell -> C_ell for CMB
ells_cmb = np.arange(cl_lensed.shape[0])
cl_cmb = np.zeros_like(ells_cmb, dtype=np.float64)
cl_cmb[1:] = cl_lensed[1:, 0] * 2 * np.pi / ells_cmb[1:] / (ells_cmb[1:] + 1)

# compute D_ell for post-reionization kSZ
# uses values from Park et al. (2018)
def post_ksz(ell):
    """
    Compute D_ell for post-reionization kSZ.

    Uses the values from Park et al. 2018 (ApJ 853 2). Parameterized as a power-
    law in ell with an amplitude. Returns D_ell in units of uK^2.
    """
    return 1.38 * np.power((ell / 3000), 0.21)

dl_lowz_ksz = post_ksz(ells_cmb)
cl_lowz_ksz = np.zeros_like(ells_cmb, dtype=np.float64)
cl_lowz_ksz[1:] = dl_lowz_ksz[1:] * 2 * np.pi / ells_cmb[1:] / (ells_cmb[1:] + 1)

# generate noise spectrum
n_ell_so = delta_t_so**2 * np.exp(theta_fwhm_so**2 * ells_cmb**2 / (8 * np.log(2.0)))
n_ell_s4 = delta_t_s4**2 * np.exp(theta_fwhm_s4**2 * ells_cmb**2 / (8 * np.log(2.0)))
n_ell_hd = delta_t_hd**2 * np.exp(theta_fwhm_hd**2 * ells_cmb**2 / (8 * np.log(2.0)))
data_so_ilc = np.genfromtxt("data/orphics_so.txt")
data_s4_ilc = np.genfromtxt("data/orphics_s4.txt")
data_hd_ilc = np.genfromtxt("data/orphics_hd.txt")
n_ell_so_ilc = np.interp(ells_cmb, data_so_ilc[:, 0], data_so_ilc[:, 1]) / ilc_rescale_factor
n_ell_s4_ilc = np.interp(ells_cmb, data_s4_ilc[:, 0], data_s4_ilc[:, 1]) / ilc_rescale_factor
n_ell_hd_ilc = np.interp(ells_cmb, data_hd_ilc[:, 0], data_hd_ilc[:, 1]) / ilc_rescale_factor

def filt_ksz(ell):
    interp_vals = np.interp(ell, cl_ksz[:, 0], cl_ksz[:, 1])
    return np.where(ell >= 200, interp_vals, 0.0)

# put it all together
signal_ksz = filt_ksz(ells_cmb)
cl_tot_so = signal_ksz + cl_cmb + n_ell_so + cl_lowz_ksz
cl_tot_s4 = signal_ksz + cl_cmb + n_ell_s4 + cl_lowz_ksz
cl_tot_hd = signal_ksz + cl_cmb + n_ell_hd + cl_lowz_ksz
cl_tot_so_ilc = signal_ksz + cl_cmb + n_ell_so_ilc + cl_lowz_ksz
cl_tot_s4_ilc = signal_ksz + cl_cmb + n_ell_s4_ilc + cl_lowz_ksz
cl_tot_hd_ilc = signal_ksz + cl_cmb + n_ell_hd_ilc + cl_lowz_ksz
cl_tot_so_ilc = np.where(cl_tot_so_ilc == 0, 1.0, cl_tot_so_ilc)
cl_tot_s4_ilc = np.where(cl_tot_s4_ilc == 0, 1.0, cl_tot_s4_ilc)
cl_tot_hd_ilc = np.where(cl_tot_hd_ilc == 0, 1.0, cl_tot_hd_ilc)
beam_ell_so = np.exp(-theta_fwhm_so**2 * ells_cmb**2 / (16 * np.log(2.0)))
beam_ell_s4 = np.exp(-theta_fwhm_s4**2 * ells_cmb**2 / (16 * np.log(2.0)))
beam_ell_hd = np.exp(-theta_fwhm_hd**2 * ells_cmb**2 / (16 * np.log(2.0)))
beam_ell_s4_ilc = np.exp(-theta_fwhm_s4_ilc**2 * ells_cmb**2 / (16 * np.log(2.0)))
beam_ell_hd_ilc = np.exp(-theta_fwhm_hd_ilc**2 * ells_cmb**2 / (16 * np.log(2.0)))
F_ell_so = signal_ksz / cl_tot_so
f_ell_so = F_ell_so * beam_ell_so
F_ell_s4 = signal_ksz / cl_tot_s4
f_ell_s4 = F_ell_s4 * beam_ell_s4
F_ell_hd = signal_ksz / cl_tot_hd
f_ell_hd = F_ell_hd * beam_ell_hd
F_ell_so_ilc = signal_ksz / cl_tot_so_ilc
f_ell_so_ilc = F_ell_so_ilc * beam_ell_so
F_ell_s4_ilc = signal_ksz / cl_tot_s4_ilc
f_ell_s4_ilc = F_ell_s4_ilc * beam_ell_s4_ilc
F_ell_hd_ilc = signal_ksz / cl_tot_hd_ilc
f_ell_hd_ilc = F_ell_hd_ilc * beam_ell_hd_ilc

# low-ell version
f_ell_low = np.exp(-(ells_cmb - 500)**2/ (2 * 100**2))

# average within bins
new_ell_so, f_ell_binned_so = bin_cl(ells_cmb, f_ell_so, log_bins=True, log_width=0.01)
new_ell_s4, f_ell_binned_s4 = bin_cl(ells_cmb, f_ell_s4, log_bins=True, log_width=0.01)
new_ell_hd, f_ell_binned_hd = bin_cl(ells_cmb, f_ell_hd, log_bins=True, log_width=0.01)
new_ell_so_ilc, f_ell_binned_so_ilc = bin_cl(ells_cmb, f_ell_so_ilc, log_bins=True, log_width=0.01)
new_ell_s4_ilc, f_ell_binned_s4_ilc = bin_cl(ells_cmb, f_ell_s4_ilc, log_bins=True, log_width=0.01)
new_ell_hd_ilc, f_ell_binned_hd_ilc = bin_cl(ells_cmb, f_ell_hd_ilc, log_bins=True, log_width=0.01)

# renormalize
f_ell_binned_so /= f_ell_binned_so.max()
f_ell_binned_s4 /= f_ell_binned_s4.max()
f_ell_binned_hd /= f_ell_binned_hd.max()
f_ell_low /= f_ell_low.max()
f_ell_binned_so_ilc /= f_ell_binned_so_ilc.max()
f_ell_binned_s4_ilc /= f_ell_binned_s4_ilc.max()
f_ell_binned_hd_ilc /= f_ell_binned_hd_ilc.max()

# save filters
filter_vals_so = np.zeros((len(new_ell_so), 2), dtype=np.float64)
filter_vals_so[:, 0] = new_ell_so
filter_vals_so[:, 1] = f_ell_binned_so
print(f"saving {f_ell_so_fn}...")
with h5py.File(f_ell_so_fn, "w") as h5f:
    dset = h5f.create_dataset("f_ell", data=filter_vals_so)

filter_vals_s4 = np.zeros((len(new_ell_s4), 2), dtype=np.float64)
filter_vals_s4[:, 0] = new_ell_s4
filter_vals_s4[:, 1] = f_ell_binned_s4

print(f"saving {f_ell_s4_fn}...")
with h5py.File(f_ell_s4_fn, "w") as h5f:
    dset = h5f.create_dataset("f_ell", data=filter_vals_s4)

filter_vals_hd = np.zeros((len(new_ell_hd), 2), dtype=np.float64)
filter_vals_hd[:, 0] = new_ell_hd
filter_vals_hd[:, 1] = f_ell_binned_hd

print(f"saving {f_ell_hd_fn}...")
with h5py.File(f_ell_hd_fn, "w") as h5f:
    dset = h5f.create_dataset("f_ell", data=filter_vals_hd)

filter_vals_low = np.zeros((len(f_ell_low), 2), dtype=np.float64)
filter_vals_low[:, 0] = ells_cmb
filter_vals_low[:, 1] = f_ell_low

print(f"saving {f_ell_low_fn}...")
with h5py.File(f_ell_low_fn, "w") as h5f:
    dset = h5f.create_dataset("f_ell", data=filter_vals_low)

filter_vals_so_ilc = np.zeros((len(new_ell_so_ilc), 2), dtype=np.float64)
filter_vals_so_ilc[:, 0] = new_ell_so_ilc
filter_vals_so_ilc[:, 1] = f_ell_binned_so_ilc

print(f"saving {f_ell_so_ilc_fn}...")
with h5py.File(f_ell_so_ilc_fn, "w") as h5f:
    dset = h5f.create_dataset("f_ell", data=filter_vals_so_ilc)

filter_vals_s4_ilc = np.zeros((len(new_ell_s4_ilc), 2), dtype=np.float64)
filter_vals_s4_ilc[:, 0] = new_ell_s4_ilc
filter_vals_s4_ilc[:, 1] = f_ell_binned_s4_ilc

print(f"saving {f_ell_s4_ilc_fn}...")
with h5py.File(f_ell_s4_ilc_fn, "w") as h5f:
    dset = h5f.create_dataset("f_ell", data=filter_vals_s4_ilc)

filter_vals_hd_ilc = np.zeros((len(new_ell_hd_ilc), 2), dtype=np.float64)
filter_vals_hd_ilc[:, 0] = new_ell_hd_ilc
filter_vals_hd_ilc[:, 1] = f_ell_binned_hd_ilc

print(f"saving {f_ell_hd_ilc_fn}...")
with h5py.File(f_ell_hd_ilc_fn, "w") as h5f:
    dset = h5f.create_dataset("f_ell", data=filter_vals_hd_ilc)

# plot filter
matplotlib.rc("text", usetex=True)
matplotlib.rc("font", family="serif")

linewidth = 1.5
alpha = 1.0

fig = plt.figure()
ax = plt.gca()

# ax.plot(new_ell_so, f_ell_binned_so, label="SO", linestyle="--")
# ax.plot(new_ell_s4, f_ell_binned_s4, label="CMB-S4")
ax.plot(
    new_ell_so_ilc,
    f_ell_binned_so_ilc,
    label="SO",
    linestyle="-",
    linewidth=linewidth,
    alpha=alpha,
)
ax.plot(
    new_ell_s4_ilc,
    f_ell_binned_s4_ilc,
    label="CMB-S4",
    linestyle="--",
    linewidth=linewidth,
    alpha=alpha,
)
ax.plot(
    new_ell_hd_ilc,
    f_ell_binned_hd_ilc,
    label="CMB-HD",
    linestyle=":",
    linewidth=linewidth,
    alpha=alpha,
)
# ax.plot(
#     ells_cmb,
#     f_ell_low,
#     label="Low-$\ell$",
#     linestyle="-.",
#     linewidth=linewidth,
#     alpha=alpha,
# )
ax.set_xlabel(r"$\ell$", fontsize=fontsize)
ax.set_ylabel(r"$f(\ell)$ [arbitrary normalization]", fontsize=fontsize)
ax.legend(loc=0, prop={"size": sm_fontsize})
ax.tick_params(axis="both", labelsize=sm_fontsize)

output = "plots/f_ell.pdf"
print(f"saving {output}...")
fig.savefig(output, bbox_inches="tight", transparent=transparent)
plt.close(fig)

fig = plt.figure()
ax = plt.gca()
cl_ref = signal_ksz
dl_ref = ells_cmb * (ells_cmb + 1) * cl_ref / (2 * np.pi)
ax.loglog(ells_cmb, dl_ref, label=r"kSZ,reion", linewidth=linewidth, alpha=alpha)

ax.loglog(ells_cmb, dl_lowz_ksz, label=r"kSZ,late", linewidth=linewidth, alpha=alpha)

dl_cmb = ells_cmb * (ells_cmb + 1) * cl_cmb / (2 * np.pi)
ax.loglog(ells_cmb, dl_cmb, label=r"CMB", linewidth=linewidth, alpha=alpha)

dl_noise_so = ells_cmb * (ells_cmb + 1) * n_ell_so / (2 * np.pi)
ax.loglog(
    ells_cmb,
    dl_noise_so,
    linewidth=linewidth,
    alpha=alpha,
    linestyle="--",
    color="C7",
)

dl_noise_s4 = ells_cmb * (ells_cmb + 1) * n_ell_s4 / (2 * np.pi)
ax.loglog(
    ells_cmb,
    dl_noise_s4,
    linewidth=linewidth,
    alpha=alpha,
    linestyle="-.",
    color="C7",
)

dl_noise_hd = ells_cmb * (ells_cmb + 1) * n_ell_hd / (2 * np.pi)
ax.loglog(
    ells_cmb,
    dl_noise_hd,
    linewidth=linewidth,
    alpha=alpha,
    linestyle=":",
    color="C7",
)

dl_noise_so_ilc = ells_cmb * (ells_cmb + 1) * n_ell_so_ilc / (2 * np.pi)
ax.loglog(
    ells_cmb,
    dl_noise_so_ilc,
    label="SO",
    linewidth=linewidth,
    alpha=alpha,
    linestyle="--",
    color="k",
)

dl_noise_s4_ilc = ells_cmb * (ells_cmb + 1) * n_ell_s4_ilc / (2 * np.pi)
ax.loglog(
    ells_cmb,
    dl_noise_s4_ilc,
    label="CMB-S4",
    linewidth=linewidth,
    alpha=alpha,
    linestyle="-.",
    color="k",
)

dl_noise_hd_ilc = ells_cmb * (ells_cmb + 1) * n_ell_hd_ilc / (2 * np.pi)
ax.loglog(
    ells_cmb,
    dl_noise_hd_ilc,
    label="CMB-HD",
    linewidth=linewidth,
    alpha=alpha,
    linestyle=":",
    color="k",
)

ax.set_xlabel(r"$\ell$", fontsize=fontsize)
ax.set_ylabel(r"$\ell(\ell+1)C_\ell/2\pi$ [$\mu$K$^2$]", fontsize=fontsize)
ax.legend(loc=4, prop={"size": sm_fontsize}, ncol=2)
ax.tick_params(axis="both", labelsize=sm_fontsize)
ax.set_xlim((200, 1e4))
ax.set_ylim((1e-3, 1e4))

output = "plots/cl_comparison_fell.pdf"
print(f"saving {output}...")
fig.savefig(output, bbox_inches="tight", transparent=transparent)
plt.close(fig)


fig = plt.figure()
ax = plt.gca()

f_ell_resampled_so = np.interp(ells_cmb, new_ell_so, f_ell_binned_so)
f_ell_resampled_s4 = np.interp(ells_cmb, new_ell_s4, f_ell_binned_s4)

dl_ksz_so = dl_ref * f_ell_resampled_so**2
dl_ksz_s4 = dl_ref * f_ell_resampled_s4**2
l1, = ax.loglog(ells_cmb, dl_ksz_so, color="C0", linestyle="-")
l2, = ax.loglog(ells_cmb, dl_ksz_s4, color="C1", linestyle="-")

dl_cmb_so = dl_cmb * f_ell_resampled_so**2
dl_cmb_s4 = dl_cmb * f_ell_resampled_s4**2
l3, = ax.loglog(ells_cmb, dl_cmb_so, color="C0", linestyle="--")
l4, = ax.loglog(ells_cmb, dl_cmb_s4, color="C1", linestyle="--")

dl_noise_so *= f_ell_resampled_so**2
dl_noise_s4 *= f_ell_resampled_s4**2
l5, = ax.loglog(ells_cmb, dl_noise_so, color="C0", linestyle=":")
l6, = ax.loglog(ells_cmb, dl_noise_s4, color="C1", linestyle=":")

ax.set_xlabel(r"$\ell$")
ax.set_ylabel(r"$f(\ell)^2\times \ell(\ell+1)C_\ell/2\pi$ [$\mu$K$^2$]")
ax.set_xlim((2e2, 1.3e4))
labels = [
    "kSZ",
    "CMB",
    "Noise",
    "SO",
    "S4",
]
lines = [
    l1, l3, l5, l1, l2
]
ax.legend(lines, labels, loc=0, ncol=2)

output = "plots/cl_comparison_fell_filtered.pdf"
print(f"saving {output}...")
fig.savefig(output, bbox_inches="tight", transparent=transparent)
plt.close(fig)


fig = plt.figure()
ax = plt.gca()

f_ell_resampled_so_ilc = np.interp(ells_cmb, new_ell_so_ilc, f_ell_binned_so_ilc)
f_ell_resampled_s4_ilc = np.interp(ells_cmb, new_ell_s4_ilc, f_ell_binned_s4_ilc)

cl_tot_so = cl_ref + cl_lowz_ksz + cl_cmb + n_ell_so
cl_filt_so = cl_tot_so * f_ell_resampled_so**2
cl_tot_s4 = cl_ref + cl_lowz_ksz + cl_cmb + n_ell_s4
cl_filt_s4 = cl_tot_s4 * f_ell_resampled_s4**2

cl_tot_so_ilc = cl_ref + cl_lowz_ksz + cl_cmb + n_ell_so_ilc
cl_filt_so_ilc = cl_tot_so_ilc * f_ell_resampled_so_ilc**2
cl_tot_s4_ilc = cl_ref + cl_lowz_ksz + cl_cmb + n_ell_s4_ilc
cl_filt_s4_ilc = cl_tot_s4_ilc * f_ell_resampled_s4_ilc**2

dl_filt_so = ells_cmb * (ells_cmb + 1) * cl_filt_so / (2 * np.pi)
dl_filt_s4 = ells_cmb * (ells_cmb + 1) * cl_filt_s4 / (2 * np.pi)
dl_filt_so_ilc = ells_cmb * (ells_cmb + 1) * cl_filt_so_ilc / (2 * np.pi)
dl_filt_s4_ilc = ells_cmb * (ells_cmb + 1) * cl_filt_s4_ilc / (2 * np.pi)
l1, = ax.loglog(ells_cmb, dl_filt_so, color="C0", linestyle="-")
l2, = ax.loglog(ells_cmb, dl_filt_s4, color="C1", linestyle="-")
l3, = ax.loglog(ells_cmb, dl_filt_so_ilc, color="C0", linestyle="--")
l4, = ax.loglog(ells_cmb, dl_filt_s4_ilc, color="C1", linestyle="--")

ax.set_xlabel(r"$\ell$")
ax.set_ylabel(r"$f(\ell)^2\times \ell(\ell+1)C_\ell/2\pi$ [$\mu$K$^2$]")
ax.set_xlim((2e2, 1.3e4))
lines = [l1, l2, l1, l3]
labels = [
    "SO",
    "S4",
    r'Na\"\i ve',
    "ILC",
]
ax.legend(lines, labels, loc=0, ncol=2)

output = "plots/cl_tot_ilc.pdf"
print(f"saving {output}...")
fig.savefig(output, bbox_inches="tight", transparent=transparent)
plt.close(fig)


fig = plt.figure()
ax = plt.gca()

dl_ksz_so_ilc = dl_ref * f_ell_resampled_so_ilc**2
dl_ksz_s4_ilc = dl_ref * f_ell_resampled_s4_ilc**2
l1, = ax.loglog(ells_cmb, dl_ksz_so_ilc, color="C0", linestyle="-")
l2, = ax.loglog(ells_cmb, dl_ksz_s4_ilc, color="C1", linestyle="-")

dl_lowz_ksz_so_ilc = dl_lowz_ksz * f_ell_resampled_so_ilc**2
dl_lowz_ksz_s4_ilc = dl_lowz_ksz * f_ell_resampled_s4_ilc**2
l3, = ax.loglog(ells_cmb, dl_lowz_ksz_so_ilc, color="C0", linestyle="--")
l4, = ax.loglog(ells_cmb, dl_lowz_ksz_s4_ilc, color="C1", linestyle="--")

dl_cmb_so_ilc = dl_cmb * f_ell_resampled_so_ilc**2
dl_cmb_s4_ilc = dl_cmb * f_ell_resampled_s4_ilc**2
l5, = ax.loglog(ells_cmb, dl_cmb_so, color="C0", linestyle=":")
l6, = ax.loglog(ells_cmb, dl_cmb_s4, color="C1", linestyle=":")

dl_noise_so_ilc *= f_ell_resampled_so_ilc**2
dl_noise_s4_ilc *= f_ell_resampled_s4_ilc**2
l7, = ax.loglog(ells_cmb, dl_noise_so, color="C0", linestyle="-.")
l8, = ax.loglog(ells_cmb, dl_noise_s4, color="C1", linestyle="-.")

ax.set_xlabel(r"$\ell$")
ax.set_ylabel(r"$f(\ell)^2\times \ell(\ell+1)C_\ell/2\pi$ [$\mu$K$^2$]")
ax.set_xlim((2e2, 1.3e4))
labels = [
    "kSZ",
    "SO",
    r"low-$z$ kSZ",
    "S4",
    "CMB",
    "Noise",
]
lines = [
    l1, l1, l3, l2, l5, l7
]
ax.legend(lines, labels, loc=0, ncol=4)

output = "plots/cl_comparison_fell_filtered_ilc.pdf"
print(f"saving {output}...")
fig.savefig(output, bbox_inches="tight", transparent=transparent)
plt.close(fig)
