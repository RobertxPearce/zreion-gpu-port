module general_tools
  ! Intel
  use IFPORT
  use OMP_LIB


  ! Default
  implicit none
  public
  save


contains


  pure function sinc(x)
    ! Function arguments
    real(8), intent(in) :: x
    real(8)             :: sinc

    if (abs(x) > 1d-6) then
       sinc = sin(x)/x
    else
       sinc = 1 - x**2/6
    endif

    return
  end function sinc


  pure function tophat(x)
    ! Function arguments
    real(8), intent(in) :: x
    real(8)             :: tophat

    if (abs(x) > 1d-6) then
       tophat = 3*(sin(x)-cos(x)*x)/x**3
    else
       tophat = 1 - x**2/10
    endif

    return
  end function tophat


!------------------------------------------------------------------------------!


  pure function interpolate(x,f,a,b,flag)
    ! Default
    implicit none

    ! Function arguments
    integer(4),   intent(in) :: a,b
    real(8),      intent(in) :: x,f(:,:)
    character(3), intent(in) :: flag
    real(8)                  :: interpolate


    ! Local parameters
    real(8), parameter :: dxmin = epsilon(real(0.))


    ! Local variables
    integer(4) :: i,n,i1,i2
    real(8)    :: x1,x2,y1,y2,dx


    ! Get size of array
    n = size(f,dim=2)


    ! Function must be monotonic for binary search
    if (f(a,1) < f(a,n)) then
       i1 = 1
       i2 = n
       do while (i2-i1 > 1)
          i = (i1+i2)/2
          if (x > f(a,i)) then
             i1 = i
          else
             i2 = i
          endif
       enddo
    else
       i1 = 1
       i2 = n
       do while (i2-i1 > 1)
          i = (i1+i2)/2
          if (x < f(a,i)) then
             i1 = i
          else
             i2 = i
          endif
       enddo
    endif


    ! Interpolate in linear or logarithmic space
    if (flag == 'lin') then
       x1 = f(a,i1)
       y1 = f(b,i1)
       x2 = f(a,i2)
       y2 = f(b,i2)
       dx = x2 - x1

       if (abs(dx) < dxmin) then
          interpolate = (y1+y2)/2
       else
          interpolate = y1+(y2-y1)*((x-x1)/(x2-x1))
       endif
    else if (flag == 'log') then
       x1 = Dlog(f(a,i1))
       y1 = Dlog(f(b,i1))
       x2 = Dlog(f(a,i2))
       y2 = Dlog(f(b,i2))
       dx = x2 - x1

       if (abs(dx) < dxmin) then
          interpolate = exp((y1+y2)/2)
       else
          interpolate = exp(y1+(y2-y1)*((Dlog(x)-x1)/(x2-x1)))
       endif
    else
       interpolate = huge(0.)
    endif


    return
  end function interpolate


!------------------------------------------------------------------------------!


  subroutine bin_cl(ell,cl,log_bins,bin_width,binned_cl)
    ! This subroutine will rebin a power spectrum given ell and Cl.
    !
    ! This routine will determine a spacing in ell based on the arguments
    ! log_bins and bin_width. Given this spacing, the bin edges will be
    ! calculated, and the resulting average within a bin will be computed. Bin
    ! membership is calculated such that ell_i <= ell < ell_i+1, so that power
    ! is not double counted and overall power should be conserved.
    !
    ! Subroutine arguments:
    !   ell: real(8), length(n)
    !     input ell values
    !   cl: real(8), length(n)
    !     input Cl values. note that ell and Cl should be the same size, but
    !     no explicit checking is done.
    !   log_bins: boolean
    !     whether to use bins evenly spaced in log (true) or linear (false)
    !   binned_cl : real(8), length(2,nout)
    !     output ell and spectrum values in columns 1 and 2, respectively

    ! Default
    implicit none


    ! Subroutine arguments
    real(8), intent(in) :: ell(:),cl(:),bin_width
    logical, intent(in) :: log_bins
    real(8), allocatable, intent(out) :: binned_cl(:,:)


    ! Local variables
    integer(4) :: i,nbins,navg
    real(8) :: lmin,lmax
    real(8), dimension(:), allocatable :: bin_edges,arr


    ! Set things depending on log or linear bins
    lmin = minval(ell)
    lmax = maxval(ell)
    if (log_bins) then
       if (lmin <= 0.0) then
          lmin = 1.0
       endif
       lmin  = log(lmin)
       lmax  = log(lmax)
       nbins = int((lmax-lmin)/bin_width + 1)
    else
       nbins = int((lmax-lmin)/bin_width + 1)
    endif

    allocate(binned_cl(2,nbins))
    allocate(bin_edges(nbins+1))
    allocate(arr(size(ell)))

    if (log_bins) then
       do i=1,nbins
          binned_cl(1,i) = exp((i-0.5)*bin_width + lmin)
          binned_cl(2,i) = 0
          bin_edges(i)   = exp((i-1  )*bin_width + lmin)
       enddo
       bin_edges(nbins+1) = exp(nbins*bin_width + lmin)
    else
       do i=1,nbins
          binned_cl(1,i) = (i-0.5)*bin_width + lmin
          binned_cl(2,i) = 0
          bin_edges(i)   = (i-1  )*bin_width + lmin
       enddo
       bin_edges(nbins+1) = nbins*bin_width + lmin
    endif

    ! Bin up input spectrum
    do i=1,nbins
       lmin = bin_edges(i)
       lmax = bin_edges(i+1)

       navg = count(ell >= lmin .and. ell < lmax)
       if (navg > 0) then
          where(ell >= lmin .and. ell < lmax)
             arr = cl
          elsewhere
             arr = 0.0
          endwhere
          binned_cl(2,i) = sum(arr)/navg
       else
          binned_cl(2,i) = 0
       endif
    enddo

    return
  end subroutine bin_cl


end module general_tools
