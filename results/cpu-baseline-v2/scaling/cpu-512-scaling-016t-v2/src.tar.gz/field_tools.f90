module field_tools
  ! Intel
  use IFPORT
  use OMP_LIB


  ! Global
  use global


  ! Tools
  use fft_tools
  use cosmo_tools
  use domain_tools
  use general_tools
  use checkpoint_tools


  ! Default
  implicit none


  ! Module parameters
  ! Particle deposition scheme
  integer(4), parameter :: dep_scheme = 2  ! TSC


contains


  subroutine init_dm
    ! Default
    implicit none


    ! Local variables
    integer(4) :: icpu,i,j,k
    integer(8) :: npt


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Allocate
    allocate(dm(Ndm,Ndm,Ndm))
    allocate(dm_cpu(2,N_cpu))
    allocate(ll_dm(Npart))
    allocate(hoc_dm( N_grid,N_grid,N_grid))
    allocate(hoc_cpu(N_grid,N_grid,N_cpu ))


    ! Initialize
    npt = Npart/N_cpu + min(1,mod(Npart,N_cpu))
    !$omp parallel        &
    !$omp default(shared) &
    !$omp private(i,j,k)
    !$omp do
    do k=1,Ndm
       do j=1,Ndm
          do i=1,Ndm
             dm(i,j,k)%x = 0
             dm(i,j,k)%v = 0
          enddo
       enddo
    enddo
    !$omp end do
    !$omp do
    do icpu=1,N_cpu
       dm_cpu(1,icpu) = 1 + (icpu-1)*npt
       dm_cpu(2,icpu) = min(icpu*npt,Npart)
    enddo
    !$omp end do
    !$omp do
    do icpu=1,N_cpu
       ll_dm(dm_cpu(1,icpu):dm_cpu(2,icpu)) = 0
    enddo
    !$omp end do
    !$omp do
    do k=1,N_grid
       hoc_dm(:,:,k) = 0
    enddo
    !$omp end do
    !$omp do
    do k=1,N_cpu
       hoc_cpu(:,:,k) = 0
    enddo
    !$omp end do
    !$omp end parallel

    ! Associate pointer
    dm_ip(1:Npart) => dm

    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called init dm'
    return
  end subroutine init_dm


!------------------------------------------------------------------------------!


  subroutine init_fields
    ! Default
    implicit none


    ! Local variables
    integer(4) :: i,j,k
    integer(8) :: Nscpu


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Allocate
    allocate(delta1(Ndm+2,Ndm,Ndm))
    allocate(delta2(Ndm+2,Ndm,Ndm))
    allocate(gradphi(Ndm+2,Ndm,Ndm,3))
    allocate(densityA(N_grid+2,N_grid,N_grid))
    allocate(densityB(N_grid+2,N_grid,N_grid))
    allocate(velocityA(3,N_grid,N_grid,N_grid))
    allocate(velocityB(3,N_grid,N_grid,N_grid))
    allocate(zreion(N_grid+2,N_grid,N_grid))
    allocate(density_ksz(Nsightpix,N_grid,N_grid))
    allocate(velocity_ksz(Nsightpix,N_grid,N_grid))
    allocate(ksz_map(N_grid,N_grid))
    allocate(t21_map(N_grid,N_grid))
    allocate(gal_map(N_grid,N_grid))
    allocate(tau_map(N_grid,N_grid))
    allocate(sight_cpu(2,N_cpu))
    allocate(zvals(Nsightpix))
    allocate(t0vals(Nsightpix))
    allocate(vrms(3,Nredshift))
    if (calc_pk) then
       allocate(rho(N_grid+2,N_grid,N_grid))
       allocate(ion(N_grid+2,N_grid,N_grid))
       allocate(tbg(N_grid+2,N_grid,N_grid))
       allocate(pk_dd(3,N_grid,Nredshift))
       allocate(pk_xx(3,N_grid,Nredshift))
       allocate(pk_dx(3,N_grid,Nredshift))
       allocate(pk_tt(3,N_grid,Nredshift))
    endif
    if (save_t21_lightcone) then
       allocate(t21_box(N_grid,N_grid,Nsightpix))
    endif
    if (save_gal_lightcone) then
       allocate(gal_box(N_grid,N_grid,Nsightpix))
    endif


    ! Initialize in parallel
    !$omp parallel        &
    !$omp default(shared) &
    !$omp private(i,j,k)
    !$omp do
    do k=1,Ndm
       delta1(:,:,k) = 0
    enddo
    !$omp end do
    !$omp do
    do k=1,Ndm
       delta2(:,:,k) = 0
    enddo
    !$omp end do
    !$omp do
    do k=1,Ndm
       gradphi(:,:,k,1) = 0
    enddo
    !$omp end do
    !$omp do
    do k=1,Ndm
       gradphi(:,:,k,2) = 0
    enddo
    !$omp end do
    !$omp do
    do k=1,Ndm
       gradphi(:,:,k,3) = 0
    enddo
    !$omp end do
    !$omp do
    do k=1,N_grid
       densityA(:,:,k) = 0
    enddo
    !$omp end do
    !$omp do
    do k=1,N_grid
       densityB(:,:,k) = 0
    enddo
    !$omp end do
    !$omp do
    do k=1,N_grid
       velocityA(:,:,:,k) = 0
    enddo
    !$omp end do
    !$omp do
    do k=1,N_grid
       velocityB(:,:,:,k) = 0
    enddo
    !$omp end do
    !$omp do
    do k=1,N_grid
       zreion(:,:,k) = 0
    enddo
    !$omp end do
    if (calc_pk) then
       !$omp do
       do k=1,N_grid
          rho(:,:,k) = 0
       enddo
       !$omp end do
       !$omp do
       do k=1,N_grid
          ion(:,:,k) = 0
       enddo
       !$omp end do
       !$omp do
       do k=1,N_grid
          tbg(:,:,k) = 0
       enddo
       !$omp end do
       pk_dd = 0
       pk_xx = 0
       pk_dx = 0
       pk_tt = 0
    endif
    if (save_t21_lightcone) then
       !$omp do
       do k=1,Nsightpix
          t21_box(:,:,k) = 0
       enddo
       !$omp end do
    endif
    if (save_gal_lightcone) then
       !$omp do
       do k=1,Nsightpix
          gal_box(:,:,k) = 0
       enddo
       !$omp end do
    endif
    !$omp end parallel

    ! Initialize computing array
    Nscpu = 1 + N_sightline/N_cpu
    do k=1,N_cpu
       sight_cpu(1,k) = 1 + int(k-1,kind=8)*int(Nscpu,kind=8)
       sight_cpu(2,k) = min(int(k,kind=8)*int(Nscpu,kind=8),N_sightline)
    enddo

    ! Plain initialization for small arrays
    ksz_map = 0
    t21_map = 0
    gal_map = 0
    tau_map = 0
    zvals   = 0
    t0vals  = 0
    vrms    = 0


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called init fields'
    return
  end subroutine init_fields


!------------------------------------------------------------------------------!


  subroutine init_small_fields
    ! Default
    implicit none


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Allocate
    allocate(cl_ksz(3,N_grid))
    allocate(cl_t21(3,N_grid))
    allocate(cl_gal(3,N_grid))
    allocate(cl_kxt(3,N_grid))
    allocate(cl_kxg(3,N_grid))
    allocate(cl_ks2(3,N_grid))
    allocate(ksz_map(N_grid,N_grid))
    allocate(t21_map(N_grid,N_grid))
    allocate(gal_map(N_grid,N_grid))
    allocate(tau_map(N_grid,N_grid))

    ! Initialize
    cl_ksz  = 0
    cl_t21  = 0
    cl_gal  = 0
    cl_kxt  = 0
    cl_kxg  = 0
    cl_ks2  = 0
    ksz_map = 0
    t21_map = 0
    gal_map = 0
    tau_map = 0


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called init small fields'
    return
  end subroutine init_small_fields


!------------------------------------------------------------------------------!


  subroutine calc_delta_field
    ! Default
    implicit none


    ! Local parameters
    real(8), parameter :: kmin = 2*pi/ndmr


    ! Local variables
    integer(4) :: i,j,k
    real(8)    :: kr,kx,ky,kz
    real(8)    :: pk,x


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Compute FFT of delta1. Unconditional: the saved GRF is a real-space field
    ! whether it was drawn here or read from disk.
    call fft_3d('f',Ndm,Ndm,Ndm,delta1)


    ! Interpolate Delta^2 from pk_lin
    !$omp parallel do               &
    !$omp default(shared)           &
    !$omp private(i,j,k)            &
    !$omp private(kr,kx,ky,kz,pk,x)
    do k=1,Ndm
       if (k <= Ndm/2+1) then
          kz = 2*pi/ndmr*(k-1)
       else
          kz = 2*pi/ndmr*(k-1-Ndm)
       endif

       do j=1,Ndm
          if (j <= Ndm/2+1) then
             ky = 2*pi/ndmr*(j-1)
          else
             ky = 2*pi/ndmr*(j-1-Ndm)
          endif

          do i=1,Ndm+2,2
             kx = 2*pi/ndmr*((i-1)/2)
             kr = sqrt(kx**2 + ky**2 + kz**2)

             if (kr > 0) then
                x  = kr*ndmr/box
                pk = interpolate(x,pk_lin(:,1:Npkl),1,5,'log')*(2*pi**2/kr**3)
                delta1(i:i+1,j,k) = sqrt(pk)*delta1(i:i+1,j,k)
             else
                delta1(i:i+1,j,k) = 0
             endif
          enddo
       enddo
    enddo
    !$omp end parallel do


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called calc delta field'
    return
  end subroutine calc_delta_field


!------------------------------------------------------------------------------!


  subroutine calc_gradphi_1
    ! Default
    implicit none


    ! Local variables
    integer(4) :: i,j,k
    real(8)    :: kx,ky,kz,ksq
    real(8)    :: wx,wy,wz


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Calculate Grad phi_1 fields
    !$omp parallel do           &
    !$omp default(shared)       &
    !$omp private(i,j,k)        &
    !$omp private(kx,ky,kz,ksq) &
    !$omp private(wx,wy,wz)
    do k=1,Ndm
       if (k <= Ndm/2+1) then
          kz = 2*pi/ndmr*(k-1)
       else
          kz = 2*pi/ndmr*(k-1-Ndm)
       endif

       do j=1,Ndm
          if (j <= Ndm/2+1) then
             ky = 2*pi/ndmr*(j-1)
          else
             ky = 2*pi/ndmr*(j-1-Ndm)
          endif

          do i=1,Ndm+2,2
             kx  = 2*pi/ndmr*((i-1)/2)
             ksq = kx**2 + ky**2 + kz**2

             ! Force kernels
             if (ksq > 0) then
                wx = -kx/ksq
                wy = -ky/ksq
                wz = -kz/ksq
             else
                wx = 0
                wy = 0
                wz = 0
             endif

             ! Complex multiply
             gradphi(i  ,j,k,1) = -wx*delta1(i+1,j,k)
             gradphi(i+1,j,k,1) =  wx*delta1(i  ,j,k)
             gradphi(i  ,j,k,2) = -wy*delta1(i+1,j,k)
             gradphi(i+1,j,k,2) =  wy*delta1(i  ,j,k)
             gradphi(i  ,j,k,3) = -wz*delta1(i+1,j,k)
             gradphi(i+1,j,k,3) =  wz*delta1(i  ,j,k)
          enddo
       enddo
    enddo
    !$omp end parallel do


    ! Inverse FFT Grad phi_1 fields
    call fft_3d('b',Ndm,Ndm,Ndm,gradphi(:,:,:,1))
    call fft_3d('b',Ndm,Ndm,Ndm,gradphi(:,:,:,2))
    call fft_3d('b',Ndm,Ndm,Ndm,gradphi(:,:,:,3))


    ! Save in particle array
    !$omp parallel do     &
    !$omp default(shared) &
    !$omp private(i,j,k)
    do k=1,Ndm
       do j=1,Ndm
          do i=1,Ndm
             dm(i,j,k)%x(1) = -Dfactor1*gradphi(i,j,k,1)
             dm(i,j,k)%x(2) = -Dfactor1*gradphi(i,j,k,2)
             dm(i,j,k)%x(3) = -Dfactor1*gradphi(i,j,k,3)
             dm(i,j,k)%v(1) = -vfactor1*gradphi(i,j,k,1)
             dm(i,j,k)%v(2) = -vfactor1*gradphi(i,j,k,2)
             dm(i,j,k)%v(3) = -vfactor1*gradphi(i,j,k,3)
          enddo
       enddo
    enddo
    !$omp end parallel do


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called calc gradphi 1'
    return
  end subroutine calc_gradphi_1


!------------------------------------------------------------------------------!


  subroutine calc_gradphi_2
    ! Default
    implicit none


    ! Local variables
    integer(4) :: i,j,k
    real(8)    :: kx,ky,kz,ksq
    real(8)    :: wx,wy,wz


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()



    ! Calculate Grad^2 phi_ii fields
    !$omp parallel do           &
    !$omp default(shared)       &
    !$omp private(i,j,k)        &
    !$omp private(kx,ky,kz,ksq) &
    !$omp private(wx,wy,wz)
    do k=1,Ndm
       if (k <= Ndm/2+1) then
          kz = 2*pi/ndmr*(k-1)
       else
          kz = 2*pi/ndmr*(k-1-Ndm)
       endif

       do j=1,Ndm
          if (j <= Ndm/2+1) then
             ky = 2*pi/ndmr*(j-1)
          else
             ky = 2*pi/ndmr*(j-1-Ndm)
          endif

          do i=1,Ndm+2,2
             kx  = 2*pi/ndmr*((i-1)/2)
             ksq = kx**2 + ky**2 + kz**2

             ! Calc kernels
             if (ksq > 0) then
                wx = -kx**2/ksq
                wy = -ky**2/ksq
                wz = -kz**2/ksq
             else
                wx = 0
                wy = 0
                wz = 0
             endif

             ! Complex multiply
             gradphi(i:i+1,j,k,1) = wx*delta1(i:i+1,j,k)
             gradphi(i:i+1,j,k,2) = wy*delta1(i:i+1,j,k)
             gradphi(i:i+1,j,k,3) = wz*delta1(i:i+1,j,k)
          enddo
       enddo
    enddo
    !$omp end parallel do


    ! Inverse FFT Grad^2 phi_ii fields
    call fft_3d('b',Ndm,Ndm,Ndm,gradphi(:,:,:,1))
    call fft_3d('b',Ndm,Ndm,Ndm,gradphi(:,:,:,2))
    call fft_3d('b',Ndm,Ndm,Ndm,gradphi(:,:,:,3))


    ! Calculate delta2
    !$omp parallel do     &
    !$omp default(shared) &
    !$omp private(i,j,k)
    do k=1,Ndm
       do j=1,Ndm
          do i=1,Ndm
             delta2(i,j,k) = gradphi(i,j,k,1)*gradphi(i,j,k,2) &
                           + gradphi(i,j,k,2)*gradphi(i,j,k,3) &
                           + gradphi(i,j,k,3)*gradphi(i,j,k,1)
          enddo
       enddo
    enddo
    !$omp end parallel do


    ! Calculate Grad^2 phi_ij fields
    !$omp parallel do           &
    !$omp default(shared)       &
    !$omp private(i,j,k)        &
    !$omp private(kx,ky,kz,ksq) &
    !$omp private(wx,wy,wz)
    do k=1,Ndm
       if (k <= Ndm/2+1) then
          kz = 2*pi/ndmr*(k-1)
       else
          kz = 2*pi/ndmr*(k-1-Ndm)
       endif

       do j=1,Ndm
          if (j  <= Ndm/2+1) then
             ky = 2*pi/ndmr*(j-1)
          else
             ky = 2*pi/ndmr*(j-1-Ndm)
          endif

          do i=1,Ndm+2,2
             kx  = 2*pi/ndmr*((i-1)/2)
             ksq = kx**2 + ky**2 + kz**2

             ! Calc kernels
             if (ksq > 0) then
                wx = -kx*ky/ksq
                wy = -ky*kz/ksq
                wz = -kz*kx/ksq
             else
                wx = 0
                wy = 0
                wz = 0
             endif

             ! Complex multiply
             gradphi(i:i+1,j,k,1) = wx*delta1(i:i+1,j,k)
             gradphi(i:i+1,j,k,2) = wy*delta1(i:i+1,j,k)
             gradphi(i:i+1,j,k,3) = wz*delta1(i:i+1,j,k)
          enddo
       enddo
    enddo
    !$omp end parallel do


    ! Inverse FFT Grad^2 phi_ij fields
    call fft_3d('b',Ndm,Ndm,Ndm,gradphi(:,:,:,1))
    call fft_3d('b',Ndm,Ndm,Ndm,gradphi(:,:,:,2))
    call fft_3d('b',Ndm,Ndm,Ndm,gradphi(:,:,:,3))


    ! Add to delta2
    !$omp parallel do     &
    !$omp default(shared) &
    !$omp private(i,j,k)
    do k=1,Ndm
       do j=1,Ndm
          do i=1,Ndm
             delta2(i,j,k) = delta2(i,j,k) &
                           - gradphi(i,j,k,1)**2 &
                           - gradphi(i,j,k,2)**2 &
                           - gradphi(i,j,k,3)**2
          enddo
       enddo
    enddo
    !$omp end parallel do


    ! Forward FFT delta2 field
    call fft_3d('f',Ndm,Ndm,Ndm,delta2)


    ! Calculate Grad phi_2
    !$omp parallel do           &
    !$omp default(shared)       &
    !$omp private(i,j,k)        &
    !$omp private(kx,ky,kz,ksq) &
    !$omp private(wx,wy,wz)
    do k=1,Ndm
       if (k <= Ndm/2+1) then
          kz = 2*pi/ndmr*(k-1)
       else
          kz = 2*pi/ndmr*(k-1-Ndm)
       endif

       do j=1,Ndm
          if (j <= Ndm/2+1) then
             ky = 2*pi/ndmr*(j-1)
          else
             ky = 2*pi/ndmr*(j-1-Ndm)
          endif

          do i=1,Ndm+2,2
             kx  = 2*pi/ndmr*((i-1)/2)
             ksq = kx**2 + ky**2 + kz**2

             ! Kernels
             if (ksq > 0) then
                wx = -kx/ksq
                wy = -ky/ksq
                wz = -kz/ksq
             else
                wx = 0
                wy = 0
                wz = 0
             endif

             ! Complex multiply
             gradphi(i  ,j,k,1) = -wx*delta2(i+1,j,k)
             gradphi(i+1,j,k,1) =  wx*delta2(i  ,j,k)
             gradphi(i  ,j,k,2) = -wy*delta2(i+1,j,k)
             gradphi(i+1,j,k,2) =  wy*delta2(i  ,j,k)
             gradphi(i  ,j,k,3) = -wz*delta2(i+1,j,k)
             gradphi(i+1,j,k,3) =  wz*delta2(i  ,j,k)
          enddo
       enddo
    enddo
    !$omp end parallel do


    ! Inverse FFT Grad phi_2 fields
    call fft_3d('b',Ndm,Ndm,Ndm,gradphi(:,:,:,1))
    call fft_3d('b',Ndm,Ndm,Ndm,gradphi(:,:,:,2))
    call fft_3d('b',Ndm,Ndm,Ndm,gradphi(:,:,:,3))


    ! Save in particle array
    !$omp parallel do     &
    !$omp default(shared) &
    !$omp private(i,j,k)
    do k=1,Ndm
       do j=1,Ndm
          do i=1,Ndm
             dm(i,j,k)%x(1) = dm(i,j,k)%x(1) + Dfactor2*gradphi(i,j,k,1)
             dm(i,j,k)%x(2) = dm(i,j,k)%x(2) + Dfactor2*gradphi(i,j,k,2)
             dm(i,j,k)%x(3) = dm(i,j,k)%x(3) + Dfactor2*gradphi(i,j,k,3)
             dm(i,j,k)%v(1) = dm(i,j,k)%v(1) + vfactor2*gradphi(i,j,k,1)
             dm(i,j,k)%v(2) = dm(i,j,k)%v(2) + vfactor2*gradphi(i,j,k,2)
             dm(i,j,k)%v(3) = dm(i,j,k)%v(3) + vfactor2*gradphi(i,j,k,3)
          enddo
       enddo
    enddo
    !$omp end parallel do


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called calc gradphi 2'
    return
  end subroutine calc_gradphi_2


!------------------------------------------------------------------------------!


  subroutine calc_dm
    ! Default
    implicit none


    ! Local variables
    integer(4) :: i,j,k
    real(8), dimension(3) :: x,v


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Compute particle positions + displacement
    !$omp parallel do        &
    !$omp default(shared)    &
    !$omp private(i,j,k,x,v)
    do k=1,Ndm
       do j=1,Ndm
          do i=1,Ndm
             x = mod(dm(i,j,k)%x + (/i,j,k/) - 0.5 + ndmr,ndmr)
             v = dm(i,j,k)%v*time_unit

             dm(i,j,k)%x = x
             dm(i,j,k)%v = v
          enddo
       enddo
    enddo
    !$omp end parallel do


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called calc dm'
    return
  end subroutine calc_dm


!------------------------------------------------------------------------------!


  subroutine link_dm
    ! Default
    implicit none


    ! Local variables
    integer(4) :: icpu,i,j,k
    integer(4) :: i1,i2,i3,idx(3)
    integer(8) :: ip,next


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Construct chaining lists in parallel
    !$omp parallel             &
    !$omp default(shared)      &
    !$omp private(icpu,ip,idx) &
    !$omp private(i,j,k,next)  &
    !$omp private(i1,i2,i3)
    !$omp do
    do icpu=1,N_cpu
       ! Init
       hoc_cpu(:,:,icpu) = 0

       ! Loop over particles
       do ip=dm_cpu(1,icpu),dm_cpu(2,icpu)
          j                 = 1 + mod(int(dm_ip(ip)%x(2)*x_dm_gr),N_grid)
          k                 = 1 + mod(int(dm_ip(ip)%x(3)*x_dm_gr),N_grid)
          ll_dm(ip)         = hoc_cpu(j,k,icpu)
          hoc_cpu(j,k,icpu) = ip
       enddo
    enddo
    !$omp end do
    !$omp do
    do k=1,N_grid
       do j=1,N_grid
          ! Init
          hoc_dm(:,j,k) = 0

          ! Loop over cpus
          do icpu=N_cpu,1,-1
             ! Head of chain
             ip = hoc_cpu(j,k,icpu)

             do while (ip > 0)
                i             = 1 + mod(int(dm_ip(ip)%x(1)*x_dm_gr),N_grid)
                next          = ll_dm(ip)
                ll_dm(ip)     = hoc_dm(i,j,k)
                hoc_dm(i,j,k) = ip
                ip            = next
             enddo
          enddo
       enddo
    enddo
    !$omp end do
    !$omp end parallel

    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called link dm'
    return
  end subroutine link_dm


!------------------------------------------------------------------------------!


  subroutine calc_density_velocity_fields(z,density,velocity)
    ! Default
    implicit none


    ! Local parameters
    real(8), parameter :: mass = x_dm_gr**3


    ! Subroutine arguments
    real(8), intent(in) :: z
    real(8), dimension(:,:,:)   :: density
    real(8), dimension(:,:,:,:) :: velocity


    ! Local variables
    integer(4) :: i,j,k,n,loc(1)
    real(8)    :: d,davg,dstd,dmax,dmin
    real(8), dimension(3) :: v,vavg,vstd,vmax,vmin


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Compute cosmology variables
    call calc_cosmo_var(z)


    ! Count the call before anything else: the checkpoints below fire on the
    ! first one only, which is calc_zreion's at z = zmean_zre.
    ckpt_ndvf = ckpt_ndvf + 1


    ! Compute displacement fields
    call calc_gradphi_1
    if (ckpt_ndvf == 1) then
       call ckpt_comp_last('calc_gradphi_1','gradphi_x',gradphi,Ndm,Ndm,Ndm,3,1)
       call ckpt_comp_last('calc_gradphi_1','gradphi_y',gradphi,Ndm,Ndm,Ndm,3,2)
       call ckpt_comp_last('calc_gradphi_1','gradphi_z',gradphi,Ndm,Ndm,Ndm,3,3)
    endif

    call calc_gradphi_2
    if (ckpt_ndvf == 1) then
       call ckpt_kspace('calc_gradphi_2','delta2_k',delta2,Ndm,Ndm,Ndm)
       call ckpt_comp_last('calc_gradphi_2','gradphi_x',gradphi,Ndm,Ndm,Ndm,3,1)
       call ckpt_comp_last('calc_gradphi_2','gradphi_y',gradphi,Ndm,Ndm,Ndm,3,2)
       call ckpt_comp_last('calc_gradphi_2','gradphi_z',gradphi,Ndm,Ndm,Ndm,3,3)
    endif


    ! Displace particles
    call calc_dm


    ! Construct linked list
    call link_dm


    ! Add particles to density and velocity fields
    !$omp parallel        &
    !$omp default(shared) &
    !$omp private(i,k,n)
    !$omp do schedule(static)
    do k=1,N_grid
       density(:,:,k)    = 0
       velocity(:,:,:,k) = 0
    enddo
    !$omp end do
    !$omp do schedule(dynamic,1)
    do n=1,Ndomain
       call set_domain(i,Ndomain,domain)
       select case(dep_scheme)
       case(0)
          call ngp_mass_assignment(indx_dom(:,:,i))
       case(1)
          call cic_mass_assignment(indx_dom(:,:,i))
       case(2)
          call tsc_mass_assignment(indx_dom(:,:,i))
       end select
       call end_domain(i,Ndomain,domain)
    enddo
    !$omp end do
    !$omp do schedule(dynamic,1)
    do n=1,Ndomain
       call set_domain(i,Ndomain,domain)
       select case(dep_scheme)
       case(0)
          call ngp_vel_assignment(indx_dom(:,:,i))
       case(1)
          call cic_vel_assignment(indx_dom(:,:,i))
       case(2)
          call tsc_vel_assignment(indx_dom(:,:,i))
       end select
       call end_domain(i,Ndomain,domain)
    enddo
    !$omp end do
    !$omp end parallel


    davg = 0
    dstd = 0
    dmax = 0
    dmin = huge(dmin)
    vavg = 0
    vstd = 0
    vmax = -huge(vmax)
    vmin = huge(vmin)
    ! Compute stats
    !$omp parallel do                      &
    !$omp default(shared)                  &
    !$omp private(i,j,k,d,v)               &
    !$omp reduction(+:davg,dstd,vavg,vstd) &
    !$omp reduction(max:dmax,vmax)         &
    !$omp reduction(min:dmin,vmin)
    do k=1,N_grid
       do j=1,N_grid
          do i=1,N_grid
             d = density(i,j,k)
             v = velocity(:,i,j,k)

             davg = davg + d
             dstd = dstd + d**2
             dmin = min(d,dmin)
             dmax = max(d,dmax)

             vavg = vavg + v
             vstd = vstd + v**2
             vmin = min(v,vmin)
             vmax = max(v,vmax)
          enddo
       enddo
    enddo
    !$omp end parallel do

    ! Finish computing statistics
    davg = davg/ncellr
    dstd = sqrt(dstd/ncellr - davg**2)
    vavg = vavg/ncellr
    vstd = sqrt(vstd/ncellr - vavg**2)

    write(*,*) "redshift: ",redshift
    write(*,*) "density: ",real((/ davg   ,dstd   ,dmax   ,dmin    /))
    write(*,*) "vx:      ",real((/ vavg(1),vstd(1),vmax(1),vmin(1) /))
    write(*,*) "vy:      ",real((/ vavg(2),vstd(2),vmax(2),vmin(2) /))
    write(*,*) "vz:      ",real((/ vavg(3),vstd(3),vmax(3),vmin(3) /))

    ! Save out to global arrays
    loc = findloc(zval_list, redshift)
    vrms(:,loc(1)) = vstd


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,&
         '  Called calc density velocity fields'
    return


  contains


    ! Mass assignment


    subroutine ngp_mass_assignment(indx)
      ! Default
      implicit none


      ! Subroutine arguments
      integer(4), dimension(2,3) :: indx


      ! Local variables
      integer(4) :: i,j,k
      integer(4) :: ii,jj,kk
      integer(8) :: ip
      real(8)    :: x,y,z


      ! Loop over cells in domain
      do k=indx(1,3),indx(2,3)
      do j=indx(1,2),indx(2,2)
      do i=indx(1,1),indx(2,1)
         ! Head of chain
         ip = hoc_dm(i,j,k)

         do while(ip > 0)
            ! Particle
            x   = mod(dm_ip(ip)%x(1)*x_dm_gr - 0.5 + ngridr,ngridr)
            y   = mod(dm_ip(ip)%x(2)*x_dm_gr - 0.5 + ngridr,ngridr)
            z   = mod(dm_ip(ip)%x(3)*x_dm_gr - 0.5 + ngridr,ngridr)

            ! Assign to grid
            ii = 1 + int(x)
            jj = 1 + int(y)
            kk = 1 + int(z)

            density(ii,jj,kk) = density(ii,jj,kk) + mass

            ! Next particle
            ip = ll_dm(ip)
         enddo
      enddo
      enddo
      enddo

      return
    end subroutine ngp_mass_assignment


    subroutine cic_mass_assignment(indx)
      ! Default
      implicit none


      ! Subroutine arguments
      integer(4), dimension(2,3) :: indx


      ! Local variables
      integer(4) :: i,j,k
      integer(4) :: i1,i2,j1,j2,k1,k2
      integer(8) :: ip
      real(8)    :: x,y,z
      real(8)    :: dx1,dx2,dy1,dy2,dz1,dz2


      ! Loop over cells in domain
      do k=indx(1,3),indx(2,3)
      do j=indx(1,2),indx(2,2)
      do i=indx(1,1),indx(2,1)
         ! Head of chain
         ip = hoc_dm(i,j,k)

         do while (ip > 0)
            ! Particle
            x   = mod(dm_ip(ip)%x(1)*x_dm_gr - 0.5 + ngridr,ngridr)
            y   = mod(dm_ip(ip)%x(2)*x_dm_gr - 0.5 + ngridr,ngridr)
            z   = mod(dm_ip(ip)%x(3)*x_dm_gr - 0.5 + ngridr,ngridr)

            ! Assign CIC weights
            i1  = 1 + int(x)
            i2  = 1 + mod(i1,N_grid)
            dx1 = i1 - x
            dx2 = 1 - dx1
            j1  = 1 + int(y)
            j2  = 1 + mod(j1,N_grid)
            dy1 = j1 - y
            dy2 = 1 - dy1
            k1  = 1 + int(z)
            k2  = 1 + mod(k1,N_grid)
            dz1 = k1 - z
            dz2 = 1 - dz1

            ! Assign mass to dm density field
            density(i1,j1,k1) = density(i1,j1,k1) + mass*dx1*dy1*dz1
            density(i2,j1,k1) = density(i2,j1,k1) + mass*dx2*dy1*dz1
            density(i1,j2,k1) = density(i1,j2,k1) + mass*dx1*dy2*dz1
            density(i2,j2,k1) = density(i2,j2,k1) + mass*dx2*dy2*dz1
            density(i1,j1,k2) = density(i1,j1,k2) + mass*dx1*dy1*dz2
            density(i2,j1,k2) = density(i2,j1,k2) + mass*dx2*dy1*dz2
            density(i1,j2,k2) = density(i1,j2,k2) + mass*dx1*dy2*dz2
            density(i2,j2,k2) = density(i2,j2,k2) + mass*dx2*dy2*dz2

            ! Next particle
            ip = ll_dm(ip)
         enddo
      enddo
      enddo
      enddo

      return
    end subroutine cic_mass_assignment


    subroutine tsc_mass_assignment(indx)
      ! Default
      implicit none


      ! Subroutine arguments
      integer(4), dimension(2,3) :: indx


      ! Local variables
      integer(4) :: i,j,k
      integer(4) :: a,b,c
      integer(8) :: ip
      real(8)    :: x,y,z,dx,dy,dz
      integer(4), dimension(-1:1) :: ii,jj,kk
      real(8),    dimension(-1:1) :: wx,wy,wz

      ! Loop over cells in domain
      do k=indx(1,3),indx(2,3)
      do j=indx(1,2),indx(2,2)
      do i=indx(1,1),indx(2,1)
         ! Head of chain
         ip = hoc_dm(i,j,k)

         do while (ip > 0)
            ! Particle
            x   = mod(dm_ip(ip)%x(1)*x_dm_gr - 0.5 + ngridr,ngridr)
            y   = mod(dm_ip(ip)%x(2)*x_dm_gr - 0.5 + ngridr,ngridr)
            z   = mod(dm_ip(ip)%x(3)*x_dm_gr - 0.5 + ngridr,ngridr)

            ! Indices
            ii( 0) = 1 + int(x)
            ii(-1) = 1 + mod(ii(0) - 2 + N_grid,N_grid)
            ii( 1) = 1 + mod(ii(0)             ,N_grid)
            jj( 0) = 1 + int(y)
            jj(-1) = 1 + mod(jj(0) - 2 + N_grid,N_grid)
            jj( 1) = 1 + mod(jj(0)             ,N_grid)
            kk( 0) = 1 + int(z)
            kk(-1) = 1 + mod(kk(0) - 2 + N_grid,N_grid)
            kk( 1) = 1 + mod(kk(0)             ,N_grid)

            ! Weights
            dx     = x - (ii(0) - 0.5)
            wx( 0) = 0.75 - dx**2
            wx(-1) = 0.5*(1.5 - abs(dx + 1))**2
            wx( 1) = 0.5*(1.5 - abs(dx - 1))**2
            dy     = y - (jj(0) - 0.5)
            wy( 0) = 0.75 - dy**2
            wy(-1) = 0.5*(1.5 - abs(dy + 1))**2
            wy( 1) = 0.5*(1.5 - abs(dy - 1))**2
            dz     = z - (kk(0) - 0.5)
            wz( 0) = 0.75 - dz**2
            wz(-1) = 0.5*(1.5 - abs(dz + 1))**2
            wz( 1) = 0.5*(1.5 - abs(dz - 1))**2

            ! Add mass to density field
            do c=-1,1
            do b=-1,1
            do a=-1,1
               density(ii(a),jj(b),kk(c)) = density(ii(a),jj(b),kk(c)) &
                                          + mass*wx(a)*wy(b)*wz(c)
            enddo
            enddo
            enddo

            ! Next particle
            ip = ll_dm(ip)
         enddo
      enddo
      enddo
      enddo

      return
    end subroutine tsc_mass_assignment


    ! Velocity assignment


    subroutine ngp_vel_assignment(indx)
      ! Default
      implicit none


      ! Subroutine arguments
      integer(4), dimension(2,3) :: indx


      ! Local variables
      integer(4) :: i,j,k
      integer(4) :: ii,jj,kk
      integer(4) :: i1,i2,i3,idx(3)
      integer(8) :: ip
      real(8)    :: x,y,z,v(3)


      ! Loop over cells in domain
      do k=indx(1,3),indx(2,3)
      do j=indx(1,2),indx(2,2)
      do i=indx(1,1),indx(2,1)
         ! Head of chain
         ip = hoc_dm(i,j,k)

         do while (ip > 0)
            ! Particle
            x   = mod(dm_ip(ip)%x(1)*x_dm_gr - 0.5 + ngridr,ngridr)
            y   = mod(dm_ip(ip)%x(2)*x_dm_gr - 0.5 + ngridr,ngridr)
            z   = mod(dm_ip(ip)%x(3)*x_dm_gr - 0.5 + ngridr,ngridr)
            v   = dm_ip(ip)%v*vel_unit/1D5

            ! Assign to grid
            ii = 1 + int(x)
            jj = 1 + int(y)
            kk = 1 + int(z)

            if (density(ii,jj,kk) > 0) then
               velocity(:,ii,jj,kk) = velocity(:,ii,jj,kk) &
                    + v*mass/density(ii,jj,kk)
            endif

            ! Next particle
            ip = ll_dm(ip)
         enddo
      enddo
      enddo
      enddo

      return
    end subroutine ngp_vel_assignment


    subroutine cic_vel_assignment(indx)
      ! Default
      implicit none


      ! Subroutine arguments
      integer(4), dimension(2,3) :: indx


      ! Local variables
      integer(4) :: i,j,k
      integer(4) :: i1,i2,j1,j2,k1,k2
      integer(8) :: ip
      real(8)    :: x,y,z,v(3)
      real(8)    :: dx1,dx2,dy1,dy2,dz1,dz2


      ! Loop over cells in domain
      do k=indx(1,3),indx(2,3)
      do j=indx(1,2),indx(2,2)
      do i=indx(1,1),indx(2,1)
         ! Head of chain
         ip = hoc_dm(i,j,k)

         do while (ip > 0)
            ! Particle
            x   = mod(dm_ip(ip)%x(1)*x_dm_gr - 0.5 + ngridr,ngridr)
            y   = mod(dm_ip(ip)%x(2)*x_dm_gr - 0.5 + ngridr,ngridr)
            z   = mod(dm_ip(ip)%x(3)*x_dm_gr - 0.5 + ngridr,ngridr)
            v   = dm_ip(ip)%v*vel_unit/1D5

            ! Assign CIC weights
            i1  = 1 + int(x)
            i2  = 1 + mod(i1,N_grid)
            dx1 = i1 - x
            dx2 = 1 - dx1
            j1  = 1 + int(y)
            j2  = 1 + mod(j1,N_grid)
            dy1 = j1 - y
            dy2 = 1 - dy1
            k1  = 1 + int(z)
            k2  = 1 + mod(k1,N_grid)
            dz1 = k1 - z
            dz2 = 1 - dz1

            ! Assign mass to dm density field
            if (density(i1,j1,k1) > 0) then
               velocity(:,i1,j1,k1) = velocity(:,i1,j1,k1) &
                    + v*mass*dx1*dy1*dz1/density(i1,j1,k1)
            endif
            if (density(i2,j1,k1) > 0) then
               velocity(:,i2,j1,k1) = velocity(:,i2,j1,k1) &
                    + v*mass*dx2*dy1*dz1/density(i2,j1,k1)
            endif
            if (density(i1,j2,k1) > 0) then
               velocity(:,i1,j2,k1) = velocity(:,i1,j2,k1) &
                    + v*mass*dx1*dy2*dz1/density(i1,j2,k1)
            endif
            if (density(i2,j2,k1) > 0) then
               velocity(:,i2,j2,k1) = velocity(:,i2,j2,k1) &
                    + v*mass*dx2*dy2*dz1/density(i2,j2,k1)
            endif
            if (density(i1,j1,k2) > 0) then
               velocity(:,i1,j1,k2) = velocity(:,i1,j1,k2) &
                    + v*mass*dx1*dy1*dz2/density(i1,j1,k2)
            endif
            if (density(i2,j1,k2) > 0) then
               velocity(:,i2,j1,k2) = velocity(:,i2,j1,k2) &
                    + v*mass*dx2*dy1*dz2/density(i2,j1,k2)
            endif
            if (density(i1,j2,k2) > 0) then
               velocity(:,i1,j2,k2) = velocity(:,i1,j2,k2) &
                    + v*mass*dx1*dy2*dz2/density(i1,j2,k2)
            endif
            if (density(i2,j2,k2) > 0) then
               velocity(:,i2,j2,k2) = velocity(:,i2,j2,k2) &
                    + v*mass*dx2*dy2*dz2/density(i2,j2,k2)
            endif

            ! Next particle
            ip = ll_dm(ip)
         enddo
      enddo
      enddo
      enddo

      return
    end subroutine cic_vel_assignment


    subroutine tsc_vel_assignment(indx)
      ! Default
      implicit none


      ! Subroutine arguments
      integer(4), dimension(2,3) :: indx


      ! Local variables
      integer(4) :: i,j,k
      integer(4) :: a,b,c
      integer(8) :: ip
      real(8)    :: x,y,z,dx,dy,dz,v(3)
      integer(4), dimension(-1:1) :: ii,jj,kk
      real(8),    dimension(-1:1) :: wx,wy,wz

      ! Loop over cells in domain
      do k=indx(1,3),indx(2,3)
      do j=indx(1,2),indx(2,2)
      do i=indx(1,1),indx(2,1)
         ! Head of chain
         ip = hoc_dm(i,j,k)

         do while (ip > 0)
            ! Particle
            x   = mod(dm_ip(ip)%x(1)*x_dm_gr - 0.5 + ngridr,ngridr)
            y   = mod(dm_ip(ip)%x(2)*x_dm_gr - 0.5 + ngridr,ngridr)
            z   = mod(dm_ip(ip)%x(3)*x_dm_gr - 0.5 + ngridr,ngridr)
            v   = dm_ip(ip)%v*vel_unit/1D5

            ! Indices
            ii( 0) = 1 + int(x)
            ii(-1) = 1 + mod(ii(0) - 2 + N_grid,N_grid)
            ii( 1) = 1 + mod(ii(0)             ,N_grid)
            jj( 0) = 1 + int(y)
            jj(-1) = 1 + mod(jj(0) - 2 + N_grid,N_grid)
            jj( 1) = 1 + mod(jj(0)             ,N_grid)
            kk( 0) = 1 + int(z)
            kk(-1) = 1 + mod(kk(0) - 2 + N_grid,N_grid)
            kk( 1) = 1 + mod(kk(0)             ,N_grid)

            ! Weights
            dx     = x - (ii(0) - 0.5)
            wx( 0) = 0.75 - dx**2
            wx(-1) = 0.5*(1.5 - abs(dx + 1))**2
            wx( 1) = 0.5*(1.5 - abs(dx - 1))**2
            dy     = y - (jj(0) - 0.5)
            wy( 0) = 0.75 - dy**2
            wy(-1) = 0.5*(1.5 - abs(dy + 1))**2
            wy( 1) = 0.5*(1.5 - abs(dy - 1))**2
            dz     = z - (kk(0) - 0.5)
            wz( 0) = 0.75 - dz**2
            wz(-1) = 0.5*(1.5 - abs(dz + 1))**2
            wz( 1) = 0.5*(1.5 - abs(dz - 1))**2

            ! Add mass to density field
            do c=-1,1
            do b=-1,1
            do a=-1,1
               if (density(ii(a),jj(b),kk(c)) > 0) then
                  velocity(:,ii(a),jj(b),kk(c)) = velocity(:,ii(a),jj(b),kk(c))&
                       + v*mass*wx(a)*wy(b)*wz(c)/density(ii(a),jj(b),kk(c))
               endif
            enddo
            enddo
            enddo

            ! Next particle
            ip = ll_dm(ip)
         enddo
      enddo
      enddo
      enddo

      return
    end subroutine tsc_vel_assignment


  end subroutine calc_density_velocity_fields


!------------------------------------------------------------------------------!


  subroutine calc_rho_ion_fields(zval,density)
    ! Default
    implicit none


    ! Subroutine arguments
    real(8) :: zval
    real(8), dimension(N_grid+2,N_grid,N_grid) :: density


    ! Local variables
    integer(4) :: i,j,k
    real(8)    :: x,xbar,xavg,xstd,xmin,xmax,tt


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Get t0 as a function of redshift
    tt = T0(zval)

    ! Move density over to rho field
    !$omp parallel do     &
    !$omp default(shared) &
    !$omp private(i,j,k)
    do k=1,N_grid
       do j=1,N_grid
          do i=1,N_grid
             rho(i,j,k) = density(i,j,k) - 1
          enddo
       enddo
    enddo
    !$omp end parallel do

    ! Compute ionization field
    xbar = 0
    !$omp parallel do       &
    !$omp default(shared)   &
    !$omp private(i,j,k,x)  &
    !$omp reduction(+:xbar)
    do k=1,N_grid
       do j=1,N_grid
          do i=1,N_grid
             if (zreion(i,j,k) > zval) then
                ion(i,j,k) = 1
                xbar       = xbar + 1
                tbg(i,j,k) = 0
             else
                ion(i,j,k) = 0
                tbg(i,j,k) = tt*density(i,j,k)
             endif
          enddo
       enddo
    enddo
    !$omp end parallel do

    ! Compute average ionization fraction
    xbar = xbar/ncellr
    write(*,*) "xbar: ",xbar

    if (xbar > 0) then
       ! Convert to overdensity and compute stats
       xavg = 0
       xstd = 0
       xmin = huge(xmin)
       xmax = 0
       !$omp parallel do            &
       !$omp default(shared)        &
       !$omp private(i,j,k,x)       &
       !$omp reduction(+:xavg,xstd) &
       !$omp reduction(max:xmax)    &
       !$omp reduction(min:xmin)
       do k=1,N_grid
          do j=1,N_grid
             do i=1,N_grid
                ion(i,j,k) = ion(i,j,k)/xbar - 1
                x    = ion(i,j,k)
                xavg = xavg + x
                xstd = xstd + x**2
                xmax = max(x,xmax)
                xmin = min(x,xmin)
             enddo
          enddo
       enddo
       !$omp end parallel do

       xavg = xavg/ncellr
       xstd = sqrt(xstd/ncellr - xavg**2)
       write(*,*) "ion:",real((/ xavg, xstd, xmin, xmax /))
    endif


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called calc rho ion fields'
    return
  end subroutine calc_rho_ion_fields


!------------------------------------------------------------------------------!


  subroutine calc_ksz_t21_fields
    ! Default
    implicit none


    ! Local variables
    integer(4) :: i,j,k,ii,jj,kk,j1,k1
    integer(4) :: iz1,iz2,idepth,ibest
    integer(4) :: icpu,ipix,is,imin(1),Nt21,Ngal
    real(8)    :: zmin,z1,z2,a1,a2,dzbest,aedge
    real(8)    :: d0,dtot,aslice,zslice,d,d1,d2
    real(8)    :: astart,afar,dA,tx,ty,t21,gal
    real(8)    :: dl,deltat,aval,zval,tau,dtau
    real(8)    :: ne,v,v1,v2,xi,nH,nHe,bg,tau_lowz
    logical    :: increasing


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! We can use 2LPT to get to an arbitrary redshift, but doing it every slice
    ! is overkill. Better to have two fields, and just interpolate between them.

    ! Initialize
    ksz_map = 0
    t21_map = 0
    gal_map = 0
    tau_map = 0

    ! Use series of "node redshifts" that we interpolate between
    zmin = minval(zval_list)
    if (z_start < zmin) then
       z1   = zmin
       imin = minloc(zval_list)
       iz1  = imin(1)
    else
       ! Find greatest redshift smaller than z_start
       dzbest = z_start - zmin
       ibest  = 1
       do iz1=2,Nredshift
          if (z_start > zval_list(iz1) &
               .and. z_start - zval_list(iz1) < dzbest) then
             dzbest = z_start - zval_list(iz1)
             ibest  = iz1
          endif
       enddo
       iz1 = ibest
       z1  = zval_list(iz1)
    endif

    ! Find the companion index
    ! We assume the list is monotonic, but not direction
    if (iz1 == 1) then
       ! We're at the low end of the array; can only go up
       iz2 = 2
       increasing = .true.
    else if (iz1 == Nredshift) then
       ! We're at the high end of the array; can only go down
       iz2 = Nredshift - 1
       increasing = .false.
    else
       ! We want to increase in redshift, so that z2 > z1
       if (zval_list(iz1+1) > z1) then
          iz2 = iz1 + 1
          increasing = .true.
       else
          iz2 = iz1 - 1
          increasing = .false.
       endif
    endif

    ! Assign redshift value
    z2 = zval_list(iz2)

    ! Compute velocity and density fields
    density1  => densityA
    density2  => densityB
    velocity1 => velocityA
    velocity2 => velocityB
    call calc_density_velocity_fields(z1,density1,velocity1)
    call calc_density_velocity_fields(z2,density2,velocity2)
    if (calc_pk) then
       call calc_rho_ion_fields(z1,density1)
       call fft_3d('f',N_grid,N_grid,N_grid,rho)
       call fft_3d('f',N_grid,N_grid,N_grid,ion)
       call fft_3d('f',N_grid,N_grid,N_grid,tbg)
       call calc_pspec(rho,rho,pk_dd(:,:,iz1))
       call calc_pspec(ion,ion,pk_xx(:,:,iz1))
       call calc_pspec(rho,ion,pk_dx(:,:,iz1))
       call calc_pspec(tbg,tbg,pk_tt(:,:,iz1))

       call calc_rho_ion_fields(z2,density2)
       call fft_3d('f',N_grid,N_grid,N_grid,rho)
       call fft_3d('f',N_grid,N_grid,N_grid,ion)
       call fft_3d('f',N_grid,N_grid,N_grid,tbg)
       call calc_pspec(rho,rho,pk_dd(:,:,iz2))
       call calc_pspec(ion,ion,pk_xx(:,:,iz2))
       call calc_pspec(rho,ion,pk_dx(:,:,iz2))
       call calc_pspec(tbg,tbg,pk_tt(:,:,iz2))
    endif

    ! Start doing work
    aedge = 1D0/(1+z_start)
    d0    = interpolate(aedge,d_comoving,1,2,'lin')
    do idepth=1,Nsightpix
       dtot   = d0 + (idepth-0.5)*x_grid_box
       aslice = interpolate(dtot,d_comoving,2,1,'lin')
       zslice = 1/aslice - 1

       ! Save in global array
       zvals(idepth) = zslice

       ! Calculate global temperature
       t0vals(idepth) = T0(zslice)

       ! When we hit a point where zslice > z2, change which field we're
       ! pointing at
       if (zslice > z2) then
          ! Check if we're at the end of the list or not
          if ((increasing .and. iz2 >= Nredshift) .or. &
               ((.not. increasing) .and. iz2 <= 1)) then
             ! Do nothing
             continue
          else
             ! Reassign pointers
             iz1 = iz2
             if (increasing) then
                iz2 = iz2 + 1
             else
                iz2 = iz2 - 1
             endif

             if (associated(density1, densityA)) then
                density1  => densityB
                density2  => densityA
                velocity1 => velocityB
                velocity2 => velocityA
             else
                density1  => densityA
                density2  => densityB
                velocity1 => velocityA
                velocity2 => velocityB
             endif

             z1 = zval_list(iz1)
             z2 = zval_list(iz2)
             call calc_density_velocity_fields(z2,density2,velocity2)
             if (calc_pk) then
                call calc_rho_ion_fields(z2,density2)
                call fft_3d('f',N_grid,N_grid,N_grid,rho)
                call fft_3d('f',N_grid,N_grid,N_grid,ion)
                call fft_3d('f',N_grid,N_grid,N_grid,tbg)
                call calc_pspec(rho,rho,pk_dd(:,:,iz2))
                call calc_pspec(ion,ion,pk_xx(:,:,iz2))
                call calc_pspec(rho,ion,pk_dx(:,:,iz2))
                call calc_pspec(tbg,tbg,pk_tt(:,:,iz2))
             endif
          endif
       endif

       ! Fill in density and velocity fields
       ! Interpolate in scalefactor for quantities
       a1 = 1D0/(1 + z1)
       a2 = 1D0/(1 + z2)
       ! Loop over slab
       select case(los_axis)
       case(1)
          ! Increasing along x-axis
          ! y- and z-axes are normal
          ii = 1 + modulo(i0 + idepth - 1, N_grid)
          !$omp parallel do             &
          !$omp default(shared)         &
          !$omp private(j,k,jj,kk)      &
          !$omp private(d,d1,d2,v,v1,v2)
          do k=1,N_grid
             kk = 1 + modulo(k0 + k - 1, N_grid)
             do j=1,N_grid
                jj = 1 + modulo(j0 + j - 1, N_grid)

                d1 = density1(ii,jj,kk)
                d2 = density2(ii,jj,kk)
                v1 = velocity1(1,ii,jj,kk)
                v2 = velocity2(1,ii,jj,kk)

                d = d1 + (d2 - d1)*((aslice - a1)/(a2 - a1))
                v = v1 + (v2 - v1)*((aslice - a1)/(a2 - a1))

                density_ksz(idepth,j,k)  = max(d,0D0)
                velocity_ksz(idepth,j,k) = v
             enddo
          enddo
          !$omp end parallel do
       case(2)
          ! Increasing along y-axis
          ! x- and z-axes are normal
          jj = 1 + modulo(j0 + idepth - 1, N_grid)
          !$omp parallel do             &
          !$omp default(shared)         &
          !$omp private(i,k,ii,kk)      &
          !$omp private(d,d1,d2,v,v1,v2)
          do k=1,N_grid
             kk = 1 + modulo(k0 + k - 1, N_grid)
             do i=1,N_grid
                ii = 1 + modulo(i0 + i - 1, N_grid)

                d1 = density1(ii,jj,kk)
                d2 = density2(ii,jj,kk)
                v1 = velocity1(2,ii,jj,kk)
                v2 = velocity2(2,ii,jj,kk)

                d = d1 + (d2 - d1)*((aslice - a1)/(a2 - a1))
                v = v1 + (v2 - v1)*((aslice - a1)/(a2 - a1))

                density_ksz(idepth,i,k)  = max(d,0D0)
                velocity_ksz(idepth,i,k) = v
             enddo
          enddo
          !$omp end parallel do
       case(3)
          ! Increasing along z-axis
          ! x- and y-axes are normal
          kk = 1 + modulo(k0 + idepth - 1, N_grid)
          !$omp parallel do             &
          !$omp default(shared)         &
          !$omp private(i,j,ii,jj)      &
          !$omp private(d,d1,d2,v,v1,v2)
          do j=1,N_grid
             jj = 1 + modulo(j0 + j - 1, N_grid)
             do i=1,N_grid
                ii = 1 + modulo(i0 + i - 1, N_grid)

                d1 = density1(ii,jj,kk)
                d2 = density2(ii,jj,kk)
                v1 = velocity1(3,ii,jj,kk)
                v2 = velocity2(3,ii,jj,kk)

                d = d1 + (d2 - d1)*((aslice - a1)/(a2 - a1))
                v = v1 + (v2 - v1)*((aslice - a1)/(a2 - a1))

                density_ksz(idepth,i,j)  = max(d,0D0)
                velocity_ksz(idepth,i,j) = v
             enddo
          enddo
          !$omp end parallel do
       end select
    enddo

    ! Now compute sightlines
    ! Calculate scalefactors
    astart = 1D0/(1+z_start)
    d0     = interpolate(astart,d_comoving,1,2,'lin')
    dtot   = d0 + Nsightpix*x_grid_box
    afar   = interpolate(dtot,d_comoving,2,1,'lin')

    ! Calculate angular diameter distance
    ! d_A(z_start+box) sets the maximum angular extent of sightlines
    dA = interpolate(afar,angular_distance,1,2,'lin')
    theta_max_ksz = box*afar/dA

    ! Get low-redshift contribution for tau
    tau_lowz = interpolate(z_start,tau_vals,1,2,'lin')

    ! Loop over sightlines
    !$omp parallel do                    &
    !$omp default(shared)                &
    !$omp private(j,k,icpu,ipix,is)      &
    !$omp private(ii,jj,kk,j1,k1)        &
    !$omp private(dtot,aval,zval,tau)    &
    !$omp private(dtau)                  &
    !$omp private(d,dl,ne,v,tx,ty,dA,xi) &
    !$omp private(deltat,nH,nHe,t21,gal) &
    !$omp private(Nt21,Ngal,bg)
    do icpu=1,N_cpu
       do is=sight_cpu(1,icpu),sight_cpu(2,icpu)
          j  = 1 + mod(is-1,N_grid)
          k  = 1 + (is-1)/N_grid
          tx = 1D0*(j-0.5-N_grid/2)/N_grid*theta_max_ksz
          ty = 1D0*(k-0.5-N_grid/2)/N_grid*theta_max_ksz

          deltat = 0
          t21    = 0
          gal    = 0
          dtau   = 0
          Nt21   = 0
          Ngal   = 0
          do ipix=1,Nsightpix
             ii = 1 + modulo(i0 + ipix - 1, N_grid)
             ! Compute total comoving distance from observer to center of cell
             dtot = d0 + (ipix-0.5)*x_grid_box
             aval = interpolate(dtot,d_comoving,2,1,'lin')
             zval = 1/aval - 1

             ! Compute proper distance for this cell
             dl = aval*x_grid_box/hubble0*Mpc2cm

             ! Compute other relevant quantities
             ! Since position of sightline changes each pixel along the line of
             !   sight, we need to find approrpiate cell
             dA = interpolate(aval,angular_distance,1,2,'lin')

             ! Scale dA by scalefactor
             dA = dA/aval

             ! Compute relevant quantities
             j1 = min(max(nint(tx*dA/x_grid_box) + N_grid/2, 1), N_grid)
             k1 = min(max(nint(ty*dA/x_grid_box) + N_grid/2, 1), N_grid)
             jj = 1 + modulo(j0 + j1 - 1, N_grid)
             kk = 1 + modulo(k0 + k1 - 1, N_grid)

             select case(los_axis)
             case(1)
                if (zreion(ii,jj,kk) > zval) then
                   xi = 1
                else
                   xi = 0
                endif
             case(2)
                if (zreion(jj,ii,kk) > zval) then
                   xi = 1
                else
                   xi = 0
                endif
             case(3)
                if (zreion(jj,kk,ii) > zval) then
                   xi = 1
                else
                   xi = 0
                endif
             end select

             ! Get density and velocity
             ! Velocity is in proper km/s, convert to cgs
             d = density_ksz(ipix,jj,kk)
             v = velocity_ksz(ipix,jj,kk)*1D5

             ! ne calculation
             nH  = d*OmegaB*rhoc_cgs*hubble0**2/aval**3*(1-YHe)/mH_cgs
             nHe = d*OmegaB*rhoc_cgs*hubble0**2/aval**3*(  YHe)/mHe_cgs
             ne  = xi*(nH + nHe)

             ! Compute T21 and "galaxy" field
             if (use_bt) then
                bg = interpolate(zval,bt_bias,1,2,'lin')
             else
                bg = b_gal
             endif
             if (zval > z1_t21 .and. zval < z2_t21) then
                t21  = t21 + T0(zval)*d*(1-xi)
                Nt21 = Nt21 + 1
             endif
             if (zval > z1_gal .and. zval < z2_gal) then
                gal  = gal + bg*d
                Ngal = Ngal + 1
             endif

             ! Optionally save lightcones
             if (save_t21_lightcone) then
                t21_box(j,k,ipix) = T0(zval)*d*(1-xi)
             endif
             if (save_gal_lightcone) then
                gal_box(j,k,ipix) = bg*d
             endif

             ! Use lookup table for tau(z)
             tau = interpolate(zval,tau_vals,1,2,'lin')

             ! Compute contribution to overall pixel
             deltat = deltat + exp(-tau)*ne*v*dl

             ! Tau calculation
             dtau = dtau + sT_cgs*ne*dl
          enddo

          ! Add overall multiplicative factors
          deltat = deltat*sT_cgs/c_cgs
          if (Nt21 > 0) then
             t21 = t21/Nt21
          endif
          if (Ngal > 0) then
             gal = gal/Ngal
          endif

          ! Save in master maps
          ksz_map(j,k) = -deltat
          t21_map(j,k) = t21
          gal_map(j,k) = gal
          tau_map(j,k) = dtau + tau_lowz
       enddo
    enddo
    !$omp end parallel do


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called calc ksz t21 fields'
    return
  end subroutine calc_ksz_t21_fields


!------------------------------------------------------------------------------!


  subroutine calc_Nsightpix
    ! Default
    implicit none


    ! Local variables
    real(8) :: astart,aend
    real(8) :: dstart,dend,dtot


    ! Timing variables
    character(8) :: ts1,ts2
    real(8)      :: tr1,tr2
    call time(ts1)
    tr1 = omp_get_wtime()


    ! Compute the length of sightlines in comoving distance
    astart = 1D0/(1+z_start)
    dstart = interpolate(astart,d_comoving,1,2,'lin')
    aend   = 1D0/(1+z_end)
    dend   = interpolate(aend,  d_comoving,1,2,'lin')
    dtot   = abs(dend - dstart)

    Nsightpix = ceiling(dtot/x_grid_box)
    write(*,*) "Nsightpix: ",Nsightpix


    tr2 = omp_get_wtime()
    call time(ts2)
    write(*,'(f8.2,2a10,a)') tr2-tr1,ts1,ts2,'  Called calc Nsightpix'
    return
  end subroutine calc_Nsightpix


!------------------------------------------------------------------------------!


  pure function T0(z)
    ! Default
    implicit none

    ! Function arguments
    real(8), intent(in) :: z
    real(8)             :: T0

    T0 = 38.6D0*hubble0*(omegab/0.045D0) &
         *sqrt(0.27D0/omegam*(1+z)/10D0)
    return
  end function T0


end module field_tools
