program coeval_boxes
  ! Intel
  use IFPORT
  use OMP_LIB


  ! Variables
  use global


  ! Tools
  use cosmo_tools
  use domain_tools
  use rng_tools
  use field_tools
  use io_tools
  use zreion_tools


  ! Default
  implicit none


  ! Local parameters
  real(8),    parameter :: z_min = 6D0
  real(8),    parameter :: z_max = 12D0
  real(8),    parameter :: d_z   = 0.1D0
  integer(4), parameter :: N_z   = (z_max - z_min) / d_z + 1


  ! Redshift index
  integer(4) :: izval
  real(8)    :: zval


  ! Global temperature
  real(8), dimension(2,N_z) :: t0_vals


  ! Initialize
  write(*,*) "Num cpu avail: ",OMP_GET_NUM_PROCS()
  call OMP_SET_NUM_THREADS(N_cpu)
  call process_args
  call init_dm
  call init_domain
  call calc_cosmo_distance
  call calc_angular_distance
  if (use_bt) then
     call read_bt
  endif
  call init_fields

  ! Do work
  call calc_linear_power_spectrum

  ! Generate initial conditions
  call make_gaussian_random_field
  call calc_delta_field

  ! Do rest of work
  call calc_zreion
  do izval = 1,N_z
     zval = z_min + (izval - 1) * d_z
     t0_vals(1,izval) = zval
     t0_vals(2,izval) = T0(zval)
  enddo
  call write_zreion(t0_vals)

  ! Iterate through redshift node values
  do izval=3,14
     zval = zval_list(izval)
     call calc_density_velocity_fields(zval,densityA,velocityA)
     call calc_rho_ion_fields(zval,densityA)

     call write_coeval_density(zval)
  enddo


  call close_h5


contains


  subroutine process_args
    ! Default
    implicit none


    ! Local variables
    integer(4)      :: i,nargs
    character(1000) :: arg


    ! Set defaults
    dir_out   = dir_out0
    zmean_zre = zmean_zre0
    alpha_zre = alpha_zre0
    kb_zre    = kb_zre0
    b0_zre    = b0_zre0

    ! Iterate through arguments
    nargs = command_argument_count()
    if (nargs > 0) then
       do i=1,nargs
          call get_command_argument(i, arg)
          select case(i)
          case(1)
             dir_out = arg
          case(2)
             read(arg,*) zmean_zre
          case(3)
             read(arg,*) alpha_zre
          case(4)
             read(arg,*) kb_zre
          case(5)
             read(arg,*) b0_zre
          end select
       enddo
    endif

    write(*,*) "dir_out:   ", trim(dir_out)
    write(*,*) "zmean_zre: ", zmean_zre
    write(*,*) "alpha_zre: ", alpha_zre
    write(*,*) "kb_zre:    ", kb_zre
    write(*,*) "b0_zre:    ", b0_zre

    return
  end subroutine process_args


end program coeval_boxes
